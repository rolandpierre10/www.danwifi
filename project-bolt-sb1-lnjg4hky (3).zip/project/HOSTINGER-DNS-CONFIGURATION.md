# 🎯 Configuration DNS Hostinger pour danwifi.com

## 📋 **ÉTAPES EXACTES POUR VOTRE SITUATION**

### **Votre URL Netlify :** `danwifi.netlify.app`
### **Votre domaine :** `danwifi.com`
### **Registrar :** Hostinger

---

## 🔧 **ÉTAPE 1 : Configuration DNS chez Hostinger**

### Accéder à la gestion DNS :
1. **Connectez-vous** à votre compte Hostinger
2. **Allez dans** "Domaines" 
3. **Cliquez sur** `danwifi.com`
4. **Trouvez** "Zone DNS" ou "Gestion DNS"

### Enregistrements DNS à ajouter :

```dns
Type    Nom/Host    Valeur/Points to           TTL
CNAME   www         danwifi.netlify.app        3600
CNAME   @           danwifi.netlify.app        3600
```

**Si CNAME @ ne fonctionne pas, utilisez :**
```dns
Type    Nom/Host    Valeur/Points to           TTL
A       @           75.2.60.5                  3600
A       @           99.83.190.102              3600
A       @           198.61.251.14              3600
A       @           198.61.251.15              3600
CNAME   www         danwifi.netlify.app        3600
```

### ⚠️ **IMPORTANT :**
- **Supprimez** tous les anciens enregistrements A ou CNAME pour `@` et `www`
- **Gardez** les enregistrements MX (email) si vous en avez

---

## 🌐 **ÉTAPE 2 : Configuration dans Netlify**

### Ajouter le domaine personnalisé :
1. **Dans Netlify** → Site settings → Domain management
2. **Cliquez** "Add custom domain"
3. **Tapez** : `danwifi.com`
4. **Cliquez** "Verify"
5. **Confirmez** que vous possédez le domaine

### Configuration automatique :
- ✅ **HTTPS** sera automatiquement activé
- ✅ **Certificat SSL** généré en 10-15 minutes
- ✅ **Redirection www** → danwifi.com automatique

---

## ⚡ **ÉTAPE 3 : Variables d'Environnement Production**

### Dans Netlify → Site settings → Environment variables :

```env
# URLs Production
VITE_APP_URL=https://danwifi.com
VITE_API_URL=https://api.danwifi.com
VITE_ENVIRONMENT=production
NODE_ENV=production

# VOS CLÉS TWILIO RÉELLES
VITE_TWILIO_ACCOUNT_SID=AC0df75c6532da8b51918d7739f3753818
VITE_TWILIO_AUTH_TOKEN=abe8115cb1779ebd923ea772967a10d7
VITE_TWILIO_API_KEY=SK1dc49c64b8ea59a3af7b7c88de79d884

# VOTRE CLÉ MERAKI RÉELLE
VITE_MERAKI_API_KEY=72917b6d6b83b835667cdb4efab91dae728f4858
VITE_MERAKI_ORG_ID=123456

# Services DanWiFi
VITE_VIRTUAL_NUMBERS_API_KEY=danwifi_live_api_key
VITE_WIFI_SERVICE_API_KEY=danwifi_live_wifi_key
```

---

## 🔍 **ÉTAPE 4 : Vérification**

### Timeline attendue :
- **0-30 minutes** : Configuration DNS
- **30 minutes-2h** : Propagation DNS
- **10-15 minutes** : Certificat SSL Netlify

### Tests à effectuer :
1. **Testez** : https://danwifi.com
2. **Testez** : https://www.danwifi.com (doit rediriger)
3. **Vérifiez** le certificat SSL (cadenas vert)
4. **Testez** l'application complète

### Outils de vérification :
```bash
# Vérifier DNS
nslookup danwifi.com

# Tester connectivité
ping danwifi.com

# Vérifier HTTPS
curl -I https://danwifi.com
```

---

## 📧 **ÉTAPE 5 : Configuration Email (Optionnel)**

### Pour recevoir des emails @danwifi.com :
```dns
Type    Nom/Host    Valeur/Points to              Priorité
MX      @           mail.hostinger.com            10
TXT     @           "v=spf1 include:_spf.hostinger.com ~all"
```

---

## 🚨 **DÉPANNAGE HOSTINGER**

### Problèmes courants :

#### "Enregistrement déjà existant"
- **Supprimez** l'ancien enregistrement d'abord
- **Puis** ajoutez le nouveau

#### "CNAME @ non supporté"
- **Utilisez** les enregistrements A à la place
- **Contactez** le support Hostinger

#### "Propagation lente"
- **Hostinger** peut prendre 2-24h
- **Testez** avec https://dnschecker.org/

#### "SSL Certificate pending"
- **Attendez** 15 minutes après configuration DNS
- **Vérifiez** que le domaine est bien ajouté dans Netlify

---

## 📋 **CHECKLIST COMPLÈTE**

### Chez Hostinger ✅
- [ ] **Connexion** au compte Hostinger
- [ ] **Accès** à la Zone DNS de danwifi.com
- [ ] **Suppression** des anciens enregistrements @ et www
- [ ] **Ajout** CNAME www → danwifi.netlify.app
- [ ] **Ajout** CNAME @ → danwifi.netlify.app (ou A records)
- [ ] **Sauvegarde** de la configuration

### Chez Netlify ✅
- [ ] **Site** danwifi.netlify.app fonctionnel
- [ ] **Domain management** → Add custom domain
- [ ] **danwifi.com** ajouté et vérifié
- [ ] **Variables d'environnement** configurées
- [ ] **Force HTTPS** activé

### Tests Finaux ✅
- [ ] **https://danwifi.com** accessible
- [ ] **https://www.danwifi.com** redirige vers danwifi.com
- [ ] **Certificat SSL** valide (cadenas vert)
- [ ] **Application** charge correctement
- [ ] **Services Twilio/Meraki** fonctionnels
- [ ] **Admin** accessible : admin@danwifi.com / admin123

---

## 🎯 **ACTIONS IMMÉDIATES**

### 1. Chez Hostinger (MAINTENANT)
```dns
Supprimez les anciens enregistrements pour @ et www
Ajoutez :
CNAME   www     danwifi.netlify.app
CNAME   @       danwifi.netlify.app
```

### 2. Chez Netlify (MAINTENANT)
- **Site settings** → **Domain management**
- **Add custom domain** → `danwifi.com`

### 3. Variables d'environnement (MAINTENANT)
- **Ajoutez** vos clés Twilio et Meraki dans Netlify

### 4. Test (DANS 30 MINUTES)
- **Testez** https://danwifi.com

---

## 📞 **SUPPORT**

### Si vous avez des problèmes :
- **Hostinger Support** : Chat 24/7 dans votre compte
- **Netlify Docs** : https://docs.netlify.com/domains-https/
- **DanWiFi Support** : support@danwifi.com

### Informations à partager si problème :
- Captures d'écran de la configuration DNS Hostinger
- Messages d'erreur exacts
- Résultats de `nslookup danwifi.com`

---

🚀 **Dans 2-4 heures maximum, votre DanWiFi sera accessible sur https://danwifi.com avec vos services Twilio et Meraki réels !**

**Voulez-vous que je vous guide étape par étape pendant que vous configurez ?**