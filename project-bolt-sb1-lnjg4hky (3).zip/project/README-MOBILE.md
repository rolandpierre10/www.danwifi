# 📱 Guide Mobile & Déploiement DanWiFi

## 🚀 Test sur Mobile

### Démarrage rapide
```bash
# Lancer le serveur de test mobile
npm run mobile-test
```

### Accès mobile manuel
1. **Démarrer le serveur :**
   ```bash
   npm run dev
   ```

2. **Trouver votre IP locale :**
   - Windows : `ipconfig`
   - Mac/Linux : `ifconfig` ou `ip addr`

3. **Accéder depuis mobile :**
   - Ouvrez `http://VOTRE_IP:5173` sur votre mobile
   - Exemple : `http://192.168.1.100:5173`

### 📲 Installation PWA

#### Android (Chrome/Edge)
1. Ouvrez l'app dans Chrome
2. Menu (⋮) → "Ajouter à l'écran d'accueil"
3. Ou attendez la notification automatique

#### iOS (Safari)
1. Ouvrez l'app dans Safari
2. Bouton partage (□↗) → "Sur l'écran d'accueil"
3. Confirmez l'ajout

## 🌐 Déploiement Production

### Préparation
```bash
# Vérifier et préparer le déploiement
npm run deploy-check
```

### Option 1 : Netlify (Recommandé)
1. **Connecter le repo :**
   - Allez sur [netlify.com](https://netlify.com)
   - "New site from Git" → Connectez GitHub
   - Sélectionnez votre repo DanWiFi

2. **Configuration build :**
   - Build command : `npm run build`
   - Publish directory : `dist`
   - Node version : `18`

3. **Variables d'environnement :**
   ```
   VITE_APP_URL=https://danwifi.com
   VITE_API_URL=https://api.danwifi.com
   VITE_STRIPE_PUBLISHABLE_KEY=pk_live_votre_cle
   VITE_PAYPAL_CLIENT_ID=votre_client_id
   ```

4. **Domaine personnalisé :**
   - Site settings → Domain management
   - Add custom domain : `danwifi.com`
   - Configurez les DNS selon les instructions

### Option 2 : Vercel
1. **Connecter le repo :**
   - Allez sur [vercel.com](https://vercel.com)
   - "New Project" → Import from GitHub

2. **Configuration automatique :**
   - Framework : Vite (détecté automatiquement)
   - Build command : `npm run build`
   - Output directory : `dist`

3. **Variables d'environnement :**
   - Settings → Environment Variables
   - Ajoutez les mêmes variables que Netlify

### Option 3 : Serveur VPS
```bash
# Build local
npm run build

# Upload vers serveur (exemple avec rsync)
rsync -avz dist/ user@votre-serveur.com:/var/www/danwifi/

# Configuration Apache/Nginx avec .htaccess fourni
```

## 🔧 Configuration DNS

### Enregistrements requis
```
Type    Nom                 Valeur
A       danwifi.com         IP_DE_VOTRE_SERVEUR
CNAME   www.danwifi.com     danwifi.com
CNAME   api.danwifi.com     votre-api-server.com
CNAME   cdn.danwifi.com     votre-cdn.com
```

### SSL/HTTPS
- **Netlify/Vercel :** SSL automatique
- **VPS :** Utilisez Let's Encrypt
  ```bash
  sudo certbot --apache -d danwifi.com -d www.danwifi.com
  ```

## 📱 Fonctionnalités Mobile

### PWA Features
- ✅ **Installation native** - Comme une vraie app
- ✅ **Mode hors ligne** - Fonctionne sans internet
- ✅ **Notifications push** - Alertes importantes
- ✅ **Écran de démarrage** - Logo et animation
- ✅ **Responsive design** - Optimisé pour tous écrans

### Test des fonctionnalités
1. **Responsive :**
   - Testez sur différentes tailles d'écran
   - Vérifiez les breakpoints Tailwind

2. **PWA :**
   - Installation depuis navigateur
   - Fonctionnement hors ligne
   - Icônes et splash screens

3. **Performance :**
   - Temps de chargement
   - Fluidité des animations
   - Consommation de données

## 🛠️ Debug Mobile

### Chrome DevTools
1. F12 → Toggle device toolbar
2. Sélectionnez un appareil mobile
3. Testez responsive et touch

### Safari Web Inspector (iOS)
1. Safari → Développement → Simulateur iOS
2. Inspectez votre app PWA

### Android Debug
1. Activez "Debug USB" sur Android
2. Chrome → `chrome://inspect`
3. Inspectez votre app mobile

## 📊 Performance Mobile

### Optimisations incluses
- **Code splitting** - Chargement par chunks
- **Lazy loading** - Composants à la demande
- **Image optimization** - Formats modernes
- **Caching** - Service Worker intelligent
- **Compression** - Gzip/Brotli activé

### Métriques à surveiller
- **FCP** (First Contentful Paint) < 1.8s
- **LCP** (Largest Contentful Paint) < 2.5s
- **FID** (First Input Delay) < 100ms
- **CLS** (Cumulative Layout Shift) < 0.1

## 🎯 Checklist Déploiement

### Avant déploiement
- [ ] Variables d'environnement configurées
- [ ] Build de production réussi
- [ ] Tests mobile effectués
- [ ] Performance vérifiée
- [ ] SEO optimisé

### Après déploiement
- [ ] DNS configuré correctement
- [ ] SSL/HTTPS actif
- [ ] PWA installable
- [ ] Mode hors ligne fonctionnel
- [ ] Analytics configuré

### Tests post-déploiement
- [ ] Accès depuis mobile
- [ ] Installation PWA
- [ ] Paiements Stripe/PayPal
- [ ] Formulaires tactiles
- [ ] Notifications push

## 🆘 Dépannage

### Problèmes courants
1. **App non accessible sur mobile :**
   - Vérifiez que mobile et PC sont sur même WiFi
   - Désactivez firewall temporairement
   - Utilisez IP locale, pas localhost

2. **PWA non installable :**
   - Vérifiez HTTPS (requis pour PWA)
   - Contrôlez manifest.json
   - Testez Service Worker

3. **Performance lente :**
   - Activez compression serveur
   - Optimisez images
   - Vérifiez cache headers

### Support
- **Email :** support@danwifi.com
- **Documentation :** [docs.danwifi.com](https://docs.danwifi.com)
- **Status :** [status.danwifi.com](https://status.danwifi.com)

---

🎉 **Votre application DanWiFi est maintenant prête pour mobile et production !**