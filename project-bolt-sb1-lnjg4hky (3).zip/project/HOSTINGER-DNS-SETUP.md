# 🌐 Configuration DNS Hostinger pour DanWiFi

## 🎯 **VOTRE SITUATION ACTUELLE**

- **Site Netlify :** https://gleeful-cactus-3709fa.netlify.app
- **Domaine :** danwifi.com (chez Hostinger)
- **Objectif :** Faire pointer danwifi.com vers votre site Netlify

---

## 📋 **ÉTAPES EXACTES CHEZ HOSTINGER**

### **Étape 1 : Accéder à la Gestion DNS**

1. **Connectez-vous** à votre compte Hostinger
2. **Allez dans** "Domaines" ou "Domains"
3. **Cliquez sur** `danwifi.com`
4. **Trouvez** "Gestion DNS" ou "DNS Zone" ou "DNS Management"

### **Étape 2 : Supprimer les Anciens Enregistrements**

**Supprimez TOUS les enregistrements existants pour :**
- `@` (domaine racine)
- `www`
- Tout enregistrement A ou CNAME pointant vers d'autres services

### **Étape 3 : Ajouter les Nouveaux Enregistrements DNS**

**Ajoutez exactement ces enregistrements :**

```dns
Type    Nom/Host        Valeur/Points to                        TTL
A       @               75.2.60.5                               3600
A       @               99.83.190.102                           3600
A       @               198.61.251.14                           3600
A       @               198.61.251.15                           3600
CNAME   www             gleeful-cactus-3709fa.netlify.app       3600
```

**⚠️ IMPORTANT :**
- `@` représente votre domaine racine (danwifi.com)
- Utilisez exactement l'URL Netlify : `gleeful-cactus-3709fa.netlify.app`
- TTL = 3600 (1 heure)

---

## 🌐 **ÉTAPE 4 : Configuration dans Netlify**

### **Ajouter le Domaine Personnalisé :**

1. **Allez sur** https://app.netlify.com/
2. **Cliquez** sur votre site "gleeful-cactus-3709fa"
3. **Site settings** → **Domain management**
4. **Cliquez** "Add custom domain"
5. **Tapez** : `danwifi.com`
6. **Cliquez** "Verify"
7. **Confirmez** que vous possédez le domaine

### **Vérifier la Configuration :**
- ✅ Primary domain : `danwifi.com`
- ✅ Domain alias : `www.danwifi.com` → redirects to `danwifi.com`
- ✅ HTTPS : Enabled (automatique)

---

## ⏰ **TEMPS D'ATTENTE**

- **Configuration DNS** : 5-10 minutes
- **Propagation** : 30 minutes à 2 heures
- **Certificat SSL** : 10-15 minutes après propagation DNS

---

## 🧪 **TESTS À EFFECTUER**

### **Après 30 minutes, testez :**

1. **https://danwifi.com** → Doit charger votre site
2. **https://www.danwifi.com** → Doit rediriger vers danwifi.com
3. **http://danwifi.com** → Doit rediriger vers https://danwifi.com

### **Outils de Vérification :**
- **DNS Checker :** https://dnschecker.org/ (tapez `danwifi.com`)
- **SSL Test :** https://www.ssllabs.com/ssltest/ (tapez `danwifi.com`)

---

## 🚨 **DÉPANNAGE HOSTINGER**

### **Si vous ne trouvez pas la gestion DNS :**
1. **Cherchez** "Zone DNS", "DNS Records", ou "Name Servers"
2. **Vérifiez** que vous êtes sur le bon domaine
3. **Contactez** le support Hostinger si nécessaire

### **Si les enregistrements ne s'ajoutent pas :**
1. **Vérifiez** que vous utilisez le bon format
2. **Essayez** d'ajouter un enregistrement à la fois
3. **Attendez** quelques minutes entre chaque ajout

### **Si "CNAME @ non supporté" :**
**Utilisez cette configuration alternative :**
```dns
Type    Nom/Host        Valeur/Points to                        TTL
A       @               75.2.60.5                               3600
A       @               99.83.190.102                           3600
A       @               198.61.251.14                           3600
A       @               198.61.251.15                           3600
CNAME   www             gleeful-cactus-3709fa.netlify.app       3600
```

---

## 📧 **CONFIGURATION EMAIL (Optionnel)**

### **Si vous voulez des emails @danwifi.com :**
```dns
Type    Nom/Host        Valeur/Points to                        Priorité
MX      @               mail.hostinger.com                      10
TXT     @               "v=spf1 include:_spf.hostinger.com ~all"
```

---

## 🎯 **RÉSUMÉ DES ACTIONS**

### **Chez Hostinger :**
1. ✅ Supprimer anciens DNS pour @ et www
2. ✅ Ajouter 4 enregistrements A pour @
3. ✅ Ajouter 1 enregistrement CNAME pour www
4. ✅ Sauvegarder la configuration

### **Chez Netlify :**
1. ✅ Ajouter danwifi.com comme domaine personnalisé
2. ✅ Vérifier que HTTPS est activé
3. ✅ Confirmer la redirection www → non-www

---

## 📞 **SUPPORT**

### **Si vous avez des problèmes :**
- **Hostinger Support :** Chat 24/7 dans votre compte
- **Question type :** "Comment configurer des enregistrements DNS pour pointer vers Netlify ?"

### **Informations à donner au support :**
- Domaine : danwifi.com
- Destination : gleeful-cactus-3709fa.netlify.app
- Type : Site web hébergé sur Netlify

---

## ✅ **CHECKLIST FINALE**

### **Avant de commencer :**
- [ ] Accès à votre compte Hostinger
- [ ] Accès à votre compte Netlify
- [ ] URL Netlify notée : `gleeful-cactus-3709fa.netlify.app`

### **Après configuration :**
- [ ] DNS configurés chez Hostinger
- [ ] Domaine ajouté dans Netlify
- [ ] Tests de fonctionnement réussis
- [ ] HTTPS activé et fonctionnel

---

🎉 **Dans 2-4 heures maximum, votre site DanWiFi sera accessible sur https://danwifi.com !**

**Avez-vous des questions sur une étape spécifique ?**