# 🔑 Guide Configuration des Clés API - Twilio & Meraki

## 🎯 **ÉTAPE 1 : Récupérer vos Clés Twilio**

### 1.1 Connexion à Twilio Console
1. **Allez sur :** https://console.twilio.com/
2. **Connectez-vous** avec vos identifiants Twilio
3. **Vérifiez** que vous êtes sur le bon compte/projet

### 1.2 Récupérer Account SID et Auth Token
1. **Sur la page d'accueil** de la console Twilio
2. **Trouvez la section "Account Info"** (en haut à droite)
3. **Copiez ces informations :**
   ```
   Account SID: ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
   Auth Token: xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
   ```
   ⚠️ **IMPORTANT :** Gardez l'Auth Token secret !

### 1.3 Créer une API Key (Recommandé)
1. **Allez dans :** Account → API Keys & Tokens
2. **Cliquez sur :** "Create API Key"
3. **Nom :** `DanWiFi Production`
4. **Type :** Standard
5. **Copiez :**
   ```
   API Key SID: SKxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
   API Secret: xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
   ```

### 1.4 Vérifier les Numéros Disponibles
1. **Allez dans :** Phone Numbers → Manage → Buy a number
2. **Vérifiez** les pays disponibles selon votre plan
3. **Notez** les types de numéros (mobile, fixe, toll-free)

---

## 📶 **ÉTAPE 2 : Récupérer vos Clés Meraki**

### 2.1 Connexion au Dashboard Meraki
1. **Allez sur :** https://dashboard.meraki.com/
2. **Connectez-vous** avec vos identifiants Cisco
3. **Sélectionnez** votre organisation

### 2.2 Activer l'API Meraki
1. **Allez dans :** Organization → Settings
2. **Trouvez :** "Dashboard API access"
3. **Cochez :** "Enable access to the Cisco Meraki Dashboard API"
4. **Cliquez :** "Save Changes"

### 2.3 Générer une Clé API
1. **Allez dans :** My Profile (en haut à droite)
2. **Section :** "API access"
3. **Cliquez :** "Generate API key"
4. **Copiez la clé :**
   ```
   API Key: xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
   ```
   ⚠️ **ATTENTION :** Cette clé ne s'affiche qu'une fois !

### 2.4 Récupérer l'Organization ID
1. **Dans l'URL** du dashboard, trouvez :
   ```
   https://dashboard.meraki.com/o/[ORG_ID]/manage/organization/overview
   ```
2. **Copiez** le numéro après `/o/` :
   ```
   Organization ID: 123456
   ```

### 2.5 Vérifier vos Réseaux
1. **Allez dans :** Network-wide → Configure → General
2. **Notez** vos Network IDs existants
3. **Vérifiez** que vous avez des points d'accès WiFi

---

## 🔧 **ÉTAPE 3 : Configuration du Fichier .env**

### 3.1 Créer le fichier .env
Créez un fichier `.env` à la racine de votre projet avec :

```bash
# ===== CONFIGURATION PRODUCTION DANWIFI =====

# URLs de Production
VITE_APP_NAME=DanWiFi
VITE_APP_URL=https://danwifi.com
VITE_API_URL=https://api.danwifi.com

# ===== VOS CLÉS TWILIO RÉELLES =====
VITE_TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
VITE_TWILIO_AUTH_TOKEN=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
VITE_TWILIO_API_KEY=SKxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
VITE_TWILIO_API_SECRET=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# ===== VOS CLÉS MERAKI RÉELLES =====
VITE_MERAKI_API_KEY=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
VITE_MERAKI_ORG_ID=123456

# ===== SERVICES DANWIFI =====
VITE_VIRTUAL_NUMBERS_API_KEY=danwifi_live_votre_cle_api_numeros_virtuels
VITE_WIFI_SERVICE_API_KEY=danwifi_live_votre_cle_api_wifi

# ===== PAIEMENTS (À CONFIGURER) =====
VITE_STRIPE_PUBLISHABLE_KEY=pk_live_votre_cle_stripe
VITE_PAYPAL_CLIENT_ID=votre_client_id_paypal_live

# ===== ENVIRONNEMENT =====
VITE_ENVIRONMENT=production
NODE_ENV=production
```

### 3.2 Remplacer les Valeurs
**Remplacez :**
- `ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx` → Votre Account SID Twilio
- `xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx` → Votre Auth Token Twilio  
- `SKxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx` → Votre API Key Twilio
- `xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx` → Votre clé API Meraki
- `123456` → Votre Organization ID Meraki

---

## 🧪 **ÉTAPE 4 : Test des Services**

### 4.1 Démarrer l'Application
```bash
npm run dev
```

### 4.2 Test Twilio
1. **Connectez-vous** en tant qu'admin : `admin@danwifi.com` / `admin123`
2. **Allez dans** l'administration
3. **Créez un numéro virtuel** de test
4. **Vérifiez** dans votre console Twilio que le numéro apparaît

### 4.3 Test Meraki
1. **Générez un code WiFi** dans l'interface
2. **Vérifiez** dans votre dashboard Meraki
3. **Cherchez** un nouveau réseau ou configuration

### 4.4 Vérification des Logs
**Ouvrez la console du navigateur (F12) et vérifiez :**
- Aucune erreur d'API
- Les appels vers Twilio/Meraki fonctionnent
- Les réponses sont correctes

---

## 🚨 **DÉPANNAGE COURANT**

### Erreur Twilio "Unauthorized"
- ✅ Vérifiez l'Account SID et Auth Token
- ✅ Assurez-vous que l'API Key est active
- ✅ Vérifiez les permissions de votre compte

### Erreur Meraki "Invalid API Key"
- ✅ Régénérez une nouvelle clé API
- ✅ Vérifiez que l'API est activée dans l'organisation
- ✅ Attendez 5-10 minutes après activation

### Erreur CORS
- ✅ Configurez les domaines autorisés dans Twilio
- ✅ Ajoutez `https://danwifi.com` dans les webhooks

### Numéros non disponibles
- ✅ Vérifiez votre plan Twilio
- ✅ Certains pays nécessitent une vérification d'identité
- ✅ Consultez la documentation Twilio par pays

---

## 🎯 **ÉTAPE 5 : Validation Complète**

### 5.1 Checklist Twilio ✅
- [ ] Account SID configuré
- [ ] Auth Token configuré  
- [ ] API Key créée et configurée
- [ ] Test de création de numéro réussi
- [ ] Test d'envoi SMS réussi
- [ ] Webhooks configurés (optionnel pour les tests)

### 5.2 Checklist Meraki ✅
- [ ] API activée dans l'organisation
- [ ] Clé API générée et configurée
- [ ] Organization ID récupéré
- [ ] Test de génération WiFi réussi
- [ ] Vérification dans le dashboard Meraki

### 5.3 Checklist Application ✅
- [ ] Fichier .env configuré
- [ ] Application démarre sans erreur
- [ ] Interface admin accessible
- [ ] Services réels fonctionnels
- [ ] Logs propres dans la console

---

## 🚀 **PROCHAINES ÉTAPES**

### 1. Backend API
**Vous devrez créer un backend à `https://api.danwifi.com` qui :**
- Gère l'authentification
- Fait le pont avec Twilio/Meraki
- Stocke les données utilisateurs
- Traite les webhooks

### 2. Webhooks Twilio
**Configurez dans votre console Twilio :**
- SMS Webhook : `https://api.danwifi.com/webhooks/twilio/sms`
- Voice Webhook : `https://api.danwifi.com/webhooks/twilio/voice`

### 3. Déploiement
**Options recommandées :**
- Netlify (frontend)
- Vercel (frontend)
- Railway/Render (backend)

---

## 📞 **SUPPORT**

**Si vous rencontrez des problèmes :**

### Documentation Officielle
- **Twilio :** https://www.twilio.com/docs
- **Meraki :** https://developer.cisco.com/meraki/

### Support DanWiFi
- **Email :** support@danwifi.com
- **Téléphone :** (514) 654-3767

### Logs Utiles
**Partagez ces informations en cas de problème :**
- Messages d'erreur de la console
- Codes de réponse HTTP
- Configuration (sans les clés secrètes !)

---

🎉 **Félicitations ! Vos services Twilio et Meraki sont maintenant intégrés à DanWiFi !**