# 🚨 Dépannage DNS : Cloudflare + Netlify

## 🔍 **ÉTAPE 1 : Vérifications Immédiates**

### Vérifier les Nameservers chez Hostinger
1. **Connectez-vous à Hostinger**
2. **Domaines** → **Gérer** → **danwifi.com**
3. **Vérifiez** que les nameservers sont bien :
   ```
   lars.ns.cloudflare.com
   paityn.ns.cloudflare.com
   ```
4. **Si ce n'est pas le cas**, changez-les maintenant

### Vérifier la Configuration Cloudflare
1. **Dashboard Cloudflare** → **danwifi.com**
2. **DNS** → **Records**
3. **Vérifiez** que vous avez exactement :

```dns
Type    Nom             Valeur              Proxy Status
A       danwifi.com     75.2.60.5           🟠 Proxied
A       danwifi.com     99.83.190.102       🟠 Proxied  
A       danwifi.com     198.61.251.14       🟠 Proxied
A       danwifi.com     198.61.251.15       🟠 Proxied
CNAME   www             danwifi.com         🟠 Proxied
```

**⚠️ IMPORTANT :** Le nuage orange doit être activé !

## 🔍 **ÉTAPE 2 : Tests de Diagnostic**

### Test 1 : Vérifier les Nameservers
Ouvrez un terminal et tapez :
```bash
nslookup -type=NS danwifi.com
```

**Résultat attendu :**
```
danwifi.com nameserver = lars.ns.cloudflare.com
danwifi.com nameserver = paityn.ns.cloudflare.com
```

### Test 2 : Vérifier la Résolution DNS
```bash
nslookup danwifi.com
```

**Résultat attendu :** Une IP de Cloudflare (pas Netlify)

### Test 3 : Vérifier la Propagation
Allez sur : https://dnschecker.org/
Tapez : `danwifi.com`
**Vérifiez** que la plupart des serveurs montrent les IPs Cloudflare

## 🔍 **ÉTAPE 3 : Configuration Netlify**

### Vérifier le Domaine dans Netlify
1. **Netlify Dashboard** → **Votre site**
2. **Site settings** → **Domain management**
3. **Vérifiez** que `danwifi.com` est listé
4. **Si pas listé**, cliquez "Add custom domain"

### Statut DNS dans Netlify
Le statut doit montrer :
- ✅ **danwifi.com** - External DNS
- ✅ **www.danwifi.com** - Redirects to danwifi.com

## 🚨 **PROBLÈMES COURANTS ET SOLUTIONS**

### Problème 1 : "Site not found" ou "Page not found"
**Solution :**
1. **Cloudflare** → **SSL/TLS** → **Overview**
2. **Changez** vers "Full" ou "Full (strict)"
3. **Attendez** 5 minutes

### Problème 2 : Redirection infinie
**Solution :**
1. **Cloudflare** → **SSL/TLS** → **Edge Certificates**
2. **Activez** "Always Use HTTPS"
3. **Cloudflare** → **Page Rules**
4. **Créez** une règle :
   - URL : `www.danwifi.com/*`
   - Setting : Forwarding URL (301)
   - Destination : `https://danwifi.com/$1`

### Problème 3 : Certificat SSL invalide
**Solution :**
1. **Cloudflare** → **SSL/TLS** → **Edge Certificates**
2. **Désactivez** puis **réactivez** "Universal SSL"
3. **Attendez** 15 minutes

### Problème 4 : DNS ne se propage pas
**Solution :**
1. **Cloudflare** → **DNS** → **Records**
2. **Supprimez** tous les enregistrements A et CNAME
3. **Recréez-les** un par un avec le proxy activé
4. **Attendez** 30 minutes

## 🔧 **SOLUTION ALTERNATIVE : Configuration Directe**

Si Cloudflare pose problème, voici une configuration directe :

### Option A : DNS Direct chez Hostinger
1. **Hostinger** → **Zone DNS**
2. **Supprimez** tous les A et CNAME
3. **Ajoutez** :
```dns
Type    Nom             Valeur              TTL
A       @               75.2.60.5           3600
A       @               99.83.190.102       3600
A       @               198.61.251.14       3600
A       @               198.61.251.15       3600
CNAME   www             danwifi.com         3600
```

### Option B : Utiliser les DNS Netlify
1. **Netlify** → **Domain management** → **DNS panel**
2. **Notez** les nameservers Netlify
3. **Hostinger** → Changez vers ces nameservers

## 🕐 **TIMELINE DE PROPAGATION**

- **Nameservers** : 2-48 heures
- **Enregistrements DNS** : 5 minutes - 2 heures
- **SSL Cloudflare** : 5-15 minutes
- **Propagation mondiale** : 24-48 heures

## 🧪 **TESTS FINAUX**

Une fois configuré, testez :

1. **https://danwifi.com** → Doit charger votre site
2. **https://www.danwifi.com** → Doit rediriger vers danwifi.com
3. **http://danwifi.com** → Doit rediriger vers https://danwifi.com

## 📞 **SI RIEN NE FONCTIONNE**

### Informations à me donner :
1. **Résultat de** `nslookup danwifi.com`
2. **Capture d'écran** de vos DNS Cloudflare
3. **Capture d'écran** de vos nameservers Hostinger
4. **Message d'erreur exact** quand vous allez sur danwifi.com

### Contacts Support :
- **Hostinger** : Chat 24/7 dans votre compte
- **Cloudflare** : Support gratuit via dashboard
- **Netlify** : Documentation complète

---

## 🎯 **ACTION IMMÉDIATE**

**Faites ceci MAINTENANT :**

1. **Vérifiez** vos nameservers chez Hostinger
2. **Testez** `nslookup danwifi.com` 
3. **Envoyez-moi** le résultat

**Quelle est la première chose qui ne fonctionne pas ?**
- [ ] Les nameservers ne sont pas changés chez Hostinger
- [ ] Les DNS ne se propagent pas
- [ ] Le site charge mais avec des erreurs
- [ ] Autre problème (précisez)