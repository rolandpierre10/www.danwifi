# 🌐 Configuration DNS Hostinger → Netlify pour DanWiFi

## 🎯 **ÉTAPE 1 : Récupérer l'URL Netlify**

### Dans votre dashboard Netlify :
1. **Allez sur votre site** DanWiFi déployé
2. **Copiez l'URL** qui ressemble à :
   ```
   https://amazing-danwifi-123456.netlify.app
   ```
3. **Notez cette URL** - vous en aurez besoin !

---

## 🔧 **ÉTAPE 2 : Configuration DNS chez Hostinger**

### Accéder à la gestion DNS :
1. **Connectez-vous** à votre compte Hostinger
2. **Allez dans** "Domaines" ou "Domains"
3. **Cliquez sur** `danwifi.com`
4. **Trouvez** "Gestion DNS" ou "DNS Management"

### Ajouter les enregistrements DNS :

#### Option A : Avec CNAME (Recommandé)
```dns
Type    Nom/Host            Valeur/Points to                    TTL
CNAME   www                 amazing-danwifi-123456.netlify.app  3600
CNAME   @                   amazing-danwifi-123456.netlify.app  3600
```

#### Option B : Si CNAME @ ne fonctionne pas
```dns
Type    Nom/Host            Valeur/Points to                    TTL
A       @                   75.2.60.5                           3600
A       @                   99.83.190.102                       3600
A       @                   198.61.251.14                       3600
A       @                   198.61.251.15                       3600
CNAME   www                 amazing-danwifi-123456.netlify.app  3600
```

### Supprimer les anciens enregistrements :
- **Supprimez** tous les anciens enregistrements A ou CNAME pour `@` et `www`
- **Gardez** les enregistrements MX (email) si vous en avez

---

## 🌐 **ÉTAPE 3 : Configuration dans Netlify**

### Ajouter le domaine personnalisé :
1. **Dans Netlify** → Site settings → Domain management
2. **Cliquez** "Add custom domain"
3. **Tapez** : `danwifi.com`
4. **Cliquez** "Verify"
5. **Confirmez** que vous possédez le domaine

### Configurer HTTPS :
- **HTTPS** sera automatiquement activé
- **Attendez** 10-15 minutes pour le certificat SSL
- **Vérifiez** que "Force HTTPS" est activé

---

## 📧 **ÉTAPE 4 : Configuration Email (Optionnel)**

### Si vous voulez des emails @danwifi.com :
```dns
Type    Nom/Host            Valeur/Points to                    Priorité
MX      @                   mail.hostinger.com                  10
TXT     @                   "v=spf1 include:_spf.hostinger.com ~all"
```

---

## ⚡ **ÉTAPE 5 : Variables d'Environnement Netlify**

### Dans Netlify → Site settings → Environment variables :
```env
VITE_APP_URL=https://danwifi.com
VITE_API_URL=https://api.danwifi.com
VITE_ENVIRONMENT=production
NODE_ENV=production

# Vos clés Twilio
VITE_TWILIO_ACCOUNT_SID=AC0df75c6532da8b51918d7739f3753818
VITE_TWILIO_AUTH_TOKEN=abe8115cb1779ebd923ea772967a10d7
VITE_TWILIO_API_KEY=SK1dc49c64b8ea59a3af7b7c88de79d884

# Votre clé Meraki
VITE_MERAKI_API_KEY=72917b6d6b83b835667cdb4efab91dae728f4858
VITE_MERAKI_ORG_ID=123456

# Autres services
VITE_VIRTUAL_NUMBERS_API_KEY=danwifi_live_api_key
VITE_WIFI_SERVICE_API_KEY=danwifi_live_wifi_key
```

---

## 🔍 **ÉTAPE 6 : Vérification**

### Tests à effectuer :
1. **Attendez** 30 minutes à 2 heures pour la propagation DNS
2. **Testez** : https://danwifi.com
3. **Testez** : https://www.danwifi.com (doit rediriger)
4. **Vérifiez** le certificat SSL (cadenas vert)

### Outils de vérification :
- **DNS Checker** : https://dnschecker.org/
- **SSL Test** : https://www.ssllabs.com/ssltest/
- **Ping** : `ping danwifi.com`

---

## 🚨 **DÉPANNAGE HOSTINGER**

### "Enregistrement déjà existant"
- **Supprimez** l'ancien enregistrement d'abord
- **Puis** ajoutez le nouveau

### "CNAME @ non supporté"
- **Utilisez** les enregistrements A à la place
- **Contactez** le support Hostinger si nécessaire

### "Propagation lente"
- **Hostinger** peut prendre 2-24h pour la propagation
- **Utilisez** un VPN pour tester depuis d'autres pays

---

## 📋 **CHECKLIST HOSTINGER → NETLIFY**

### Chez Hostinger ✅
- [ ] **Connexion** au compte Hostinger
- [ ] **Accès** à la gestion DNS de danwifi.com
- [ ] **Suppression** des anciens enregistrements
- [ ] **Ajout** des nouveaux enregistrements CNAME/A
- [ ] **Sauvegarde** de la configuration

### Chez Netlify ✅
- [ ] **Site** déployé et fonctionnel
- [ ] **URL Netlify** récupérée
- [ ] **Domaine personnalisé** ajouté
- [ ] **Variables d'environnement** configurées
- [ ] **HTTPS** activé

### Tests Finaux ✅
- [ ] **https://danwifi.com** accessible
- [ ] **https://www.danwifi.com** redirige
- [ ] **Certificat SSL** valide
- [ ] **Application** fonctionne correctement
- [ ] **Services Twilio/Meraki** opérationnels

---

## 🎯 **ACTIONS IMMÉDIATES POUR VOUS**

### 1. Récupérez votre URL Netlify
**Dans votre dashboard Netlify, copiez l'URL complète**

### 2. Configurez DNS chez Hostinger
```dns
CNAME   www     votre-url.netlify.app
CNAME   @       votre-url.netlify.app
```

### 3. Ajoutez le domaine dans Netlify
**Site settings → Domain management → Add custom domain**

### 4. Configurez les variables d'environnement
**Ajoutez vos clés Twilio et Meraki dans Netlify**

---

## 📞 **SUPPORT SPÉCIFIQUE**

### Hostinger Support
- **Chat** : Disponible 24/7 dans votre compte
- **Email** : support@hostinger.com
- **Documentation** : https://support.hostinger.com/

### Questions Fréquentes Hostinger
- **Temps de propagation** : 2-24 heures
- **CNAME root** : Supporté sur la plupart des plans
- **SSL gratuit** : Inclus avec Netlify

---

🚀 **Dans 2-24 heures, votre DanWiFi sera accessible sur https://danwifi.com !**

**Quelle est l'URL exacte de votre site Netlify ?** Je peux vous donner les enregistrements DNS exacts à ajouter chez Hostinger.