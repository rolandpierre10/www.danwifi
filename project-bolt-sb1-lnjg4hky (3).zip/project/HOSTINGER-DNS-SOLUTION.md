# 🔧 Solution DNS Hostinger pour DanWiFi

## 🚨 **PROBLÈME IDENTIFIÉ**

Avec Hostinger, les enregistrements CNAME pour `@` (root domain) ne fonctionnent pas toujours. Voici la **solution qui marche** :

---

## ✅ **SOLUTION QUI FONCTIONNE**

### **Étape 1 : Supprimer les anciens enregistrements**
Dans votre Zone DNS Hostinger :
1. **Supprimez** l'enregistrement `CNAME @ danwifi.netlify.app`
2. **Supprimez** tous les anciens enregistrements A pour `@`
3. **Gardez** le `CNAME www danwifi.netlify.app`

### **Étape 2 : Ajouter les bons enregistrements**
```dns
Type    Nom/Host    Valeur/Points to           TTL
A       @           75.2.60.5                  3600
A       @           99.83.190.102              3600  
A       @           198.61.251.14              3600
A       @           198.61.251.15              3600
CNAME   www         danwifi.netlify.app        3600
```

### **Étape 3 : Vérification dans Hostinger**
Votre configuration DNS doit ressembler à :
```
@ (root)     A      75.2.60.5
@ (root)     A      99.83.190.102
@ (root)     A      198.61.251.14
@ (root)     A      198.61.251.15
www          CNAME  danwifi.netlify.app
```

---

## 🌐 **ÉTAPE 4 : Configuration Netlify**

### Dans Netlify → Site settings → Domain management :
1. **Add custom domain** → `danwifi.com`
2. **Verify** que vous possédez le domaine
3. **Attendez** que le statut passe à "Netlify DNS"

---

## ⚡ **ÉTAPE 5 : Variables d'Environnement**

### Dans Netlify → Environment variables :
```env
VITE_APP_URL=https://danwifi.com
VITE_API_URL=https://api.danwifi.com
VITE_ENVIRONMENT=production

# Vos clés Twilio
VITE_TWILIO_ACCOUNT_SID=AC0df75c6532da8b51918d7739f3753818
VITE_TWILIO_AUTH_TOKEN=abe8115cb1779ebd923ea772967a10d7
VITE_TWILIO_API_KEY=SK1dc49c64b8ea59a3af7b7c88de79d884

# Votre clé Meraki  
VITE_MERAKI_API_KEY=72917b6d6b83b835667cdb4efab91dae728f4858
```

---

## 🔍 **VÉRIFICATION**

### Tests dans 30-60 minutes :
```bash
# Test DNS
nslookup danwifi.com
# Doit retourner les IPs Netlify

# Test HTTPS
curl -I https://danwifi.com
# Doit retourner 200 OK

# Test redirection
curl -I https://www.danwifi.com
# Doit rediriger vers danwifi.com
```

---

## 🚨 **SI ÇA NE MARCHE TOUJOURS PAS**

### Option Alternative : Cloudflare (Gratuit)
1. **Créez** un compte Cloudflare gratuit
2. **Ajoutez** danwifi.com à Cloudflare
3. **Changez** les nameservers chez Hostinger vers Cloudflare
4. **Configurez** les DNS dans Cloudflare

### Nameservers Cloudflare typiques :
```
ava.ns.cloudflare.com
walt.ns.cloudflare.com
```

---

## 📋 **CHECKLIST IMMÉDIATE**

### À faire MAINTENANT chez Hostinger :
- [ ] **Supprimer** `CNAME @ danwifi.netlify.app`
- [ ] **Ajouter** les 4 enregistrements A pour `@`
- [ ] **Garder** `CNAME www danwifi.netlify.app`
- [ ] **Sauvegarder** la configuration

### À faire MAINTENANT chez Netlify :
- [ ] **Ajouter** danwifi.com comme domaine personnalisé
- [ ] **Configurer** les variables d'environnement
- [ ] **Vérifier** que Force HTTPS est activé

---

## 📞 **SUPPORT IMMÉDIAT**

### Si problème persiste :
- **Hostinger Chat** : Disponible 24/7 dans votre compte
- **Demandez** : "Comment configurer des enregistrements A pour pointer vers Netlify"
- **Mentionnez** : "CNAME root ne fonctionne pas"

---

🎯 **RÉSUMÉ : Utilisez des enregistrements A au lieu de CNAME pour le domaine root (@) avec Hostinger !**