# 🔥 Guide de Configuration des Services Réels DanWiFi

## 🎯 Vous avez Twilio et Meraki - Parfait !

Puisque vous possédez déjà des comptes **Twilio** et **Cisco Meraki**, voici comment configurer DanWiFi pour utiliser vos services réels.

## 📋 Étape 1 : Configuration Twilio

### 1.1 Récupérer vos clés Twilio
1. Connectez-vous à votre [Console Twilio](https://console.twilio.com/)
2. Allez dans **Account → API Keys & Tokens**
3. Notez ces informations :
   - **Account SID** : `ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`
   - **Auth Token** : `xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`
   - **API Key** (créez-en une si nécessaire)

### 1.2 Configurer les webhooks Twilio
Dans votre console Twilio, configurez ces webhooks :
- **SMS Webhook** : `https://api.danwifi.com/webhooks/twilio/sms`
- **Voice Webhook** : `https://api.danwifi.com/webhooks/twilio/voice`

## 📋 Étape 2 : Configuration Cisco Meraki

### 2.1 Récupérer votre clé API Meraki
1. Connectez-vous à votre [Dashboard Meraki](https://dashboard.meraki.com/)
2. Allez dans **Organization → Settings → Dashboard API access**
3. Activez l'API et générez une clé
4. Notez votre **Organization ID** dans l'URL

### 2.2 Préparer vos réseaux Meraki
- Assurez-vous d'avoir des points d'accès WiFi configurés
- Vérifiez que vous avez les permissions pour créer des réseaux
- Notez vos **Network IDs** existants si vous voulez les utiliser

## 📋 Étape 3 : Configuration des Variables d'Environnement

Créez un fichier `.env` avec vos vraies clés :

```bash
# ===== VOS COMPTES RÉELS =====

# Twilio (Votre compte existant)
VITE_TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
VITE_TWILIO_AUTH_TOKEN=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
VITE_TWILIO_API_KEY=SKxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# Cisco Meraki (Votre compte existant)
VITE_MERAKI_API_KEY=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
VITE_MERAKI_ORG_ID=123456

# Configuration DanWiFi
VITE_APP_URL=https://danwifi.com
VITE_API_URL=https://api.danwifi.com
VITE_ENVIRONMENT=production

# Paiements (à configurer)
VITE_STRIPE_PUBLISHABLE_KEY=pk_live_votre_cle_stripe
VITE_PAYPAL_CLIENT_ID=votre_client_id_paypal
```

## 📋 Étape 4 : Test des Services Réels

### 4.1 Test Twilio
```bash
# Démarrer l'application
npm run dev

# Dans l'interface admin ou utilisateur :
# 1. Créer un numéro virtuel
# 2. Envoyer un SMS de test
# 3. Vérifier dans la console Twilio
```

### 4.2 Test Meraki
```bash
# Dans l'interface :
# 1. Générer un code WiFi
# 2. Vérifier la création du réseau dans Meraki Dashboard
# 3. Tester la connexion WiFi
```

## 🔥 Fonctionnalités Réelles Activées

### 📞 Numéros Virtuels Twilio
- ✅ **Création automatique** de vrais numéros
- ✅ **SMS réels** envoyés/reçus via Twilio
- ✅ **Appels réels** via Twilio Voice
- ✅ **Historique complet** des communications
- ✅ **Coûts en temps réel** depuis Twilio
- ✅ **Support 200+ pays** selon votre plan Twilio

### 📶 WiFi Sécurisé Meraki
- ✅ **Création automatique** de réseaux WiFi
- ✅ **SSID sécurisés** avec WPA3/AES-256
- ✅ **Analytics en temps réel** depuis Meraki
- ✅ **Gestion des appareils** connectés
- ✅ **Contrôle de bande passante**
- ✅ **Événements de sécurité**

## 🚀 Déploiement en Production

### 5.1 Backend API (Requis)
Vous devez déployer un backend à `https://api.danwifi.com` qui :
- Gère l'authentification des utilisateurs
- Stocke les données des numéros et codes WiFi
- Fait le pont entre votre frontend et Twilio/Meraki
- Gère les webhooks Twilio

### 5.2 Exemple d'endpoints backend requis :
```
POST /virtual-numbers/create
POST /virtual-numbers/{id}/sms
POST /virtual-numbers/{id}/call
DELETE /virtual-numbers/{id}

POST /wifi/generate
GET /wifi/{id}/analytics
POST /wifi/{id}/revoke
PUT /wifi/{id}/settings

POST /webhooks/twilio/sms
POST /webhooks/twilio/voice
```

## 💰 Coûts Réels

### Twilio (selon vos tarifs)
- **Numéros virtuels** : ~$1-3/mois par numéro
- **SMS** : ~$0.0075 par SMS
- **Appels** : ~$0.013/minute

### Cisco Meraki
- **Utilisation de votre infrastructure existante**
- **Pas de coûts supplémentaires** pour les codes WiFi
- **Analytics inclus** dans votre abonnement

## 🎯 Avantages de cette Configuration

✅ **Services 100% réels** - Pas de simulation
✅ **Vos comptes existants** - Pas de nouveaux frais
✅ **Intégration native** - APIs officielles
✅ **Scalabilité** - Selon vos plans Twilio/Meraki
✅ **Analytics complets** - Données réelles
✅ **Support professionnel** - Twilio + Meraki

## 🔧 Prochaines Étapes

1. **Configurez vos clés** dans le fichier `.env`
2. **Testez les services** en mode développement
3. **Déployez le backend** à `api.danwifi.com`
4. **Configurez les webhooks** Twilio
5. **Lancez en production** sur `danwifi.com`

**🎉 Votre DanWiFi sera alors 100% opérationnel avec de vrais services !**

---

## 📞 Support

Si vous avez des questions sur la configuration :
- **Email** : support@danwifi.com
- **Documentation Twilio** : https://www.twilio.com/docs
- **Documentation Meraki** : https://developer.cisco.com/meraki/