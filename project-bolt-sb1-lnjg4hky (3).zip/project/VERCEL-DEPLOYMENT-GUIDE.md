# 🚀 Guide Vercel : Déployer DanWiFi Maintenant

## 🎯 **ÉTAPE 1 : Vérification (30 secondes)**

Ouvrez un terminal dans votre projet DanWiFi et tapez :
```bash
npm run build
```

**✅ Si ça marche** → Continuez
**❌ Si erreur** → Dites-moi l'erreur

---

## 🌐 **ÉTAPE 2 : Créer Compte Vercel (1 minute)**

1. **Allez sur** https://vercel.com/
2. **Cliquez** "Sign Up"
3. **Choisissez** "Continue with GitHub"
4. **Autorisez** Vercel

---

## 🚀 **ÉTAPE 3 : Déployer (2 minutes)**

1. **Dashboard Vercel** → **"New Project"**
2. **Trouvez** votre repo DanWiFi
3. **Cliquez** "Import"
4. **Cliquez** "Deploy" (configuration automatique)
5. **Attendez** 2-3 minutes

**Vous obtiendrez :** `https://danwifi-abc123.vercel.app`

---

## 🌐 **ÉTAPE 4 : Ajouter danwifi.com (1 minute)**

1. **Votre projet** → **Settings** → **Domains**
2. **Tapez** `danwifi.com`
3. **Add**

**Vercel vous donne :**
```
A Record: @ → 76.76.19.61
CNAME: www → cname.vercel-dns.com
```

---

## 🔧 **ÉTAPE 5 : DNS Hostinger (3 minutes)**

1. **Hostinger** → **Domaines** → **danwifi.com** → **Gestion DNS**
2. **Supprimez** anciens A et CNAME pour @ et www
3. **Ajoutez** :
```
Type: A, Nom: @, Valeur: 76.76.19.61
Type: CNAME, Nom: www, Valeur: cname.vercel-dns.com
```

---

## ⏰ **ÉTAPE 6 : Attendre (30 min - 2h)**

**Testez après 30 minutes :**
- https://danwifi.com
- https://www.danwifi.com

---

## 🎉 **RÉSULTAT**

✅ **Site en ligne** sur https://danwifi.com
✅ **HTTPS automatique**
✅ **Déploiement automatique** depuis GitHub
✅ **Performance optimale**

---

## 🚨 **AIDE**

**Si problème :**
- Build échoue → Vérifiez `npm run build` local
- DNS ne marche pas → Attendez 2h
- Autre → Dites-moi l'erreur exacte

**COMMENCEZ MAINTENANT : https://vercel.com/**