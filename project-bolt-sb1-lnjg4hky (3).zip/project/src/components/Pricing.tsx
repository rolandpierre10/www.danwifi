import React, { useState } from 'react';
import { Check, Star, Shield, Globe, Phone, Wifi, MessageSquare } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { useSubscription } from '../contexts/SubscriptionContext';
import PaymentModal from './PaymentModal';

const Pricing: React.FC = () => {
  const { t } = useLanguage();
  const { isAuthenticated } = useAuth();
  const { plans, isLoading } = useSubscription();
  const [selectedPlan, setSelectedPlan] = useState('quarterly');
  const [paymentModal, setPaymentModal] = useState<{ isOpen: boolean; plan: any }>({
    isOpen: false,
    plan: null
  });

  const handleSelectPlan = async (plan: any) => {
    if (!isAuthenticated) {
      // Redirect to signup
      const signupButton = document.querySelector('[data-auth-signup]') as HTMLButtonElement;
      signupButton?.click();
      return;
    }

    // Open payment modal
    setPaymentModal({ isOpen: true, plan });
  };

  const getFeatureIcon = (feature: string) => {
    switch (feature) {
      case 'virtualNumbers':
        return <Phone size={16} className="text-blue-600" />;
      case 'sms':
        return <MessageSquare size={16} className="text-green-600" />;
      case 'wifi':
        return <Wifi size={16} className="text-purple-600" />;
      case 'security':
        return <Shield size={16} className="text-red-600" />;
      case 'global':
        return <Globe size={16} className="text-indigo-600" />;
      default:
        return <Check size={16} className="text-green-600" />;
    }
  };

  return (
    <>
      <section id="pricing" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              {t('pricing.title')}
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Des forfaits simples avec 1 numéro virtuel, SMS et appels illimités, et 1 code WiFi unique. 
              Disponible dans 200+ pays. Choisissez la durée qui vous convient.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {plans.map((plan) => (
              <div
                key={plan.id}
                className={`relative bg-white rounded-2xl shadow-lg border-2 transition-all duration-300 hover:shadow-xl hover:scale-105 ${
                  plan.popular 
                    ? 'border-red-500 ring-4 ring-red-100' 
                    : 'border-gray-200 hover:border-red-300'
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <div className="bg-red-600 text-white px-4 py-2 rounded-full text-sm font-semibold flex items-center space-x-1">
                      <Star size={16} fill="currentColor" />
                      <span>{t('pricing.popular')}</span>
                    </div>
                  </div>
                )}

                {plan.savings && (
                  <div className="absolute -top-2 -right-2 bg-green-500 text-white px-3 py-1 rounded-full text-xs font-semibold">
                    -{plan.savings}
                  </div>
                )}

                <div className="p-8">
                  <div className="text-center mb-8">
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">
                      {plan.name}
                    </h3>
                    <div className="mb-4">
                      <span className="text-4xl font-bold text-gray-900">
                        ${plan.price}
                      </span>
                      <span className="text-gray-600 ml-1">
                        {t('pricing.per_month')}
                      </span>
                    </div>
                    <p className="text-sm text-gray-500">
                      Facturé pour {plan.duration} mois
                    </p>
                  </div>

                  {/* Features */}
                  <div className="space-y-4 mb-8">
                    <div className="flex items-center space-x-3">
                      {getFeatureIcon('virtualNumbers')}
                      <span className="text-gray-700 text-sm">
                        1 numéro virtuel
                      </span>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      {getFeatureIcon('sms')}
                      <span className="text-gray-700 text-sm">
                        SMS illimités
                      </span>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <Phone size={16} className="text-orange-600" />
                      <span className="text-gray-700 text-sm">
                        Appels illimités
                      </span>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      {getFeatureIcon('wifi')}
                      <span className="text-gray-700 text-sm">
                        1 code WiFi unique
                      </span>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      {getFeatureIcon('global')}
                      <span className="text-gray-700 text-sm">
                        200+ pays disponibles
                      </span>
                    </div>

                    {plan.features.premiumNumbers && (
                      <div className="flex items-center space-x-3">
                        <Star size={16} className="text-yellow-600" />
                        <span className="text-gray-700 text-sm">Numéros premium</span>
                      </div>
                    )}

                    <div className="flex items-center space-x-3">
                      {getFeatureIcon('security')}
                      <span className="text-gray-700 text-sm">
                        Support {plan.features.priority === 'premium' ? 'Premium 24/7' : 
                                plan.features.priority === 'high' ? 'Prioritaire' : 'Standard'}
                      </span>
                    </div>

                    <div className="flex items-center space-x-3">
                      <Check size={16} className="text-green-600" />
                      <span className="text-gray-700 text-sm">Activation instantanée</span>
                    </div>

                    <div className="flex items-center space-x-3">
                      <Shield size={16} className="text-red-600" />
                      <span className="text-gray-700 text-sm">Chiffrement de bout en bout</span>
                    </div>
                  </div>

                  <button
                    onClick={() => handleSelectPlan(plan)}
                    disabled={isLoading}
                    className={`w-full py-3 rounded-lg font-semibold transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed ${
                      plan.popular
                        ? 'bg-red-600 text-white hover:bg-red-700 shadow-lg'
                        : 'bg-gray-100 text-gray-900 hover:bg-red-50 hover:text-red-600 border border-gray-200 hover:border-red-300'
                    }`}
                  >
                    {isLoading ? 'Chargement...' : 
                     isAuthenticated ? 'Choisir ce forfait' : 'Commencer maintenant'}
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Features Comparison */}
          <div className="mt-20">
            <h3 className="text-2xl font-bold text-gray-900 text-center mb-12">
              Comparaison détaillée des fonctionnalités
            </h3>
            
            <div className="bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Fonctionnalités</th>
                      {plans.map((plan) => (
                        <th key={plan.id} className="px-6 py-4 text-center text-sm font-semibold text-gray-900">
                          {plan.name}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    <tr>
                      <td className="px-6 py-4 text-sm font-medium text-gray-900">Numéros virtuels</td>
                      {plans.map((plan) => (
                        <td key={plan.id} className="px-6 py-4 text-center text-sm text-gray-600">
                          1
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="px-6 py-4 text-sm font-medium text-gray-900">SMS</td>
                      {plans.map((plan) => (
                        <td key={plan.id} className="px-6 py-4 text-center text-sm text-gray-600">
                          Illimités
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="px-6 py-4 text-sm font-medium text-gray-900">Appels vocaux</td>
                      {plans.map((plan) => (
                        <td key={plan.id} className="px-6 py-4 text-center text-sm text-gray-600">
                          Illimités
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="px-6 py-4 text-sm font-medium text-gray-900">Codes WiFi</td>
                      {plans.map((plan) => (
                        <td key={plan.id} className="px-6 py-4 text-center text-sm text-gray-600">
                          1 unique
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="px-6 py-4 text-sm font-medium text-gray-900">Pays disponibles</td>
                      {plans.map((plan) => (
                        <td key={plan.id} className="px-6 py-4 text-center text-sm text-gray-600">
                          200+
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="px-6 py-4 text-sm font-medium text-gray-900">Numéros premium</td>
                      {plans.map((plan) => (
                        <td key={plan.id} className="px-6 py-4 text-center">
                          {plan.features.premiumNumbers ? (
                            <Check size={20} className="mx-auto text-green-600" />
                          ) : (
                            <span className="text-gray-400">-</span>
                          )}
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="px-6 py-4 text-sm font-medium text-gray-900">Support</td>
                      {plans.map((plan) => (
                        <td key={plan.id} className="px-6 py-4 text-center text-sm text-gray-600">
                          {plan.features.priority === 'premium' ? 'Premium 24/7' : 
                           plan.features.priority === 'high' ? 'Prioritaire' : 'Standard'}
                        </td>
                      ))}
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Money back guarantee */}
          <div className="mt-16 text-center">
            <div className="bg-gray-50 rounded-2xl p-8 max-w-2xl mx-auto">
              <Shield size={48} className="mx-auto text-red-600 mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-4">
                Garantie Satisfait ou Remboursé
              </h3>
              <p className="text-gray-600">
                Essayez DanWiFi sans risque pendant 30 jours. 
                Si vous n'êtes pas entièrement satisfait, nous vous remboursons intégralement.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Payment Modal */}
      <PaymentModal
        isOpen={paymentModal.isOpen}
        onClose={() => setPaymentModal({ isOpen: false, plan: null })}
        plan={paymentModal.plan}
      />
    </>
  );
};

export default Pricing;