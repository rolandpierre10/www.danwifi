import React, { useState } from 'react';
import { X, CreditCard, Shield, Lock, CheckCircle, AlertCircle, Eye, EyeOff } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useSubscription } from '../contexts/SubscriptionContext';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  plan: {
    id: string;
    name: string;
    price: number;
    duration: number;
    currency: string;
  } | null;
}

const PaymentModal: React.FC<PaymentModalProps> = ({ isOpen, onClose, plan }) => {
  const { user } = useAuth();
  const { subscribeToPlan } = useSubscription();
  const [paymentMethod, setPaymentMethod] = useState<'stripe' | 'paypal'>('stripe');
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<'idle' | 'processing' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');
  const [showCVC, setShowCVC] = useState(false);
  
  const [cardData, setCardData] = useState({
    number: '',
    expiry: '',
    cvc: '',
    name: '',
    email: user?.email || '',
    address: '',
    city: '',
    postalCode: '',
    country: 'FR'
  });

  const [paypalData, setPaypalData] = useState({
    email: user?.email || '',
    password: ''
  });

  if (!isOpen || !plan) return null;

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = matches && matches[0] || '';
    const parts = [];
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    if (parts.length) {
      return parts.join(' ');
    } else {
      return v;
    }
  };

  const formatExpiry = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    if (v.length >= 2) {
      return v.substring(0, 2) + '/' + v.substring(2, 4);
    }
    return v;
  };

  const handleCardInputChange = (field: string, value: string) => {
    let formattedValue = value;
    
    if (field === 'number') {
      formattedValue = formatCardNumber(value);
    } else if (field === 'expiry') {
      formattedValue = formatExpiry(value);
    } else if (field === 'cvc') {
      formattedValue = value.replace(/[^0-9]/g, '').substring(0, 4);
    }
    
    setCardData(prev => ({ ...prev, [field]: formattedValue }));
  };

  const validateCard = () => {
    const errors = [];
    
    if (!cardData.number || cardData.number.replace(/\s/g, '').length < 13) {
      errors.push('Numéro de carte invalide');
    }
    
    if (!cardData.expiry || cardData.expiry.length !== 5) {
      errors.push('Date d\'expiration invalide');
    }
    
    if (!cardData.cvc || cardData.cvc.length < 3) {
      errors.push('Code CVC invalide');
    }
    
    if (!cardData.name.trim()) {
      errors.push('Nom du titulaire requis');
    }
    
    if (!cardData.email.trim()) {
      errors.push('Email requis');
    }
    
    return errors;
  };

  const handleStripePayment = async () => {
    const validationErrors = validateCard();
    if (validationErrors.length > 0) {
      setErrorMessage(validationErrors.join(', '));
      return;
    }

    setIsProcessing(true);
    setPaymentStatus('processing');
    setErrorMessage('');

    try {
      // Simulation d'un appel API réel vers votre backend
      const response = await fetch(`${import.meta.env.VITE_API_URL}/payments/process-card`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth-token')}`,
        },
        body: JSON.stringify({
          card: {
            number: cardData.number.replace(/\s/g, ''),
            expiry: cardData.expiry,
            cvc: cardData.cvc,
            name: cardData.name
          },
          billing: {
            email: cardData.email,
            address: cardData.address,
            city: cardData.city,
            postalCode: cardData.postalCode,
            country: cardData.country
          },
          amount: Math.round(plan.price * 1.2 * 100), // Prix avec TVA en centimes
          currency: plan.currency.toLowerCase(),
          planId: plan.id,
          userId: user?.id,
          metadata: {
            planName: plan.name,
            duration: plan.duration,
            userEmail: user?.email
          }
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Erreur lors du traitement du paiement');
      }

      const result = await response.json();
      
      if (result.success) {
        // Activer l'abonnement
        await subscribeToPlan(plan.id);
        setPaymentStatus('success');
        
        // Rediriger après 3 secondes
        setTimeout(() => {
          onClose();
          window.location.hash = '#dashboard';
        }, 3000);
      } else {
        throw new Error(result.error || 'Paiement refusé');
      }
    } catch (error) {
      setPaymentStatus('error');
      setErrorMessage(error instanceof Error ? error.message : 'Erreur lors du traitement du paiement');
    } finally {
      setIsProcessing(false);
    }
  };

  const handlePayPalPayment = async () => {
    if (!paypalData.email || !paypalData.password) {
      setErrorMessage('Email et mot de passe PayPal requis');
      return;
    }

    setIsProcessing(true);
    setPaymentStatus('processing');
    setErrorMessage('');

    try {
      // Simulation d'un appel API réel vers votre backend
      const response = await fetch(`${import.meta.env.VITE_API_URL}/payments/process-paypal`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth-token')}`,
        },
        body: JSON.stringify({
          paypal: {
            email: paypalData.email,
            password: paypalData.password
          },
          amount: plan.price * 1.2, // Prix avec TVA
          currency: plan.currency,
          planId: plan.id,
          userId: user?.id,
          description: `Abonnement DanWiFi - ${plan.name} (${plan.duration} mois)`
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Erreur lors du traitement du paiement PayPal');
      }

      const result = await response.json();
      
      if (result.success) {
        // Activer l'abonnement
        await subscribeToPlan(plan.id);
        setPaymentStatus('success');
        
        // Rediriger après 3 secondes
        setTimeout(() => {
          onClose();
          window.location.hash = '#dashboard';
        }, 3000);
      } else {
        throw new Error(result.error || 'Paiement PayPal refusé');
      }
    } catch (error) {
      setPaymentStatus('error');
      setErrorMessage(error instanceof Error ? error.message : 'Erreur lors du traitement du paiement PayPal');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (paymentMethod === 'stripe') {
      await handleStripePayment();
    } else {
      await handlePayPalPayment();
    }
  };

  const getCardType = (number: string) => {
    const num = number.replace(/\s/g, '');
    if (num.startsWith('4')) return 'Visa';
    if (num.startsWith('5') || num.startsWith('2')) return 'Mastercard';
    if (num.startsWith('3')) return 'American Express';
    return 'Carte bancaire';
  };

  const renderPaymentProcessing = () => (
    <div className="text-center py-8">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
      <h3 className="text-xl font-semibold text-gray-900 mb-2">Traitement du paiement...</h3>
      <p className="text-gray-600">
        Veuillez patienter pendant que nous traitons votre paiement.
        Ne fermez pas cette fenêtre.
      </p>
    </div>
  );

  const renderPaymentSuccess = () => (
    <div className="text-center py-8">
      <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
        <CheckCircle size={32} className="text-green-600" />
      </div>
      <h3 className="text-2xl font-bold text-gray-900 mb-2">Paiement réussi !</h3>
      <p className="text-gray-600 mb-4">
        Votre abonnement {plan.name} a été activé avec succès.
      </p>
      <p className="text-sm text-gray-500">
        Redirection vers votre tableau de bord dans quelques secondes...
      </p>
    </div>
  );

  const totalPrice = plan.price * 1.2; // Prix avec TVA
  const taxAmount = plan.price * 0.2; // TVA

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900">Finaliser le paiement</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors duration-200"
          >
            <X size={20} className="text-gray-500" />
          </button>
        </div>

        <div className="p-6">
          {paymentStatus === 'processing' ? (
            renderPaymentProcessing()
          ) : paymentStatus === 'success' ? (
            renderPaymentSuccess()
          ) : (
            <>
              {/* Plan Summary */}
              <div className="bg-gray-50 rounded-lg p-4 mb-6">
                <h3 className="font-semibold text-gray-900 mb-3">Récapitulatif de commande</h3>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Forfait {plan.name}</span>
                    <span className="font-semibold">${plan.price.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Durée</span>
                    <span className="text-gray-900">{plan.duration} mois</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">TVA (20%)</span>
                    <span className="text-gray-900">${taxAmount.toFixed(2)}</span>
                  </div>
                  <hr className="my-2" />
                  <div className="flex justify-between items-center font-bold text-lg">
                    <span>Total TTC</span>
                    <span className="text-red-600">${totalPrice.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              {/* Payment Method Selection */}
              <div className="mb-6">
                <h3 className="font-semibold text-gray-900 mb-4">Méthode de paiement</h3>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => setPaymentMethod('stripe')}
                    className={`p-4 border-2 rounded-lg transition-all duration-200 ${
                      paymentMethod === 'stripe'
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-center space-x-2">
                      <CreditCard size={20} className="text-blue-600" />
                      <span className="font-medium">Carte bancaire</span>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">Visa, Mastercard, etc.</p>
                  </button>

                  <button
                    onClick={() => setPaymentMethod('paypal')}
                    className={`p-4 border-2 rounded-lg transition-all duration-200 ${
                      paymentMethod === 'paypal'
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-center space-x-2">
                      <div className="w-5 h-5 bg-blue-600 rounded flex items-center justify-center">
                        <span className="text-white text-xs font-bold">P</span>
                      </div>
                      <span className="font-medium">PayPal</span>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">Compte PayPal</p>
                  </button>
                </div>
              </div>

              {/* Error Message */}
              {paymentStatus === 'error' && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
                  <div className="flex items-center space-x-2">
                    <AlertCircle size={16} className="text-red-600" />
                    <span className="text-red-700 font-medium">Erreur de paiement</span>
                  </div>
                  <p className="text-red-600 text-sm mt-1">{errorMessage}</p>
                </div>
              )}

              {/* Payment Form */}
              <form onSubmit={handleSubmit} className="space-y-6">
                {paymentMethod === 'stripe' ? (
                  <>
                    {/* Card Information */}
                    <div className="space-y-4">
                      <h4 className="font-medium text-gray-900">Informations de carte</h4>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Numéro de carte *
                        </label>
                        <div className="relative">
                          <input
                            type="text"
                            value={cardData.number}
                            onChange={(e) => handleCardInputChange('number', e.target.value)}
                            placeholder="1234 5678 9012 3456"
                            maxLength={19}
                            className="w-full px-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            required
                          />
                          <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-xs text-gray-500">
                            {cardData.number && getCardType(cardData.number)}
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Date d'expiration *
                          </label>
                          <input
                            type="text"
                            value={cardData.expiry}
                            onChange={(e) => handleCardInputChange('expiry', e.target.value)}
                            placeholder="MM/AA"
                            maxLength={5}
                            className="w-full px-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Code CVC *
                          </label>
                          <div className="relative">
                            <input
                              type={showCVC ? 'text' : 'password'}
                              value={cardData.cvc}
                              onChange={(e) => handleCardInputChange('cvc', e.target.value)}
                              placeholder="123"
                              maxLength={4}
                              className="w-full px-3 py-3 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                              required
                            />
                            <button
                              type="button"
                              onClick={() => setShowCVC(!showCVC)}
                              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                            >
                              {showCVC ? <EyeOff size={16} /> : <Eye size={16} />}
                            </button>
                          </div>
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Nom du titulaire *
                        </label>
                        <input
                          type="text"
                          value={cardData.name}
                          onChange={(e) => setCardData(prev => ({ ...prev, name: e.target.value }))}
                          placeholder="Nom tel qu'il apparaît sur la carte"
                          className="w-full px-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          required
                        />
                      </div>
                    </div>

                    {/* Billing Information */}
                    <div className="space-y-4">
                      <h4 className="font-medium text-gray-900">Adresse de facturation</h4>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Email *
                        </label>
                        <input
                          type="email"
                          value={cardData.email}
                          onChange={(e) => setCardData(prev => ({ ...prev, email: e.target.value }))}
                          placeholder="votre@email.com"
                          className="w-full px-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Adresse
                        </label>
                        <input
                          type="text"
                          value={cardData.address}
                          onChange={(e) => setCardData(prev => ({ ...prev, address: e.target.value }))}
                          placeholder="123 Rue de la Paix"
                          className="w-full px-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Ville
                          </label>
                          <input
                            type="text"
                            value={cardData.city}
                            onChange={(e) => setCardData(prev => ({ ...prev, city: e.target.value }))}
                            placeholder="Paris"
                            className="w-full px-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Code postal
                          </label>
                          <input
                            type="text"
                            value={cardData.postalCode}
                            onChange={(e) => setCardData(prev => ({ ...prev, postalCode: e.target.value }))}
                            placeholder="75001"
                            className="w-full px-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          />
                        </div>
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    {/* PayPal Login */}
                    <div className="space-y-4">
                      <h4 className="font-medium text-gray-900">Connexion PayPal</h4>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Email PayPal *
                        </label>
                        <input
                          type="email"
                          value={paypalData.email}
                          onChange={(e) => setPaypalData(prev => ({ ...prev, email: e.target.value }))}
                          placeholder="votre@email.com"
                          className="w-full px-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Mot de passe PayPal *
                        </label>
                        <input
                          type="password"
                          value={paypalData.password}
                          onChange={(e) => setPaypalData(prev => ({ ...prev, password: e.target.value }))}
                          placeholder="••••••••"
                          className="w-full px-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          required
                        />
                      </div>
                    </div>
                  </>
                )}

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="w-full bg-red-600 text-white py-4 rounded-lg font-semibold hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200 flex items-center justify-center space-x-2"
                >
                  {isProcessing ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                      <span>Traitement en cours...</span>
                    </>
                  ) : (
                    <>
                      <Lock size={16} />
                      <span>Payer ${totalPrice.toFixed(2)} maintenant</span>
                    </>
                  )}
                </button>
              </form>

              {/* Security Notice */}
              <div className="mt-6 p-4 bg-green-50 rounded-lg">
                <div className="flex items-start space-x-2">
                  <Shield size={16} className="text-green-600 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-green-800">Paiement 100% sécurisé</p>
                    <p className="text-xs text-green-700 mt-1">
                      Vos données sont protégées par un chiffrement SSL 256 bits. 
                      Nous ne stockons aucune information de carte bancaire.
                    </p>
                  </div>
                </div>
              </div>

              {/* Terms */}
              <p className="text-xs text-gray-500 mt-4 text-center">
                En procédant au paiement, vous acceptez nos{' '}
                <a href="#" className="text-red-600 hover:underline">conditions d'utilisation</a>{' '}
                et notre{' '}
                <a href="#" className="text-red-600 hover:underline">politique de confidentialité</a>.
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default PaymentModal;