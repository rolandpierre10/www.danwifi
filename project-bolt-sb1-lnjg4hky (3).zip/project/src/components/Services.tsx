import React from 'react';
import { Phone, MessageSquare, Wifi, Globe, Shield, Zap, ArrowRight } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const Services: React.FC = () => {
  const { t } = useLanguage();

  const services = [
    {
      icon: Phone,
      title: 'Numéros Virtuels',
      description: 'Obtenez un numéro de téléphone virtuel dans plus de 200 pays. SMS et appels illimités inclus.',
      color: 'red',
      features: ['200+ pays disponibles', 'Activation instantanée', 'SMS illimités', 'Appels illimités']
    },
    {
      icon: MessageSquare,
      title: 'SMS Illimités',
      description: 'Envoyez et recevez des SMS sans limite avec vos numéros virtuels dans le monde entier.',
      color: 'blue',
      features: ['SMS illimités', 'Réception garantie', 'Support multimédia', 'Historique complet']
    },
    {
      icon: Wifi,
      title: 'WiFi Sécurisé',
      description: 'Code WiFi unique lié à votre numéro virtuel pour une connexion sécurisée partout.',
      color: 'green',
      features: ['Code unique par numéro', 'Chiffrement WPA3', 'Accès sécurisé', 'Monitoring 24/7']
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      red: {
        bg: 'bg-red-100',
        text: 'text-red-600',
        border: 'border-red-200',
        hover: 'hover:border-red-300',
        button: 'bg-red-600 hover:bg-red-700'
      },
      blue: {
        bg: 'bg-blue-100',
        text: 'text-blue-600',
        border: 'border-blue-200',
        hover: 'hover:border-blue-300',
        button: 'bg-blue-600 hover:bg-blue-700'
      },
      green: {
        bg: 'bg-green-100',
        text: 'text-green-600',
        border: 'border-green-200',
        hover: 'hover:border-green-300',
        button: 'bg-green-600 hover:bg-green-700'
      }
    };
    return colors[color as keyof typeof colors];
  };

  const handleLearnMore = (serviceTitle: string) => {
    // Scroll to pricing section
    const pricingElement = document.getElementById('pricing');
    if (pricingElement) {
      pricingElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Nos Services Premium
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Découvrez notre gamme complète de services de télécommunications virtuelles, 
            conçus pour répondre à tous vos besoins de connexion mondiale.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const colorClasses = getColorClasses(service.color);
            const Icon = service.icon;
            
            return (
              <div
                key={index}
                className={`bg-white rounded-2xl p-8 shadow-lg border-2 ${colorClasses.border} ${colorClasses.hover} transition-all duration-300 hover:shadow-xl hover:transform hover:scale-105 group`}
              >
                <div className={`${colorClasses.bg} w-16 h-16 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <Icon className={`h-8 w-8 ${colorClasses.text}`} />
                </div>
                
                <h3 className="text-2xl font-bold text-gray-900 mb-4">
                  {service.title}
                </h3>
                
                <p className="text-gray-600 mb-6 leading-relaxed">
                  {service.description}
                </p>
                
                <ul className="space-y-3 mb-8">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center space-x-3">
                      <div className={`w-2 h-2 rounded-full ${colorClasses.text.replace('text-', 'bg-')}`}></div>
                      <span className="text-gray-700 text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <button 
                  onClick={() => handleLearnMore(service.title)}
                  className={`w-full ${colorClasses.button} text-white py-3 rounded-lg font-semibold transition-all duration-200 flex items-center justify-center space-x-2 group`}
                >
                  <span>En Savoir Plus</span>
                  <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform duration-200" />
                </button>
              </div>
            );
          })}
        </div>

        {/* Additional features */}
        <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="bg-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
              <Globe className="h-8 w-8 text-red-600" />
            </div>
            <h4 className="text-xl font-semibold text-gray-900 mb-2">Couverture Mondiale</h4>
            <p className="text-gray-600">Services disponibles dans plus de 200 pays à travers le monde</p>
          </div>
          
          <div className="text-center">
            <div className="bg-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
              <Shield className="h-8 w-8 text-red-600" />
            </div>
            <h4 className="text-xl font-semibold text-gray-900 mb-2">Sécurité Avancée</h4>
            <p className="text-gray-600">Chiffrement de bout en bout et protection maximale de vos données</p>
          </div>
          
          <div className="text-center">
            <div className="bg-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
              <Zap className="h-8 w-8 text-red-600" />
            </div>
            <h4 className="text-xl font-semibold text-gray-900 mb-2">Activation Rapide</h4>
            <p className="text-gray-600">Vos services sont opérationnels en moins de 2 minutes</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;