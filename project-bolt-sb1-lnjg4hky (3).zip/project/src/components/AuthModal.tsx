import React, { useState } from 'react';
import { X, Mail, Lock, User, Eye, EyeOff, Phone, MapPin, Building, Search, ChevronDown } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { countries, getCountriesByRegion, getPopularCountries, searchCountries } from '../data/countries';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'login' | 'signup' | 'partner';
}

const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, initialMode = 'login' }) => {
  const { login, signup } = useAuth();
  const { t } = useLanguage();
  const [mode, setMode] = useState<'login' | 'signup' | 'partner'>(initialMode);
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [countrySearch, setCountrySearch] = useState('');
  const [showCountryDropdown, setShowCountryDropdown] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState<typeof countries[0] | null>(null);
  
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    firstName: '',
    lastName: '',
    phone: '',
    company: '',
    country: '',
    agreeToTerms: false,
    agreeToPartnerTerms: false
  });

  const filteredCountries = searchCountries(countrySearch);
  const popularCountries = getPopularCountries();
  const countriesByRegion = getCountriesByRegion();

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      if (mode === 'login') {
        await login(formData.email, formData.password);
        onClose();
      } else {
        if (formData.password !== formData.confirmPassword) {
          setError('Les mots de passe ne correspondent pas');
          return;
        }
        
        if (mode === 'partner' && !formData.agreeToPartnerTerms) {
          setError('Vous devez accepter les conditions partenaires');
          return;
        }
        
        if (!formData.agreeToTerms) {
          setError('Vous devez accepter les conditions d\'utilisation');
          return;
        }

        if (!selectedCountry && mode !== 'login') {
          setError('Veuillez sélectionner votre pays');
          return;
        }

        const fullName = `${formData.firstName} ${formData.lastName}`;
        await signup(formData.email, formData.password, fullName, mode === 'partner' ? 'partner' : 'user');
        onClose();
      }
    } catch (err) {
      setError('Une erreur est survenue. Veuillez réessayer.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value
    }));
  };

  const handleCountrySelect = (country: typeof countries[0]) => {
    setSelectedCountry(country);
    setFormData(prev => ({ ...prev, country: country.name }));
    setCountrySearch(country.name);
    setShowCountryDropdown(false);
  };

  const renderCountrySection = (title: string, countryList: typeof countries) => {
    if (countryList.length === 0) return null;
    
    return (
      <div className="border-b border-gray-100 last:border-b-0">
        <div className="px-4 py-2 bg-gray-50 text-xs font-semibold text-gray-600 uppercase tracking-wider">
          {title}
        </div>
        {countryList.slice(0, title === 'Pays Populaires' ? 12 : 50).map((country) => (
          <button
            key={country.code}
            type="button"
            onClick={() => handleCountrySelect(country)}
            className="w-full text-left px-4 py-3 hover:bg-gray-50 flex items-center space-x-3 border-b border-gray-50 last:border-b-0 transition-colors duration-150"
          >
            <span className="text-lg">{country.flag}</span>
            <div className="flex-1 min-w-0">
              <span className="text-sm text-gray-900 truncate block">{country.name}</span>
            </div>
            <span className="text-xs text-gray-500 font-mono">{country.code}</span>
          </button>
        ))}
      </div>
    );
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900">
            {mode === 'login' ? 'Connexion' : mode === 'partner' ? 'Inscription Partenaire' : 'Inscription'}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors duration-200"
          >
            <X size={20} className="text-gray-500" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
              {error}
            </div>
          )}

          {/* Email */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Adresse Email
            </label>
            <div className="relative">
              <Mail size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                required
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all duration-200"
                placeholder="votre@email.com"
              />
            </div>
          </div>

          {/* Names for signup */}
          {mode !== 'login' && (
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Prénom
                </label>
                <div className="relative">
                  <User size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleInputChange}
                    required
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all duration-200"
                    placeholder="Prénom"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nom
                </label>
                <input
                  type="text"
                  name="lastName"
                  value={formData.lastName}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all duration-200"
                  placeholder="Nom"
                />
              </div>
            </div>
          )}

          {/* Phone for signup */}
          {mode !== 'login' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Téléphone
              </label>
              <div className="relative">
                <Phone size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  required
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all duration-200"
                  placeholder="+33 1 23 45 67 89"
                />
              </div>
            </div>
          )}

          {/* Company for partner */}
          {mode === 'partner' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nom de l'Entreprise
              </label>
              <div className="relative">
                <Building size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  name="company"
                  value={formData.company}
                  onChange={handleInputChange}
                  required
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all duration-200"
                  placeholder="Nom de votre entreprise"
                />
              </div>
            </div>
          )}

          {/* Country for signup */}
          {mode !== 'login' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Pays <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <MapPin size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 z-10" />
                <ChevronDown size={16} className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 z-10" />
                <input
                  type="text"
                  value={selectedCountry ? `${selectedCountry.flag} ${selectedCountry.name}` : countrySearch}
                  onChange={(e) => {
                    setCountrySearch(e.target.value);
                    setShowCountryDropdown(true);
                    if (!e.target.value) setSelectedCountry(null);
                  }}
                  onFocus={() => setShowCountryDropdown(true)}
                  placeholder="Rechercher et sélectionner votre pays..."
                  className="w-full pl-10 pr-10 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all duration-200 cursor-pointer"
                  readOnly={!!selectedCountry}
                />
                
                {showCountryDropdown && (
                  <>
                    <div 
                      className="fixed inset-0 z-40" 
                      onClick={() => setShowCountryDropdown(false)}
                    />
                    <div className="absolute top-full left-0 right-0 bg-white border border-gray-300 rounded-lg shadow-xl max-h-80 overflow-y-auto z-50 mt-1">
                      {/* Search Results */}
                      {countrySearch && filteredCountries.length > 0 && (
                        renderCountrySection('Résultats de Recherche', filteredCountries)
                      )}
                      
                      {/* Popular Countries */}
                      {!countrySearch && renderCountrySection('Pays Populaires', popularCountries)}
                      
                      {/* Countries by Region */}
                      {!countrySearch && Object.entries(countriesByRegion).map(([region, regionCountries]) => 
                        renderCountrySection(region, regionCountries)
                      )}
                      
                      {/* No Results */}
                      {countrySearch && filteredCountries.length === 0 && (
                        <div className="px-4 py-8 text-center text-gray-500">
                          <Search size={24} className="mx-auto mb-2 text-gray-400" />
                          <p className="text-sm">Aucun pays trouvé pour "{countrySearch}"</p>
                          <p className="text-xs text-gray-400 mt-1">Essayez avec un autre terme de recherche</p>
                        </div>
                      )}
                    </div>
                  </>
                )}
              </div>
              {selectedCountry && (
                <div className="mt-2 flex items-center space-x-2 text-sm text-gray-600">
                  <span>Pays sélectionné:</span>
                  <span className="font-medium">{selectedCountry.flag} {selectedCountry.name}</span>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedCountry(null);
                      setCountrySearch('');
                      setFormData(prev => ({ ...prev, country: '' }));
                    }}
                    className="text-red-600 hover:text-red-700 text-xs underline"
                  >
                    Changer
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Password */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Mot de Passe
            </label>
            <div className="relative">
              <Lock size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type={showPassword ? 'text' : 'password'}
                name="password"
                value={formData.password}
                onChange={handleInputChange}
                required
                className="w-full pl-10 pr-12 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all duration-200"
                placeholder="••••••••"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>
          </div>

          {/* Confirm Password for signup */}
          {mode !== 'login' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Confirmer le Mot de Passe
              </label>
              <div className="relative">
                <Lock size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  name="confirmPassword"
                  value={formData.confirmPassword}
                  onChange={handleInputChange}
                  required
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all duration-200"
                  placeholder="••••••••"
                />
              </div>
            </div>
          )}

          {/* Terms and Conditions */}
          {mode !== 'login' && (
            <div className="space-y-3">
              <label className="flex items-start space-x-3">
                <input
                  type="checkbox"
                  name="agreeToTerms"
                  checked={formData.agreeToTerms}
                  onChange={handleInputChange}
                  required
                  className="mt-1 w-4 h-4 text-red-600 border-gray-300 rounded focus:ring-red-500"
                />
                <span className="text-sm text-gray-600">
                  J'accepte les{' '}
                  <a href="#" className="text-red-600 hover:text-red-700 underline">
                    conditions d'utilisation
                  </a>{' '}
                  et la{' '}
                  <a href="#" className="text-red-600 hover:text-red-700 underline">
                    politique de confidentialité
                  </a>
                </span>
              </label>

              {mode === 'partner' && (
                <label className="flex items-start space-x-3">
                  <input
                    type="checkbox"
                    name="agreeToPartnerTerms"
                    checked={formData.agreeToPartnerTerms}
                    onChange={handleInputChange}
                    required
                    className="mt-1 w-4 h-4 text-red-600 border-gray-300 rounded focus:ring-red-500"
                  />
                  <span className="text-sm text-gray-600">
                    J'accepte les{' '}
                    <a href="#" className="text-red-600 hover:text-red-700 underline">
                      conditions spécifiques aux partenaires
                    </a>{' '}
                    et comprends que mon compte nécessite une validation administrative
                  </span>
                </label>
              )}
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-red-600 text-white py-3 rounded-lg font-semibold hover:bg-red-700 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? 'Chargement...' : (
              mode === 'login' ? 'Se Connecter' : 
              mode === 'partner' ? 'Demander un Partenariat' : 
              'Créer mon Compte'
            )}
          </button>

          {/* Mode Switch */}
          <div className="text-center space-y-2">
            {mode === 'login' ? (
              <>
                <p className="text-sm text-gray-600">
                  Pas encore de compte ?{' '}
                  <button
                    type="button"
                    onClick={() => setMode('signup')}
                    className="text-red-600 hover:text-red-700 font-medium"
                  >
                    Créer un compte
                  </button>
                </p>
                <p className="text-sm text-gray-600">
                  Vous êtes un professionnel ?{' '}
                  <button
                    type="button"
                    onClick={() => setMode('partner')}
                    className="text-red-600 hover:text-red-700 font-medium"
                  >
                    Devenir partenaire
                  </button>
                </p>
              </>
            ) : (
              <p className="text-sm text-gray-600">
                Déjà un compte ?{' '}
                <button
                  type="button"
                  onClick={() => setMode('login')}
                  className="text-red-600 hover:text-red-700 font-medium"
                >
                  Se connecter
                </button>
              </p>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};

export default AuthModal;