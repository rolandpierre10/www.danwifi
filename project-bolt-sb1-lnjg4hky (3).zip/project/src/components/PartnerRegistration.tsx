import React, { useState } from 'react';
import { 
  Building, 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  CreditCard, 
  FileText, 
  Shield, 
  DollarSign,
  CheckCircle,
  AlertCircle,
  Crown,
  Globe,
  Users,
  TrendingUp,
  X,
  ChevronDown,
  ChevronRight
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { countries, getPopularCountries, searchCountries } from '../data/countries';

interface PartnerRegistrationProps {
  isOpen: boolean;
  onClose: () => void;
}

const PartnerRegistration: React.FC<PartnerRegistrationProps> = ({ isOpen, onClose }) => {
  const { signup } = useAuth();
  const [currentStep, setCurrentStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [contractAccepted, setContractAccepted] = useState(false);
  const [partnerCode, setPartnerCode] = useState('');
  const [countrySearch, setCountrySearch] = useState('');
  const [showCountryDropdown, setShowCountryDropdown] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState<typeof countries[0] | null>(null);

  const [formData, setFormData] = useState({
    // Informations personnelles
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    
    // Informations entreprise
    companyName: '',
    companyAddress: '',
    companyCity: '',
    companyPostalCode: '',
    country: '',
    businessType: '',
    yearsInBusiness: '',
    
    // Informations financières
    cardNumber: '',
    cardExpiry: '',
    cardCVC: '',
    cardName: '',
    
    // Acceptations
    agreeToTerms: false,
    agreeToPartnerContract: false,
    agreeToPayment: false
  });

  const filteredCountries = searchCountries(countrySearch);
  const popularCountries = getPopularCountries();

  if (!isOpen) return null;

  const generatePartnerCode = () => {
    const timestamp = Date.now().toString(36).toUpperCase();
    const random = Math.random().toString(36).substr(2, 6).toUpperCase();
    return `DW-PARTNER-${timestamp}-${random}`;
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value
    }));
  };

  const handleCountrySelect = (country: typeof countries[0]) => {
    setSelectedCountry(country);
    setFormData(prev => ({ ...prev, country: country.name }));
    setCountrySearch(country.name);
    setShowCountryDropdown(false);
  };

  const validateStep = (step: number): boolean => {
    switch (step) {
      case 1:
        return !!(formData.firstName && formData.lastName && formData.email && formData.phone && formData.password && formData.confirmPassword && selectedCountry);
      case 2:
        return !!(formData.companyName && formData.companyAddress && formData.companyCity && formData.businessType);
      case 3:
        return !!(formData.cardNumber && formData.cardExpiry && formData.cardCVC && formData.cardName);
      case 4:
        return contractAccepted && formData.agreeToPartnerContract && formData.agreeToPayment;
      default:
        return false;
    }
  };

  const handleNext = () => {
    if (validateStep(currentStep)) {
      if (currentStep === 4) {
        handleSubmit();
      } else {
        setCurrentStep(currentStep + 1);
      }
    } else {
      setError('Veuillez remplir tous les champs requis');
    }
  };

  const handleSubmit = async () => {
    setError('');
    setIsLoading(true);

    try {
      if (formData.password !== formData.confirmPassword) {
        setError('Les mots de passe ne correspondent pas');
        return;
      }

      // Générer le code partenaire
      const code = generatePartnerCode();
      setPartnerCode(code);

      // Créer le compte partenaire
      const fullName = `${formData.firstName} ${formData.lastName}`;
      await signup(formData.email, formData.password, fullName, 'partner');

      // Sauvegarder les données partenaire (en production, envoyer à l'API)
      const partnerData = {
        ...formData,
        partnerCode: code,
        registrationDate: new Date().toISOString(),
        status: 'pending',
        annualFee: 1500,
        commissionRate: 8
      };

      localStorage.setItem(`partner_${code}`, JSON.stringify(partnerData));

      setCurrentStep(5); // Étape de confirmation
    } catch (err) {
      setError('Une erreur est survenue. Veuillez réessayer.');
    } finally {
      setIsLoading(false);
    }
  };

  const renderStep1 = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
          <User className="h-8 w-8 text-blue-600" />
        </div>
        <h3 className="text-xl font-semibold text-gray-900">Informations Personnelles</h3>
        <p className="text-gray-600">Vos informations de contact</p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Prénom *</label>
          <input
            type="text"
            name="firstName"
            value={formData.firstName}
            onChange={handleInputChange}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
            placeholder="Votre prénom"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Nom *</label>
          <input
            type="text"
            name="lastName"
            value={formData.lastName}
            onChange={handleInputChange}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
            placeholder="Votre nom"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Email *</label>
        <div className="relative">
          <Mail size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleInputChange}
            required
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
            placeholder="votre@email.com"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Téléphone *</label>
        <div className="relative">
          <Phone size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="tel"
            name="phone"
            value={formData.phone}
            onChange={handleInputChange}
            required
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
            placeholder="+33 1 23 45 67 89"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Pays *</label>
        <div className="relative">
          <MapPin size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 z-10" />
          <input
            type="text"
            value={selectedCountry ? `${selectedCountry.flag} ${selectedCountry.name}` : countrySearch}
            onChange={(e) => {
              setCountrySearch(e.target.value);
              setShowCountryDropdown(true);
              if (!e.target.value) setSelectedCountry(null);
            }}
            onFocus={() => setShowCountryDropdown(true)}
            placeholder="Rechercher votre pays..."
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
          />
          
          {showCountryDropdown && (
            <>
              <div className="fixed inset-0 z-40\" onClick={() => setShowCountryDropdown(false)} />
              <div className="absolute top-full left-0 right-0 bg-white border border-gray-300 rounded-lg shadow-xl max-h-60 overflow-y-auto z-50 mt-1">
                {(countrySearch ? filteredCountries : popularCountries).slice(0, 20).map((country) => (
                  <button
                    key={country.code}
                    type="button"
                    onClick={() => handleCountrySelect(country)}
                    className="w-full text-left px-4 py-3 hover:bg-gray-50 flex items-center space-x-3"
                  >
                    <span className="text-lg">{country.flag}</span>
                    <span className="flex-1">{country.name}</span>
                    <span className="text-xs text-gray-500">{country.code}</span>
                  </button>
                ))}
              </div>
            </>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Mot de passe *</label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleInputChange}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
            placeholder="••••••••"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Confirmer mot de passe *</label>
          <input
            type="password"
            name="confirmPassword"
            value={formData.confirmPassword}
            onChange={handleInputChange}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
            placeholder="••••••••"
          />
        </div>
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
          <Building className="h-8 w-8 text-green-600" />
        </div>
        <h3 className="text-xl font-semibold text-gray-900">Informations Entreprise</h3>
        <p className="text-gray-600">Détails de votre bureau d'assistance DanWiFi</p>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Nom de l'entreprise *</label>
        <input
          type="text"
          name="companyName"
          value={formData.companyName}
          onChange={handleInputChange}
          required
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
          placeholder="Nom de votre entreprise"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Adresse *</label>
        <input
          type="text"
          name="companyAddress"
          value={formData.companyAddress}
          onChange={handleInputChange}
          required
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
          placeholder="Adresse complète"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Ville *</label>
          <input
            type="text"
            name="companyCity"
            value={formData.companyCity}
            onChange={handleInputChange}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
            placeholder="Ville"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Code postal</label>
          <input
            type="text"
            name="companyPostalCode"
            value={formData.companyPostalCode}
            onChange={handleInputChange}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
            placeholder="Code postal"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Type d'activité *</label>
        <select
          name="businessType"
          value={formData.businessType}
          onChange={handleInputChange}
          required
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
        >
          <option value="">Sélectionner le type d'activité</option>
          <option value="telecommunications">Télécommunications</option>
          <option value="it_services">Services informatiques</option>
          <option value="retail">Commerce de détail</option>
          <option value="consulting">Conseil</option>
          <option value="other">Autre</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Années d'expérience</label>
        <select
          name="yearsInBusiness"
          value={formData.yearsInBusiness}
          onChange={handleInputChange}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
        >
          <option value="">Sélectionner</option>
          <option value="0-1">Moins d'1 an</option>
          <option value="1-3">1 à 3 ans</option>
          <option value="3-5">3 à 5 ans</option>
          <option value="5-10">5 à 10 ans</option>
          <option value="10+">Plus de 10 ans</option>
        </select>
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <div className="bg-yellow-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
          <CreditCard className="h-8 w-8 text-yellow-600" />
        </div>
        <h3 className="text-xl font-semibold text-gray-900">Carte de Crédit Valide</h3>
        <p className="text-gray-600">Nécessaire pour vendre des abonnements aux clients</p>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
        <div className="flex items-start space-x-3">
          <AlertCircle className="h-5 w-5 text-blue-600 mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-blue-800">Pourquoi une carte de crédit ?</h4>
            <p className="text-sm text-blue-700 mt-1">
              Votre carte sera utilisée pour traiter les paiements des clients qui n'ont pas de carte 
              ou qui ne maîtrisent pas l'informatique. Vous recevrez 8% de commission sur chaque vente.
            </p>
          </div>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Numéro de carte *</label>
        <input
          type="text"
          name="cardNumber"
          value={formData.cardNumber}
          onChange={handleInputChange}
          required
          placeholder="1234 5678 9012 3456"
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Date d'expiration *</label>
          <input
            type="text"
            name="cardExpiry"
            value={formData.cardExpiry}
            onChange={handleInputChange}
            required
            placeholder="MM/AA"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Code CVC *</label>
          <input
            type="text"
            name="cardCVC"
            value={formData.cardCVC}
            onChange={handleInputChange}
            required
            placeholder="123"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Nom sur la carte *</label>
        <input
          type="text"
          name="cardName"
          value={formData.cardName}
          onChange={handleInputChange}
          required
          placeholder="Nom tel qu'il apparaît sur la carte"
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
        />
      </div>

      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
        <div className="flex items-center space-x-2 mb-2">
          <Shield size={16} className="text-green-600" />
          <span className="text-sm font-medium text-green-800">Sécurité garantie</span>
        </div>
        <p className="text-sm text-green-700">
          Vos informations de carte sont chiffrées et sécurisées. Nous utilisons les mêmes 
          standards de sécurité que les banques.
        </p>
      </div>
    </div>
  );

  const renderStep4 = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
          <FileText className="h-8 w-8 text-red-600" />
        </div>
        <h3 className="text-xl font-semibold text-gray-900">Contrat de Partenariat DanWiFi</h3>
        <p className="text-gray-600">Code d'identifiant : <code className="bg-gray-100 px-2 py-1 rounded text-sm font-mono">{generatePartnerCode()}</code></p>
      </div>

      {/* Contrat de partenariat complet */}
      <div className="bg-white border-2 border-gray-300 rounded-xl p-6 max-h-80 overflow-y-auto">
        <div className="text-center mb-6">
          <h4 className="text-xl font-bold text-gray-900 mb-2">CONTRAT DE PARTENARIAT DANWIFI</h4>
          <div className="flex items-center justify-center space-x-4 text-sm text-gray-600">
            <span>📄 Document officiel</span>
            <span>🔒 Confidentiel</span>
            <span>⚖️ Juridiquement contraignant</span>
          </div>
        </div>
        
        <div className="space-y-6 text-sm text-gray-700 leading-relaxed">
          <div className="bg-blue-50 border-l-4 border-blue-400 p-4">
            <h5 className="font-bold text-blue-900 mb-2">📋 ARTICLE 1 - OBJET DU CONTRAT</h5>
            <p className="text-blue-800">
              Le présent contrat a pour objet de définir les conditions dans lesquelles le <strong>Partenaire</strong> 
              s'engage à créer et exploiter un <strong>bureau d\'assistance DanWiFi</strong> pour la vente et le support 
              des services de numéros virtuels et WiFi sécurisé dans sa région géographique.
            </p>
          </div>

          <div className="bg-green-50 border-l-4 border-green-400 p-4">
            <h5 className="font-bold text-green-900 mb-2">💰 ARTICLE 2 - CONDITIONS FINANCIÈRES</h5>
            <ul className="list-disc list-inside space-y-2 text-green-800">
              <li><strong>Cotisation annuelle :</strong> 1 500$ USD pour être opérationnel</li>
              <li><strong>Commission :</strong> 8% sur chaque abonnement client vendu</li>
              <li><strong>Paiement :</strong> Commission versée mensuellement</li>
              <li><strong>Carte de crédit :</strong> Obligatoire pour traiter les paiements clients</li>
            </ul>
          </div>

          <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
            <h5 className="font-bold text-yellow-900 mb-2">📋 ARTICLE 3 - OBLIGATIONS DU PARTENAIRE</h5>
            <ul className="list-disc list-inside space-y-2 text-yellow-800">
              <li>Maintenir un <strong>local professionnel</strong> et accueillant</li>
              <li>Respecter les <strong>standards de qualité DanWiFi</strong> dans tous les bureaux</li>
              <li>Posséder une <strong>carte de crédit valide</strong> pour traiter les paiements clients</li>
              <li>Fournir un <strong>support technique de qualité</strong> aux clients</li>
              <li>Maintenir la <strong>confidentialité des données</strong> clients</li>
              <li>Respecter la <strong>charte graphique</strong> et l'image de marque DanWiFi</li>
              <li>Former le personnel aux <strong>produits et services DanWiFi</strong></li>
              <li>Afficher clairement les <strong>tarifs et conditions</strong></li>
              <li>Respecter les horaires d'ouverture minimum : <strong>6h/jour, 5j/semaine</strong></li>
            </ul>
          </div>

          <div className="bg-purple-50 border-l-4 border-purple-400 p-4">
            <h5 className="font-bold text-purple-900 mb-2">🎯 ARTICLE 4 - SERVICES À FOURNIR</h5>
            <ul className="list-disc list-inside space-y-2 text-purple-800">
              <li><strong>Vente d'abonnements</strong> DanWiFi aux clients locaux</li>
              <li><strong>Support technique</strong> pour les numéros virtuels</li>
              <li><strong>Assistance WiFi</strong> et configuration des codes</li>
              <li><strong>Formation clients</strong> non-informaticiens</li>
              <li><strong>Gestion des paiements</strong> pour clients sans carte bancaire</li>
              <li><strong>Service après-vente</strong> et résolution de problèmes</li>
            </ul>
          </div>

          <div className="bg-red-50 border-l-4 border-red-400 p-4">
            <h5 className="font-bold text-red-900 mb-2">⚠️ ARTICLE 5 - CONDITIONS À RESPECTER</h5>
            <ul className="list-disc list-inside space-y-2 text-red-800">
              <li>Tenir un <strong>registre des ventes</strong> et interventions</li>
              <li>Participer aux <strong>formations DanWiFi</strong> obligatoires</li>
              <li>Respecter les <strong>procédures de sécurité</strong> des données</li>
              <li>Maintenir un <strong>niveau de service client</strong> élevé</li>
              <li>Signaler tout <strong>incident ou problème</strong> dans les 24h</li>
              <li>Utiliser uniquement les <strong>outils et logiciels</strong> approuvés</li>
            </ul>
          </div>

          <div className="bg-indigo-50 border-l-4 border-indigo-400 p-4">
            <h5 className="font-bold text-indigo-900 mb-2">🔍 ARTICLE 6 - VALIDATION ET ACTIVATION</h5>
            <p className="text-indigo-800">
              Le compte partenaire doit être <strong>validé manuellement</strong> par un administrateur DanWiFi 
              avant activation. Cette validation peut prendre <strong>2 à 5 jours ouvrés</strong>. 
              Une notification sera envoyée par email une fois le compte activé.
            </p>
          </div>

          <div className="bg-gray-50 border-l-4 border-gray-400 p-4">
            <h5 className="font-bold text-gray-900 mb-2">📞 ARTICLE 7 - SUPPORT ET FORMATION</h5>
            <ul className="list-disc list-inside space-y-2 text-gray-800">
              <li><strong>Formation initiale</strong> gratuite aux produits DanWiFi</li>
              <li><strong>Support technique 24/7</strong> pour les partenaires</li>
              <li><strong>Mises à jour régulières</strong> des procédures</li>
              <li><strong>Matériel marketing</strong> fourni par DanWiFi</li>
            </ul>
          </div>

          <div className="bg-orange-50 border-l-4 border-orange-400 p-4">
            <h5 className="font-bold text-orange-900 mb-2">⚖️ ARTICLE 8 - RÉSILIATION</h5>
            <p className="text-orange-800">
              Le contrat peut être résilié par l'une ou l'autre des parties avec un <strong>préavis de 30 jours</strong>. 
              En cas de manquement grave aux obligations, la résiliation peut être <strong>immédiate</strong>. 
              Les commissions dues restent acquises jusqu'à la date de résiliation.
            </p>
          </div>

          <div className="bg-teal-50 border-l-4 border-teal-400 p-4">
            <h5 className="font-bold text-teal-900 mb-2">🌍 ARTICLE 9 - TERRITOIRE ET EXCLUSIVITÉ</h5>
            <p className="text-teal-800">
              Le partenaire bénéficie d'une <strong>exclusivité territoriale</strong> dans un rayon de 25 km 
              autour de son bureau d'assistance, sous réserve de respecter les objectifs de vente minimums.
            </p>
          </div>

          <div className="bg-pink-50 border-l-4 border-pink-400 p-4">
            <h5 className="font-bold text-pink-900 mb-2">📊 ARTICLE 10 - OBJECTIFS ET PERFORMANCE</h5>
            <ul className="list-disc list-inside space-y-2 text-pink-800">
              <li><strong>Objectif minimum :</strong> 10 ventes par mois après 3 mois d'activité</li>
              <li><strong>Évaluation trimestrielle</strong> des performances</li>
              <li><strong>Bonus de performance</strong> pour dépassement d'objectifs</li>
              <li><strong>Plan d'amélioration</strong> en cas de sous-performance</li>
            </ul>
          </div>

          <div className="border-2 border-red-500 bg-red-50 p-4 rounded-lg">
            <h5 className="font-bold text-red-900 mb-2 text-center">⚖️ ACCEPTATION DU CONTRAT</h5>
            <p className="text-red-800 text-center">
              En cochant les cases ci-dessous, vous acceptez <strong>TOUS</strong> les termes et conditions 
              de ce contrat de partenariat DanWiFi et vous vous engagez à les respecter intégralement.
            </p>
          </div>
        </div>
      </div>

      {/* Cases d'acceptation */}
      <div className="space-y-4 bg-gray-50 p-6 rounded-xl border border-gray-200">
        <h4 className="font-semibold text-gray-900 mb-4">✅ Acceptation du Contrat</h4>
        
        <label className="flex items-start space-x-3 p-3 bg-white rounded-lg border border-gray-200 hover:bg-blue-50 cursor-pointer">
          <input
            type="checkbox"
            checked={contractAccepted}
            onChange={(e) => setContractAccepted(e.target.checked)}
            className="mt-1 w-5 h-5 text-red-600 border-gray-300 rounded focus:ring-red-500"
          />
          <div>
            <span className="text-sm font-medium text-gray-900">
              ✅ J'ai lu et j'accepte intégralement le contrat de partenariat DanWiFi
            </span>
            <p className="text-xs text-gray-600 mt-1">
              Je comprends tous les articles et m'engage à respecter toutes les conditions énumérées.
            </p>
          </div>
        </label>

        <label className="flex items-start space-x-3 p-3 bg-white rounded-lg border border-gray-200 hover:bg-green-50 cursor-pointer">
          <input
            type="checkbox"
            name="agreeToPartnerContract"
            checked={formData.agreeToPartnerContract}
            onChange={handleInputChange}
            className="mt-1 w-5 h-5 text-red-600 border-gray-300 rounded focus:ring-red-500"
          />
          <div>
            <span className="text-sm font-medium text-gray-900">
              🤝 Je m'engage à respecter toutes les obligations de partenaire
            </span>
            <p className="text-xs text-gray-600 mt-1">
              Y compris la qualité de service, les horaires, la formation du personnel et la confidentialité.
            </p>
          </div>
        </label>

        <label className="flex items-start space-x-3 p-3 bg-white rounded-lg border border-gray-200 hover:bg-yellow-50 cursor-pointer">
          <input
            type="checkbox"
            name="agreeToPayment"
            checked={formData.agreeToPayment}
            onChange={handleInputChange}
            className="mt-1 w-5 h-5 text-red-600 border-gray-300 rounded focus:ring-red-500"
          />
          <div>
            <span className="text-sm font-medium text-gray-900">
              💳 J'accepte les conditions financières (1 500$ + commission 8%)
            </span>
            <p className="text-xs text-gray-600 mt-1">
              Je comprends que ma carte de crédit sera utilisée pour traiter les paiements clients et que je recevrai 8% de commission.
            </p>
          </div>
        </label>
      </div>

      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <AlertCircle className="h-5 w-5 text-amber-600 mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-amber-800">⏳ Validation Administrative</h4>
            <p className="text-sm text-amber-700 mt-1">
              Votre demande de partenariat sera examinée par notre équipe dans les <strong>2-5 jours ouvrés</strong>. 
              Vous recevrez une notification par email une fois votre compte validé et activé avec votre code partenaire unique.
            </p>
          </div>
        </div>
      </div>
    </div>
  );

  const renderStep5 = () => (
    <div className="text-center space-y-6">
      <div className="bg-green-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto">
        <CheckCircle className="h-10 w-10 text-green-600" />
      </div>
      
      <div>
        <h3 className="text-2xl font-bold text-gray-900 mb-2">🎉 Demande de Partenariat Envoyée !</h3>
        <p className="text-gray-600">
          Votre demande de partenariat a été soumise avec succès.
        </p>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <h4 className="text-lg font-semibold text-blue-900 mb-3">🔑 Votre Code Partenaire Unique</h4>
        <div className="bg-white border-2 border-blue-300 rounded-lg p-4 mb-4">
          <code className="text-xl font-mono text-blue-800 font-bold">{partnerCode}</code>
        </div>
        <p className="text-sm text-blue-700">
          ⚠️ <strong>Conservez précieusement ce code !</strong> Il vous sera demandé lors de l'activation de votre compte partenaire.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="flex items-center justify-center space-x-2 mb-2">
            <Crown className="h-5 w-5 text-yellow-500" />
            <span className="font-medium">Statut</span>
          </div>
          <span className="text-yellow-600 font-semibold">En attente de validation</span>
        </div>
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="flex items-center justify-center space-x-2 mb-2">
            <DollarSign className="h-5 w-5 text-green-500" />
            <span className="font-medium">Commission</span>
          </div>
          <span className="text-green-600 font-semibold">8% par vente</span>
        </div>
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="flex items-center justify-center space-x-2 mb-2">
            <Users className="h-5 w-5 text-blue-500" />
            <span className="font-medium">Support</span>
          </div>
          <span className="text-blue-600 font-semibold">Formation incluse</span>
        </div>
      </div>

      <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
        <h5 className="font-semibold text-gray-900 mb-4">📋 Prochaines étapes :</h5>
        <ol className="text-sm text-gray-700 space-y-2 text-left">
          <li className="flex items-center space-x-2">
            <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">1</span>
            <span>Validation de votre demande par notre équipe (2-5 jours ouvrés)</span>
          </li>
          <li className="flex items-center space-x-2">
            <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">2</span>
            <span>Notification par email de l'activation avec instructions</span>
          </li>
          <li className="flex items-center space-x-2">
            <span className="bg-purple-100 text-purple-800 px-2 py-1 rounded-full text-xs font-medium">3</span>
            <span>Accès à votre espace partenaire personnalisé</span>
          </li>
          <li className="flex items-center space-x-2">
            <span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-medium">4</span>
            <span>Formation complète aux produits et services DanWiFi</span>
          </li>
          <li className="flex items-center space-x-2">
            <span className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs font-medium">5</span>
            <span>Ouverture officielle de votre bureau d'assistance DanWiFi</span>
          </li>
        </ol>
      </div>

      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
        <h5 className="font-semibold text-green-900 mb-2">📧 Email de confirmation envoyé</h5>
        <p className="text-sm text-green-700">
          Un email de confirmation a été envoyé à <strong>{formData.email}</strong> avec tous les détails 
          de votre demande et votre code partenaire.
        </p>
      </div>

      <button
        onClick={onClose}
        className="bg-red-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-red-700 transition-colors duration-200 flex items-center space-x-2 mx-auto"
      >
        <CheckCircle size={20} />
        <span>Fermer</span>
      </button>
    </div>
  );

  const renderProgressBar = () => (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-4">
        {[1, 2, 3, 4, 5].map((step) => (
          <div key={step} className="flex flex-col items-center">
            <div
              className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold border-2 transition-all duration-300 ${
                step < currentStep
                  ? 'bg-green-600 text-white border-green-600'
                  : step === currentStep
                  ? 'bg-red-600 text-white border-red-600'
                  : 'bg-gray-200 text-gray-500 border-gray-300'
              }`}
            >
              {step < currentStep ? '✓' : step}
            </div>
            <div className={`text-xs mt-2 font-medium ${
              step <= currentStep ? 'text-red-600' : 'text-gray-500'
            }`}>
              {step === 1 && 'Personnel'}
              {step === 2 && 'Entreprise'}
              {step === 3 && 'Paiement'}
              {step === 4 && 'Contrat'}
              {step === 5 && 'Confirmation'}
            </div>
          </div>
        ))}
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2">
        <div 
          className="bg-red-600 h-2 rounded-full transition-all duration-500"
          style={{ width: `${((currentStep - 1) / 4) * 100}%` }}
        ></div>
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[95vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 bg-gradient-to-r from-red-50 to-yellow-50">
          <div className="flex items-center space-x-3">
            <Crown className="h-8 w-8 text-yellow-500" />
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Devenir Partenaire DanWiFi</h2>
              <p className="text-gray-600">Créez votre bureau d'assistance et gagnez 8% de commission</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors duration-200"
          >
            <X size={24} className="text-gray-500" />
          </button>
        </div>

        <div className="p-6">
          {currentStep < 5 && renderProgressBar()}

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm mb-6 flex items-center space-x-2">
              <AlertCircle size={16} />
              <span>{error}</span>
            </div>
          )}

          {currentStep === 1 && renderStep1()}
          {currentStep === 2 && renderStep2()}
          {currentStep === 3 && renderStep3()}
          {currentStep === 4 && renderStep4()}
          {currentStep === 5 && renderStep5()}

          {currentStep < 5 && (
            <div className="flex justify-between mt-8 pt-6 border-t border-gray-200">
              <button
                onClick={() => setCurrentStep(Math.max(1, currentStep - 1))}
                disabled={currentStep === 1}
                className="px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200 flex items-center space-x-2"
              >
                <ChevronRight size={16} className="rotate-180" />
                <span>Précédent</span>
              </button>
              <button
                onClick={handleNext}
                disabled={isLoading || !validateStep(currentStep)}
                className="px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200 flex items-center space-x-2"
              >
                <span>
                  {isLoading ? 'Traitement...' : currentStep === 4 ? 'Soumettre la Demande' : 'Suivant'}
                </span>
                {!isLoading && <ChevronRight size={16} />}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PartnerRegistration;