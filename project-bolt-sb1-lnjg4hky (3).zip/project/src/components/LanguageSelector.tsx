import React, { useState } from 'react';
import { ChevronDown, Globe, Search, Users } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const LanguageSelector: React.FC = () => {
  const { currentLanguage, setLanguage, availableLanguages, searchLanguages } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredLanguages = searchLanguages(searchTerm);
  
  // Tri alphabétique des langues
  const sortedLanguages = [...(searchTerm ? filteredLanguages : availableLanguages)].sort((a, b) => 
    a.name.localeCompare(b.name)
  );

  const handleLanguageSelect = (language: typeof availableLanguages[0]) => {
    setLanguage(language);
    setIsOpen(false);
    setSearchTerm('');
  };

  const renderLanguageItem = (language: typeof availableLanguages[0]) => (
    <button
      key={language.code}
      onClick={() => handleLanguageSelect(language)}
      className={`w-full text-left px-3 py-2 hover:bg-gray-50 flex items-center justify-between border-b border-gray-50 last:border-b-0 transition-colors duration-150 ${
        currentLanguage.code === language.code ? 'bg-red-50 text-red-600' : 'text-gray-700'
      }`}
    >
      <div className="flex items-center space-x-2 flex-1 min-w-0">
        <span className="text-base flex-shrink-0">{language.flag}</span>
        <div className="flex-1 min-w-0">
          <div className="font-medium truncate text-sm">{language.name}</div>
          <div className="text-xs text-gray-500 truncate">{language.nativeName}</div>
          {language.speakers && (
            <div className="text-xs text-gray-400 flex items-center space-x-1">
              <Users size={8} />
              <span>{language.speakers}</span>
            </div>
          )}
        </div>
      </div>
      <div className="flex flex-col items-end space-y-1 flex-shrink-0">
        <span className="text-xs text-gray-400 uppercase font-mono">{language.code}</span>
        <span className="text-xs text-gray-400">{language.region}</span>
      </div>
    </button>
  );

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2 px-2 py-2 rounded-lg bg-white/10 hover:bg-white/20 transition-colors duration-200 text-white"
      >
        <Globe size={14} />
        <span className="text-sm font-medium hidden sm:inline">{currentLanguage.name}</span>
        <span className="text-sm font-medium sm:hidden">{currentLanguage.flag}</span>
        <ChevronDown size={14} className={`transform transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <>
          <div 
            className="fixed inset-0 z-40" 
            onClick={() => setIsOpen(false)}
          />
          <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-lg shadow-xl border border-gray-200 z-50 max-w-[calc(100vw-2rem)] max-h-[80vh] overflow-hidden">
            {/* Header */}
            <div className="p-3 border-b border-gray-200">
              <h3 className="text-base font-semibold text-gray-900 mb-2 flex items-center space-x-2">
                <Globe size={16} className="text-red-600" />
                <span>Choisir une langue</span>
              </h3>
              
              {/* Search */}
              <div className="relative">
                <Search size={14} className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Rechercher une langue..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-8 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent text-sm"
                />
              </div>
            </div>

            {/* Languages List */}
            <div className="max-h-80 overflow-y-auto">
              {sortedLanguages.length > 0 ? (
                <div>
                  {sortedLanguages.map(renderLanguageItem)}
                </div>
              ) : (
                <div className="px-3 py-6 text-center text-gray-500">
                  <Search size={20} className="mx-auto mb-2 text-gray-400" />
                  <p className="text-sm">Aucune langue trouvée pour "{searchTerm}"</p>
                  <p className="text-xs text-gray-400 mt-1">Essayez avec un autre terme de recherche</p>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="p-2 border-t border-gray-200 bg-gray-50 text-center">
              <p className="text-xs text-gray-500">
                {availableLanguages.length} langues disponibles • Actuelle: {currentLanguage.nativeName}
              </p>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default LanguageSelector;