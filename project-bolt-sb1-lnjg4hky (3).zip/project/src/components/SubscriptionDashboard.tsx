import React, { useState } from 'react';
import { 
  User, 
  Phone, 
  Wifi, 
  CreditCard, 
  Settings, 
  BarChart3, 
  Plus, 
  Copy, 
  Trash2, 
  MessageSquare, 
  PhoneCall, 
  Shield, 
  Globe, 
  Calendar,
  Crown,
  AlertCircle,
  Lock
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useSubscription } from '../contexts/SubscriptionContext';
import { countries, getPopularCountries } from '../data/countries';
import PaymentModal from './PaymentModal';

const SubscriptionDashboard: React.FC = () => {
  const { user, logout } = useAuth();
  const { 
    subscription, 
    plans, 
    virtualNumbers, 
    wifiCodes, 
    createVirtualNumber, 
    generateWiFiCode, 
    deleteVirtualNumber, 
    revokeWiFiCode,
    sendSMS,
    makeCall 
  } = useSubscription();

  const [activeTab, setActiveTab] = useState<'overview' | 'numbers' | 'wifi' | 'billing' | 'settings'>('overview');
  const [showCreateNumber, setShowCreateNumber] = useState(false);
  const [showCreateWiFi, setShowCreateWiFi] = useState(false);
  const [showSMSModal, setShowSMSModal] = useState<{ numberId: string; number: string } | null>(null);
  const [showCallModal, setShowCallModal] = useState<{ numberId: string; number: string } | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [paymentModal, setPaymentModal] = useState<{ isOpen: boolean; plan: any }>({
    isOpen: false,
    plan: null
  });

  // Vérifier si l'utilisateur a un abonnement actif
  const hasActiveSubscription = subscription && subscription.status === 'active';

  const handleCreateNumber = async (countryCode: string, type: 'mobile' | 'landline' | 'premium') => {
    if (!hasActiveSubscription) {
      alert('Vous devez avoir un abonnement actif pour créer un numéro virtuel.');
      return;
    }

    setIsLoading(true);
    try {
      await createVirtualNumber(countryCode, type);
      setShowCreateNumber(false);
      alert('Numéro virtuel créé avec succès !');
    } catch (error) {
      alert(error instanceof Error ? error.message : 'Erreur lors de la création du numéro');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateWiFi = async (virtualNumberId: string, location?: { country: string; city: string; venue?: string }) => {
    if (!hasActiveSubscription) {
      alert('Vous devez avoir un abonnement actif pour créer un code WiFi.');
      return;
    }

    setIsLoading(true);
    try {
      await generateWiFiCode(virtualNumberId, location);
      setShowCreateWiFi(false);
      alert('Code WiFi généré avec succès !');
    } catch (error) {
      alert(error instanceof Error ? error.message : 'Erreur lors de la génération du code WiFi');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectPlan = (plan: any) => {
    setPaymentModal({ isOpen: true, plan });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('Copié dans le presse-papiers !');
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('fr-FR');
  };

  const renderOverview = () => (
    <div className="space-y-6">
      {/* Status de l'abonnement */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-semibold text-gray-900">Statut de l'Abonnement</h3>
          {hasActiveSubscription ? (
            <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
              Actif
            </span>
          ) : (
            <span className="bg-red-100 text-red-800 px-3 py-1 rounded-full text-sm font-medium">
              Aucun abonnement
            </span>
          )}
        </div>

        {hasActiveSubscription ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{virtualNumbers.length}</div>
              <div className="text-sm text-gray-600">Numéros Virtuels</div>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">{wifiCodes.filter(w => w.status === 'active').length}</div>
              <div className="text-sm text-gray-600">Codes WiFi Actifs</div>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">
                {subscription.endDate ? Math.ceil((new Date(subscription.endDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24)) : 0}
              </div>
              <div className="text-sm text-gray-600">Jours Restants</div>
            </div>
          </div>
        ) : (
          <div className="text-center py-8">
            <Lock size={48} className="mx-auto text-gray-400 mb-4" />
            <h4 className="text-lg font-medium text-gray-900 mb-2">Aucun Abonnement Actif</h4>
            <p className="text-gray-600 mb-6">
              Vous devez souscrire à un forfait pour accéder aux services de numéros virtuels et codes WiFi.
            </p>
            <button
              onClick={() => setActiveTab('billing')}
              className="bg-red-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-red-700 transition-colors duration-200"
            >
              Choisir un Forfait
            </button>
          </div>
        )}
      </div>

      {/* Actions rapides - Conditionnées à l'abonnement */}
      {hasActiveSubscription && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="bg-blue-100 p-2 rounded-lg">
                <Phone className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900">Créer votre Numéro</h3>
            </div>
            <p className="text-gray-600 mb-4">
              Obtenez un numéro de téléphone virtuel dans le pays de votre choix avec SMS et appels illimités.
            </p>
            <button
              onClick={() => setShowCreateNumber(true)}
              disabled={virtualNumbers.length >= 1}
              className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200"
            >
              {virtualNumbers.length >= 1 ? 'Limite Atteinte (1/1)' : 'Créer un Numéro Virtuel'}
            </button>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="bg-green-100 p-2 rounded-lg">
                <Wifi className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900">Créer votre WiFi</h3>
            </div>
            <p className="text-gray-600 mb-4">
              Générez un code WiFi sécurisé unique lié à votre numéro virtuel pour une connexion protégée.
            </p>
            <button
              onClick={() => setShowCreateWiFi(true)}
              disabled={virtualNumbers.length === 0 || wifiCodes.filter(w => w.status === 'active').length >= virtualNumbers.length}
              className="w-full bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200"
            >
              {virtualNumbers.length === 0 
                ? 'Créez d\'abord un numéro' 
                : wifiCodes.filter(w => w.status === 'active').length >= virtualNumbers.length
                ? 'Limite Atteinte'
                : 'Générer un Code WiFi'
              }
            </button>
          </div>
        </div>
      )}

      {/* Message d'information si pas d'abonnement */}
      {!hasActiveSubscription && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-6">
          <div className="flex items-start space-x-3">
            <AlertCircle className="h-6 w-6 text-amber-600 mt-0.5" />
            <div>
              <h4 className="text-lg font-medium text-amber-800 mb-2">Abonnement Requis</h4>
              <p className="text-amber-700 mb-4">
                Pour créer des numéros virtuels et des codes WiFi, vous devez souscrire à l'un de nos forfaits. 
                Tous nos forfaits incluent :
              </p>
              <ul className="text-amber-700 space-y-1 mb-4">
                <li>• 1 numéro virtuel dans 200+ pays</li>
                <li>• SMS et appels illimités</li>
                <li>• 1 code WiFi sécurisé unique</li>
                <li>• Support technique 24/7</li>
              </ul>
              <button
                onClick={() => setActiveTab('billing')}
                className="bg-amber-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-amber-700 transition-colors duration-200"
              >
                Voir les Forfaits
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  const renderNumbers = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-semibold text-gray-900">Mes Numéros Virtuels</h3>
        {hasActiveSubscription && (
          <button
            onClick={() => setShowCreateNumber(true)}
            disabled={virtualNumbers.length >= 1}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200 flex items-center space-x-2"
          >
            <Plus size={16} />
            <span>Nouveau Numéro</span>
          </button>
        )}
      </div>

      {!hasActiveSubscription ? (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
          <Lock size={48} className="mx-auto text-gray-400 mb-4" />
          <h4 className="text-lg font-medium text-gray-900 mb-2">Abonnement Requis</h4>
          <p className="text-gray-600 mb-4">
            Souscrivez à un forfait pour créer et gérer vos numéros virtuels.
          </p>
          <button
            onClick={() => setActiveTab('billing')}
            className="bg-red-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-red-700 transition-colors duration-200"
          >
            Choisir un Forfait
          </button>
        </div>
      ) : virtualNumbers.length === 0 ? (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
          <Phone size={48} className="mx-auto text-gray-400 mb-4" />
          <h4 className="text-lg font-medium text-gray-900 mb-2">Aucun Numéro Virtuel</h4>
          <p className="text-gray-600 mb-4">
            Créez votre premier numéro virtuel pour commencer à utiliser nos services.
          </p>
          <button
            onClick={() => setShowCreateNumber(true)}
            className="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors duration-200"
          >
            Créer un Numéro
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {virtualNumbers.map((number) => (
            <div key={number.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <div className="flex items-center space-x-2 mb-2">
                    <span className="text-xl font-semibold text-gray-900">{number.number}</span>
                    <button
                      onClick={() => copyToClipboard(number.number)}
                      className="text-gray-400 hover:text-gray-600"
                    >
                      <Copy size={16} />
                    </button>
                  </div>
                  <div className="flex items-center space-x-4 text-sm text-gray-600">
                    <span>{number.country}</span>
                    <span className="capitalize">{number.type}</span>
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      number.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                    }`}>
                      {number.status}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => deleteVirtualNumber(number.id)}
                  className="text-red-400 hover:text-red-600"
                >
                  <Trash2 size={16} />
                </button>
              </div>

              <div className="flex space-x-3">
                <button
                  onClick={() => setShowSMSModal({ numberId: number.id, number: number.number })}
                  className="flex-1 bg-blue-50 text-blue-600 py-2 px-4 rounded-lg font-medium hover:bg-blue-100 transition-colors duration-200 flex items-center justify-center space-x-2"
                >
                  <MessageSquare size={16} />
                  <span>Envoyer SMS</span>
                </button>
                <button
                  onClick={() => setShowCallModal({ numberId: number.id, number: number.number })}
                  className="flex-1 bg-green-50 text-green-600 py-2 px-4 rounded-lg font-medium hover:bg-green-100 transition-colors duration-200 flex items-center justify-center space-x-2"
                >
                  <PhoneCall size={16} />
                  <span>Appeler</span>
                </button>
              </div>

              <div className="mt-4 text-xs text-gray-500">
                Créé le {formatDate(number.createdAt)} • Expire le {formatDate(number.expiresAt)}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  const renderWiFi = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-semibold text-gray-900">Mes Codes WiFi</h3>
        {hasActiveSubscription && virtualNumbers.length > 0 && (
          <button
            onClick={() => setShowCreateWiFi(true)}
            disabled={wifiCodes.filter(w => w.status === 'active').length >= virtualNumbers.length}
            className="bg-green-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200 flex items-center space-x-2"
          >
            <Plus size={16} />
            <span>Nouveau Code WiFi</span>
          </button>
        )}
      </div>

      {!hasActiveSubscription ? (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
          <Lock size={48} className="mx-auto text-gray-400 mb-4" />
          <h4 className="text-lg font-medium text-gray-900 mb-2">Abonnement Requis</h4>
          <p className="text-gray-600 mb-4">
            Souscrivez à un forfait pour créer et gérer vos codes WiFi sécurisés.
          </p>
          <button
            onClick={() => setActiveTab('billing')}
            className="bg-red-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-red-700 transition-colors duration-200"
          >
            Choisir un Forfait
          </button>
        </div>
      ) : virtualNumbers.length === 0 ? (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
          <Phone size={48} className="mx-auto text-gray-400 mb-4" />
          <h4 className="text-lg font-medium text-gray-900 mb-2">Numéro Virtuel Requis</h4>
          <p className="text-gray-600 mb-4">
            Vous devez d'abord créer un numéro virtuel pour générer un code WiFi.
          </p>
          <button
            onClick={() => setActiveTab('numbers')}
            className="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors duration-200"
          >
            Créer un Numéro
          </button>
        </div>
      ) : wifiCodes.length === 0 ? (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
          <Wifi size={48} className="mx-auto text-gray-400 mb-4" />
          <h4 className="text-lg font-medium text-gray-900 mb-2">Aucun Code WiFi</h4>
          <p className="text-gray-600 mb-4">
            Générez votre premier code WiFi sécurisé lié à votre numéro virtuel.
          </p>
          <button
            onClick={() => setShowCreateWiFi(true)}
            className="bg-green-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors duration-200"
          >
            Générer un Code WiFi
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {wifiCodes.map((wifi) => (
            <div key={wifi.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <div className="flex items-center space-x-2 mb-2">
                    <span className="text-lg font-semibold text-gray-900">{wifi.code}</span>
                    <button
                      onClick={() => copyToClipboard(wifi.code)}
                      className="text-gray-400 hover:text-gray-600"
                    >
                      <Copy size={16} />
                    </button>
                  </div>
                  <div className="space-y-1 text-sm text-gray-600">
                    <div>SSID: {wifi.ssid}</div>
                    <div className="flex items-center space-x-2">
                      <span>Mot de passe:</span>
                      <code className="bg-gray-100 px-2 py-1 rounded text-xs">{wifi.password}</code>
                      <button
                        onClick={() => copyToClipboard(wifi.password)}
                        className="text-gray-400 hover:text-gray-600"
                      >
                        <Copy size={14} />
                      </button>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <span className={`px-2 py-1 rounded-full text-xs ${
                    wifi.status === 'active' ? 'bg-green-100 text-green-800' : 
                    wifi.status === 'expired' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {wifi.status}
                  </span>
                  {wifi.status === 'active' && (
                    <button
                      onClick={() => revokeWiFiCode(wifi.id)}
                      className="text-red-400 hover:text-red-600"
                    >
                      <Trash2 size={16} />
                    </button>
                  )}
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Utilisation:</span>
                  <span className="font-medium">{wifi.usageCount}/{wifi.maxUsage} connexions</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                  <div 
                    className="bg-green-600 h-2 rounded-full" 
                    style={{ width: `${(wifi.usageCount / wifi.maxUsage) * 100}%` }}
                  ></div>
                </div>
              </div>

              <div className="mt-4 text-xs text-gray-500">
                Créé le {formatDate(wifi.createdAt)} • Expire le {formatDate(wifi.expiresAt)}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  const renderBilling = () => (
    <div className="space-y-6">
      <h3 className="text-xl font-semibold text-gray-900">Facturation & Abonnements</h3>

      {/* Abonnement actuel */}
      {hasActiveSubscription && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h4 className="text-lg font-semibold text-gray-900 mb-4">Abonnement Actuel</h4>
          <div className="flex justify-between items-center">
            <div>
              <div className="text-lg font-medium text-gray-900">
                Forfait {plans.find(p => p.id === subscription.planId)?.name}
              </div>
              <div className="text-sm text-gray-600">
                Expire le {formatDate(subscription.endDate)}
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-green-600">
                ${plans.find(p => p.id === subscription.planId)?.price}/mois
              </div>
              <div className="text-sm text-gray-600">
                {subscription.autoRenew ? 'Renouvellement automatique' : 'Pas de renouvellement'}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Plans disponibles */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h4 className="text-lg font-semibold text-gray-900 mb-6">
          {hasActiveSubscription ? 'Changer de Forfait' : 'Choisir un Forfait'}
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {plans.map((plan) => (
            <div
              key={plan.id}
              className={`border-2 rounded-xl p-4 transition-all duration-200 ${
                plan.popular 
                  ? 'border-red-500 ring-2 ring-red-100' 
                  : 'border-gray-200 hover:border-red-300'
              }`}
            >
              {plan.popular && (
                <div className="text-center mb-3">
                  <span className="bg-red-600 text-white px-3 py-1 rounded-full text-xs font-semibold">
                    Populaire
                  </span>
                </div>
              )}

              <div className="text-center mb-4">
                <h5 className="text-lg font-semibold text-gray-900 mb-2">{plan.name}</h5>
                <div className="text-2xl font-bold text-gray-900">${plan.price}</div>
                <div className="text-sm text-gray-600">pour {plan.duration} mois</div>
                {plan.savings && (
                  <div className="text-sm text-green-600 font-medium">Économisez {plan.savings}</div>
                )}
              </div>

              <div className="space-y-2 mb-4 text-sm">
                <div className="flex items-center space-x-2">
                  <Phone size={14} className="text-blue-600" />
                  <span>1 numéro virtuel</span>
                </div>
                <div className="flex items-center space-x-2">
                  <MessageSquare size={14} className="text-green-600" />
                  <span>SMS illimités</span>
                </div>
                <div className="flex items-center space-x-2">
                  <PhoneCall size={14} className="text-orange-600" />
                  <span>Appels illimités</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Wifi size={14} className="text-purple-600" />
                  <span>1 code WiFi unique</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Globe size={14} className="text-indigo-600" />
                  <span>200+ pays</span>
                </div>
              </div>

              <button
                onClick={() => handleSelectPlan(plan)}
                disabled={hasActiveSubscription && subscription.planId === plan.id}
                className={`w-full py-2 rounded-lg font-medium transition-colors duration-200 ${
                  hasActiveSubscription && subscription.planId === plan.id
                    ? 'bg-gray-100 text-gray-500 cursor-not-allowed'
                    : plan.popular
                    ? 'bg-red-600 text-white hover:bg-red-700'
                    : 'bg-gray-100 text-gray-900 hover:bg-red-50 hover:text-red-600'
                }`}
              >
                {hasActiveSubscription && subscription.planId === plan.id
                  ? 'Forfait Actuel'
                  : 'Choisir ce Forfait'
                }
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderSettings = () => (
    <div className="space-y-6">
      <h3 className="text-xl font-semibold text-gray-900">Paramètres du Compte</h3>
      
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h4 className="text-lg font-semibold text-gray-900 mb-4">Informations Personnelles</h4>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Nom</label>
            <input
              type="text"
              value={user?.name || ''}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              readOnly
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <input
              type="email"
              value={user?.email || ''}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              readOnly
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Rôle</label>
            <input
              type="text"
              value={user?.role === 'admin' ? 'Administrateur' : user?.role === 'partner' ? 'Partenaire' : 'Utilisateur'}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50"
              readOnly
            />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h4 className="text-lg font-semibold text-gray-900 mb-4">Actions du Compte</h4>
        <div className="space-y-3">
          <button className="w-full text-left px-4 py-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors duration-200">
            Changer le mot de passe
          </button>
          <button className="w-full text-left px-4 py-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors duration-200">
            Télécharger mes données
          </button>
          <button
            onClick={logout}
            className="w-full text-left px-4 py-3 border border-red-200 text-red-600 rounded-lg hover:bg-red-50 transition-colors duration-200"
          >
            Se déconnecter
          </button>
        </div>
      </div>
    </div>
  );

  const tabs = [
    { id: 'overview', label: 'Vue d\'ensemble', icon: BarChart3 },
    { id: 'numbers', label: 'Numéros Virtuels', icon: Phone },
    { id: 'wifi', label: 'Codes WiFi', icon: Wifi },
    { id: 'billing', label: 'Facturation', icon: CreditCard },
    { id: 'settings', label: 'Paramètres', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Tableau de Bord</h1>
              <p className="text-gray-600 mt-1">
                Bienvenue, {user?.name} 
                {user?.role === 'partner' && !user?.isApproved && (
                  <span className="ml-2 bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs">
                    En attente de validation
                  </span>
                )}
              </p>
            </div>
            <button
              onClick={() => window.location.hash = ''}
              className="text-red-600 hover:text-red-700 font-medium"
            >
              ← Retour à l'accueil
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="mb-8">
          <nav className="flex space-x-1 bg-white rounded-xl p-1 shadow-sm border border-gray-200">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex-1 flex items-center justify-center space-x-2 py-3 px-4 rounded-lg font-medium transition-all duration-200 ${
                    activeTab === tab.id
                      ? 'bg-red-600 text-white shadow-sm'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                  }`}
                >
                  <Icon size={18} />
                  <span className="hidden sm:inline">{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Content */}
        <div className="mb-8">
          {activeTab === 'overview' && renderOverview()}
          {activeTab === 'numbers' && renderNumbers()}
          {activeTab === 'wifi' && renderWiFi()}
          {activeTab === 'billing' && renderBilling()}
          {activeTab === 'settings' && renderSettings()}
        </div>
      </div>

      {/* Modals */}
      {/* Create Number Modal */}
      {showCreateNumber && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h3 className="text-xl font-semibold text-gray-900">Créer un Numéro Virtuel</h3>
              <button
                onClick={() => setShowCreateNumber(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                ×
              </button>
            </div>
            <div className="p-6">
              <CreateNumberForm onSubmit={handleCreateNumber} onCancel={() => setShowCreateNumber(false)} />
            </div>
          </div>
        </div>
      )}

      {/* Create WiFi Modal */}
      {showCreateWiFi && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h3 className="text-xl font-semibold text-gray-900">Générer un Code WiFi</h3>
              <button
                onClick={() => setShowCreateWiFi(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                ×
              </button>
            </div>
            <div className="p-6">
              <CreateWiFiForm 
                virtualNumbers={virtualNumbers}
                onSubmit={handleCreateWiFi} 
                onCancel={() => setShowCreateWiFi(false)} 
              />
            </div>
          </div>
        </div>
      )}

      {/* SMS Modal */}
      {showSMSModal && (
        <SMSModal
          numberId={showSMSModal.numberId}
          number={showSMSModal.number}
          onClose={() => setShowSMSModal(null)}
          onSend={sendSMS}
        />
      )}

      {/* Call Modal */}
      {showCallModal && (
        <CallModal
          numberId={showCallModal.numberId}
          number={showCallModal.number}
          onClose={() => setShowCallModal(null)}
          onCall={makeCall}
        />
      )}

      {/* Payment Modal */}
      <PaymentModal
        isOpen={paymentModal.isOpen}
        onClose={() => setPaymentModal({ isOpen: false, plan: null })}
        plan={paymentModal.plan}
      />
    </div>
  );
};

// Composant pour créer un numéro
const CreateNumberForm: React.FC<{
  onSubmit: (countryCode: string, type: 'mobile' | 'landline' | 'premium') => void;
  onCancel: () => void;
}> = ({ onSubmit, onCancel }) => {
  const [selectedCountry, setSelectedCountry] = useState('');
  const [numberType, setNumberType] = useState<'mobile' | 'landline' | 'premium'>('mobile');
  const [searchTerm, setSearchTerm] = useState('');

  const popularCountries = getPopularCountries();
  const filteredCountries = countries.filter(country =>
    country.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    country.code.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedCountry) {
      onSubmit(selectedCountry, numberType);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Rechercher un pays
        </label>
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Tapez le nom d'un pays..."
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Sélectionner un pays
        </label>
        <div className="max-h-48 overflow-y-auto border border-gray-300 rounded-lg">
          {(searchTerm ? filteredCountries : popularCountries).map((country) => (
            <button
              key={country.code}
              type="button"
              onClick={() => setSelectedCountry(country.code)}
              className={`w-full text-left px-3 py-2 hover:bg-gray-50 flex items-center space-x-3 ${
                selectedCountry === country.code ? 'bg-red-50 text-red-600' : ''
              }`}
            >
              <span className="text-lg">{country.flag}</span>
              <span className="flex-1">{country.name}</span>
              <span className="text-xs text-gray-500">{country.code}</span>
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Type de numéro
        </label>
        <div className="space-y-2">
          {[
            { value: 'mobile', label: 'Mobile', description: 'Numéro de téléphone mobile' },
            { value: 'landline', label: 'Fixe', description: 'Numéro de téléphone fixe' },
            { value: 'premium', label: 'Premium', description: 'Numéro premium avec fonctionnalités avancées' }
          ].map((type) => (
            <label key={type.value} className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
              <input
                type="radio"
                name="numberType"
                value={type.value}
                checked={numberType === type.value}
                onChange={(e) => setNumberType(e.target.value as any)}
                className="text-red-600 focus:ring-red-500"
              />
              <div>
                <div className="font-medium text-gray-900">{type.label}</div>
                <div className="text-sm text-gray-600">{type.description}</div>
              </div>
            </label>
          ))}
        </div>
      </div>

      <div className="flex space-x-3">
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors duration-200"
        >
          Annuler
        </button>
        <button
          type="submit"
          disabled={!selectedCountry}
          className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200"
        >
          Créer le Numéro
        </button>
      </div>
    </form>
  );
};

// Composant pour créer un code WiFi
const CreateWiFiForm: React.FC<{
  virtualNumbers: any[];
  onSubmit: (virtualNumberId: string, location?: { country: string; city: string; venue?: string }) => void;
  onCancel: () => void;
}> = ({ virtualNumbers, onSubmit, onCancel }) => {
  const [selectedNumberId, setSelectedNumberId] = useState('');
  const [location, setLocation] = useState({
    country: '',
    city: '',
    venue: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedNumberId) {
      const locationData = location.country && location.city ? {
        country: location.country,
        city: location.city,
        venue: location.venue || undefined
      } : undefined;
      
      onSubmit(selectedNumberId, locationData);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Numéro virtuel associé
        </label>
        <select
          value={selectedNumberId}
          onChange={(e) => setSelectedNumberId(e.target.value)}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
          required
        >
          <option value="">Sélectionner un numéro</option>
          {virtualNumbers.map((number) => (
            <option key={number.id} value={number.id}>
              {number.number} ({number.country})
            </option>
          ))}
        </select>
      </div>

      <div className="space-y-4">
        <h4 className="text-sm font-medium text-gray-700">Localisation (optionnel)</h4>
        
        <div>
          <label className="block text-xs text-gray-600 mb-1">Pays</label>
          <input
            type="text"
            value={location.country}
            onChange={(e) => setLocation(prev => ({ ...prev, country: e.target.value }))}
            placeholder="France"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
          />
        </div>

        <div>
          <label className="block text-xs text-gray-600 mb-1">Ville</label>
          <input
            type="text"
            value={location.city}
            onChange={(e) => setLocation(prev => ({ ...prev, city: e.target.value }))}
            placeholder="Paris"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
          />
        </div>

        <div>
          <label className="block text-xs text-gray-600 mb-1">Lieu (optionnel)</label>
          <input
            type="text"
            value={location.venue}
            onChange={(e) => setLocation(prev => ({ ...prev, venue: e.target.value }))}
            placeholder="Café, Hôtel, Bureau..."
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
          />
        </div>
      </div>

      <div className="flex space-x-3">
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors duration-200"
        >
          Annuler
        </button>
        <button
          type="submit"
          disabled={!selectedNumberId}
          className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200"
        >
          Générer le Code WiFi
        </button>
      </div>
    </form>
  );
};

// Composant pour envoyer un SMS
const SMSModal: React.FC<{
  numberId: string;
  number: string;
  onClose: () => void;
  onSend: (numberId: string, to: string, message: string) => Promise<boolean>;
}> = ({ numberId, number, onClose, onSend }) => {
  const [to, setTo] = useState('');
  const [message, setMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      const success = await onSend(numberId, to, message);
      if (success) {
        alert('SMS envoyé avec succès !');
        onClose();
      } else {
        alert('Erreur lors de l\'envoi du SMS');
      }
    } catch (error) {
      alert('Erreur lors de l\'envoi du SMS');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h3 className="text-xl font-semibold text-gray-900">Envoyer un SMS</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">×</button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">De</label>
            <input
              type="text"
              value={number}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50"
              readOnly
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">À</label>
            <input
              type="tel"
              value={to}
              onChange={(e) => setTo(e.target.value)}
              placeholder="+33 1 23 45 67 89"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Message</label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Votre message..."
              rows={4}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              required
            />
            <div className="text-xs text-gray-500 mt-1">{message.length}/160 caractères</div>
          </div>
          
          <div className="flex space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors duration-200"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 transition-colors duration-200"
            >
              {isLoading ? 'Envoi...' : 'Envoyer SMS'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// Composant pour passer un appel
const CallModal: React.FC<{
  numberId: string;
  number: string;
  onClose: () => void;
  onCall: (numberId: string, to: string) => Promise<boolean>;
}> = ({ numberId, number, onClose, onCall }) => {
  const [to, setTo] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      const success = await onCall(numberId, to);
      if (success) {
        alert('Appel initié avec succès !');
        onClose();
      } else {
        alert('Erreur lors de l\'initiation de l\'appel');
      }
    } catch (error) {
      alert('Erreur lors de l\'initiation de l\'appel');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h3 className="text-xl font-semibold text-gray-900">Passer un Appel</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">×</button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">De</label>
            <input
              type="text"
              value={number}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50"
              readOnly
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Appeler</label>
            <input
              type="tel"
              value={to}
              onChange={(e) => setTo(e.target.value)}
              placeholder="+33 1 23 45 67 89"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              required
            />
          </div>
          
          <div className="flex space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors duration-200"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 transition-colors duration-200"
            >
              {isLoading ? 'Appel...' : 'Appeler'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default SubscriptionDashboard;