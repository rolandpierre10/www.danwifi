import React, { useState } from 'react';
import { Wifi, Menu, X, Shield, Phone, BarChart3, Crown } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { useSubscription } from '../contexts/SubscriptionContext';
import LanguageSelector from './LanguageSelector';
import AuthModal from './AuthModal';
import PartnerRegistration from './PartnerRegistration';

const Header: React.FC = () => {
  const { t } = useLanguage();
  const { isAuthenticated, isAdmin, logout, user } = useAuth();
  const { subscription } = useSubscription();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [authModal, setAuthModal] = useState<{ isOpen: boolean; mode: 'login' | 'signup' | 'partner' }>({
    isOpen: false,
    mode: 'login'
  });
  const [partnerModal, setPartnerModal] = useState(false);

  const handleAuthClick = (mode: 'login' | 'signup' | 'partner') => {
    if (mode === 'partner') {
      setPartnerModal(true);
    } else {
      setAuthModal({ isOpen: true, mode });
    }
    setIsMenuOpen(false);
  };

  const handleLogout = () => {
    logout();
    setIsMenuOpen(false);
    window.location.hash = '';
  };

  const handleDashboardClick = () => {
    if (isAdmin) {
      window.location.hash = '#admin';
    } else {
      window.location.hash = '#dashboard';
    }
    setIsMenuOpen(false);
  };

  const handleAdminClick = () => {
    window.location.hash = '#admin';
    setIsMenuOpen(false);
  };

  return (
    <>
      <header className="bg-gradient-to-r from-red-600 to-red-500 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            {/* Logo */}
            <div className="flex items-center space-x-2">
              <div className="bg-white p-2 rounded-lg">
                <Wifi className="h-8 w-8 text-red-600" />
              </div>
              <span className="text-2xl font-bold text-white">{t('app.title')}</span>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-8">
              <a href="#home" className="text-white hover:text-red-200 transition-colors duration-200 font-medium">
                {t('nav.home')}
              </a>
              <a href="#services" className="text-white hover:text-red-200 transition-colors duration-200 font-medium">
                {t('nav.services')}
              </a>
              <a href="#pricing" className="text-white hover:text-red-200 transition-colors duration-200 font-medium">
                {t('nav.pricing')}
              </a>
              <a href="#partners" className="text-white hover:text-red-200 transition-colors duration-200 font-medium">
                {t('nav.partners')}
              </a>
              
              {isAuthenticated ? (
                <div className="flex items-center space-x-4">
                  <div className="text-white text-sm">
                    Bonjour, <span className="font-medium">{user?.name}</span>
                    {user?.role === 'partner' && !user?.isApproved && (
                      <span className="ml-2 bg-yellow-500 text-yellow-900 px-2 py-1 rounded-full text-xs">
                        En attente
                      </span>
                    )}
                    {subscription && (
                      <span className="ml-2 bg-green-500 text-green-900 px-2 py-1 rounded-full text-xs">
                        Abonné
                      </span>
                    )}
                  </div>
                  
                  {!isAdmin && (
                    <button
                      onClick={handleDashboardClick}
                      className="text-white hover:text-red-200 transition-colors duration-200 font-medium flex items-center space-x-1"
                    >
                      <BarChart3 size={16} />
                      <span>Tableau de Bord</span>
                    </button>
                  )}
                  
                  {isAdmin && (
                    <button
                      onClick={handleAdminClick}
                      className="text-white hover:text-red-200 transition-colors duration-200 font-medium flex items-center space-x-1"
                    >
                      <Shield size={16} />
                      <span>Administration</span>
                    </button>
                  )}
                  
                  <button
                    onClick={handleLogout}
                    className="bg-white text-red-600 px-4 py-2 rounded-lg font-medium hover:bg-red-50 transition-colors duration-200"
                  >
                    Déconnexion
                  </button>
                </div>
              ) : (
                <div className="flex items-center space-x-4">
                  <button
                    onClick={() => handleAuthClick('login')}
                    className="text-white hover:text-red-200 transition-colors duration-200 font-medium"
                  >
                    {t('nav.login')}
                  </button>
                  <button
                    onClick={() => handleAuthClick('signup')}
                    data-auth-signup
                    className="bg-white text-red-600 px-4 py-2 rounded-lg font-medium hover:bg-red-50 transition-colors duration-200"
                  >
                    {t('nav.signup')}
                  </button>
                  <button
                    onClick={() => handleAuthClick('partner')}
                    className="bg-yellow-500 text-yellow-900 px-4 py-2 rounded-lg font-medium hover:bg-yellow-400 transition-colors duration-200 border border-yellow-400 flex items-center space-x-2"
                  >
                    <Crown size={16} />
                    <span>Devenir Partenaire</span>
                  </button>
                </div>
              )}
              
              <LanguageSelector />
            </nav>

            {/* Mobile menu button */}
            <div className="md:hidden flex items-center space-x-4">
              <LanguageSelector />
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-white p-2 rounded-lg hover:bg-white/10 transition-colors duration-200"
              >
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden pb-4">
              <nav className="flex flex-col space-y-4">
                <a href="#home" className="text-white hover:text-red-200 transition-colors duration-200 font-medium">
                  {t('nav.home')}
                </a>
                <a href="#services" className="text-white hover:text-red-200 transition-colors duration-200 font-medium">
                  {t('nav.services')}
                </a>
                <a href="#pricing" className="text-white hover:text-red-200 transition-colors duration-200 font-medium">
                  {t('nav.pricing')}
                </a>
                <a href="#partners" className="text-white hover:text-red-200 transition-colors duration-200 font-medium">
                  {t('nav.partners')}
                </a>
                
                {isAuthenticated ? (
                  <>
                    <div className="text-white text-sm py-2 border-t border-red-400">
                      Connecté en tant que <span className="font-medium">{user?.name}</span>
                      {user?.role === 'partner' && !user?.isApproved && (
                        <span className="block mt-1 bg-yellow-500 text-yellow-900 px-2 py-1 rounded-full text-xs w-fit">
                          En attente de validation
                        </span>
                      )}
                      {subscription && (
                        <span className="block mt-1 bg-green-500 text-green-900 px-2 py-1 rounded-full text-xs w-fit">
                          Abonnement actif
                        </span>
                      )}
                    </div>
                    
                    {!isAdmin && (
                      <button
                        onClick={handleDashboardClick}
                        className="text-white hover:text-red-200 transition-colors duration-200 font-medium flex items-center space-x-2 text-left"
                      >
                        <BarChart3 size={16} />
                        <span>Tableau de Bord</span>
                      </button>
                    )}
                    
                    {isAdmin && (
                      <button
                        onClick={handleAdminClick}
                        className="text-white hover:text-red-200 transition-colors duration-200 font-medium flex items-center space-x-2 text-left"
                      >
                        <Shield size={16} />
                        <span>Administration</span>
                      </button>
                    )}
                    
                    <button
                      onClick={handleLogout}
                      className="bg-white text-red-600 px-4 py-2 rounded-lg font-medium hover:bg-red-50 transition-colors duration-200 w-fit"
                    >
                      Déconnexion
                    </button>
                  </>
                ) : (
                  <>
                    <button
                      onClick={() => handleAuthClick('login')}
                      className="text-white hover:text-red-200 transition-colors duration-200 font-medium text-left"
                    >
                      {t('nav.login')}
                    </button>
                    <button
                      onClick={() => handleAuthClick('signup')}
                      className="bg-white text-red-600 px-4 py-2 rounded-lg font-medium hover:bg-red-50 transition-colors duration-200 w-fit"
                    >
                      {t('nav.signup')}
                    </button>
                    <button
                      onClick={() => handleAuthClick('partner')}
                      className="bg-yellow-500 text-yellow-900 px-4 py-2 rounded-lg font-medium hover:bg-yellow-400 transition-colors duration-200 border border-yellow-400 w-fit flex items-center space-x-2"
                    >
                      <Crown size={16} />
                      <span>Devenir Partenaire</span>
                    </button>
                  </>
                )}
              </nav>
            </div>
          )}
        </div>
      </header>

      {/* Auth Modal */}
      <AuthModal
        isOpen={authModal.isOpen}
        onClose={() => setAuthModal({ ...authModal, isOpen: false })}
        initialMode={authModal.mode}
      />

      {/* Partner Registration Modal */}
      <PartnerRegistration
        isOpen={partnerModal}
        onClose={() => setPartnerModal(false)}
      />
    </>
  );
};

export default Header;