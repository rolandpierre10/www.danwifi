import React from 'react';
import { ArrowRight, Play, Shield, Zap, Globe, CheckCircle } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';

const Hero: React.FC = () => {
  const { t } = useLanguage();
  const { isAuthenticated } = useAuth();

  const handleGetStarted = () => {
    if (isAuthenticated) {
      // Rediriger vers le tableau de bord pour les utilisateurs connectés
      window.location.hash = '#dashboard';
    } else {
      // Trigger signup modal pour les nouveaux utilisateurs
      const signupButton = document.querySelector('[data-auth-signup]') as HTMLButtonElement;
      signupButton?.click();
    }
  };

  const handleLearnMore = () => {
    // Scroll to services section
    const servicesElement = document.getElementById('services');
    if (servicesElement) {
      servicesElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative bg-gradient-to-br from-red-50 to-white pt-20 pb-32 overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 w-72 h-72 bg-red-200/30 rounded-full -translate-x-32 -translate-y-32"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-red-300/20 rounded-full translate-x-48 translate-y-48"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left content */}
          <div className="space-y-8">
            <div className="space-y-6">
              <div className="inline-flex items-center space-x-2 bg-red-100 text-red-800 px-4 py-2 rounded-full text-sm font-medium">
                <CheckCircle size={16} />
                <span>Nouveau : 1 numéro + 1 code WiFi unique</span>
              </div>
              
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
                Services Illimités de<br />
                <span className="text-red-600">Numéros Virtuels</span><br />
                & WiFi Sécurisé
              </h1>
              
              <p className="text-xl text-gray-600 leading-relaxed">
                Connectez-vous au monde entier avec notre numéro de téléphone virtuel, 
                SMS et appels illimités, plus un code WiFi unique sécurisé. 
                Disponible dans 200+ pays.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <button 
                onClick={handleGetStarted}
                className="group bg-red-600 text-white px-8 py-4 rounded-xl font-semibold text-lg hover:bg-red-700 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl flex items-center justify-center space-x-2"
              >
                <span>{isAuthenticated ? 'Accéder au Tableau de Bord' : 'Commencer Maintenant'}</span>
                <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform duration-300" />
              </button>
              
              <button 
                onClick={handleLearnMore}
                className="group bg-white text-red-600 px-8 py-4 rounded-xl font-semibold text-lg border-2 border-red-200 hover:border-red-300 transition-all duration-300 hover:shadow-lg flex items-center justify-center space-x-2"
              >
                <Play size={20} />
                <span>En Savoir Plus</span>
              </button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-8 pt-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-red-600">200+</div>
                <div className="text-sm text-gray-600 mt-1">Pays disponibles</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-red-600">99.9%</div>
                <div className="text-sm text-gray-600 mt-1">Disponibilité</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-red-600">24/7</div>
                <div className="text-sm text-gray-600 mt-1">Support</div>
              </div>
            </div>
          </div>

          {/* Right content - Feature cards */}
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300">
              <div className="flex items-center space-x-4">
                <div className="bg-red-100 p-3 rounded-xl">
                  <Shield className="h-8 w-8 text-red-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">Sécurité Maximale</h3>
                  <p className="text-gray-600">Chiffrement de bout en bout pour toutes vos communications</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300">
              <div className="flex items-center space-x-4">
                <div className="bg-blue-100 p-3 rounded-xl">
                  <Zap className="h-8 w-8 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">Activation Instantanée</h3>
                  <p className="text-gray-600">Vos services sont activés en moins de 2 minutes</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300">
              <div className="flex items-center space-x-4">
                <div className="bg-green-100 p-3 rounded-xl">
                  <Globe className="h-8 w-8 text-green-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">Couverture Mondiale</h3>
                  <p className="text-gray-600">Numéros virtuels disponibles dans 200+ pays</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;