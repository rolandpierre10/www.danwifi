import React, { useState } from 'react';
import { 
  Users, 
  Phone, 
  Wifi, 
  CreditCard, 
  Settings, 
  BarChart3, 
  Shield, 
  UserCheck, 
  UserX, 
  DollarSign,
  TrendingUp,
  Globe,
  Menu,
  X,
  ChevronDown,
  ChevronRight,
  Eye,
  Edit,
  Trash2,
  CheckCircle,
  XCircle,
  AlertCircle,
  Crown,
  Mail,
  Building,
  Calendar,
  Copy,
  Plus,
  MessageSquare,
  PhoneCall,
  MapPin
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useSubscription } from '../contexts/SubscriptionContext';
import { countries, getPopularCountries } from '../data/countries';

const AdminDashboard: React.FC = () => {
  const { user, logout } = useAuth();
  const { createVirtualNumber, generateWiFiCode } = useSubscription();
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'partners' | 'payments' | 'services' | 'settings'>('overview');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [expandedMenus, setExpandedMenus] = useState<Record<string, boolean>>({});

  // États pour les services admin
  const [adminNumbers, setAdminNumbers] = useState<any[]>([
    {
      id: 'admin_001',
      number: '+1 514 123 4567',
      country: 'Canada',
      countryCode: 'CA',
      type: 'premium',
      status: 'active',
      createdAt: '2024-01-10T10:00:00Z',
      expiresAt: '2025-01-10T10:00:00Z',
      isPersonal: true
    }
  ]);

  const [adminWifiCodes, setAdminWifiCodes] = useState<any[]>([
    {
      id: 'wifi_admin_001',
      code: 'DANWIFI-ADMIN-SECURE-001',
      virtualNumberId: 'admin_001',
      ssid: 'DanWiFi_Admin_Secure',
      password: 'AdminSecure2024!',
      status: 'active',
      createdAt: '2024-01-10T10:00:00Z',
      expiresAt: '2025-01-10T10:00:00Z',
      usageCount: 5,
      maxUsage: 100,
      isPersonal: true,
      location: {
        country: 'Canada',
        city: 'Montréal',
        venue: 'Bureau Principal DanWiFi'
      }
    }
  ]);

  // États pour les modals
  const [showCreateNumber, setShowCreateNumber] = useState(false);
  const [showCreateWiFi, setShowCreateWiFi] = useState(false);
  const [showEditNumber, setShowEditNumber] = useState<any>(null);
  const [showEditWiFi, setShowEditWiFi] = useState<any>(null);
  const [showSMSModal, setShowSMSModal] = useState<any>(null);
  const [showCallModal, setShowCallModal] = useState<any>(null);

  // Mock data pour la démo
  const stats = {
    totalUsers: 1247,
    activeSubscriptions: 892,
    totalRevenue: 45678.90,
    pendingPartners: 23,
    virtualNumbers: 1156,
    wifiCodes: 2341
  };

  const recentUsers = [
    { id: '1', name: 'Jean Dupont', email: 'jean@example.com', status: 'active', joinDate: '2024-01-15', subscription: 'Premium' },
    { id: '2', name: 'Marie Martin', email: 'marie@example.com', status: 'active', joinDate: '2024-01-14', subscription: 'Standard' },
    { id: '3', name: 'Pierre Durand', email: 'pierre@example.com', status: 'inactive', joinDate: '2024-01-13', subscription: 'Basic' },
  ];

  const pendingPartners = [
    { 
      id: '1', 
      name: 'TechCorp Solutions', 
      email: 'contact@techcorp.com', 
      company: 'TechCorp Inc.', 
      country: 'France', 
      requestDate: '2024-01-10',
      partnerCode: 'DW-PARTNER-ABC123',
      businessType: 'telecommunications',
      phone: '+33 1 23 45 67 89',
      address: '123 Rue de la Tech, Paris',
      annualFee: 1500,
      status: 'pending'
    },
    { 
      id: '2', 
      name: 'Global Telecom', 
      email: 'info@globaltel.com', 
      company: 'Global Telecom Ltd', 
      country: 'Canada', 
      requestDate: '2024-01-09',
      partnerCode: 'DW-PARTNER-DEF456',
      businessType: 'it_services',
      phone: '+1 514 123 4567',
      address: '456 Tech Street, Montreal',
      annualFee: 1500,
      status: 'pending'
    },
  ];

  const approvedPartners = [
    {
      id: '3',
      name: 'Digital Solutions Pro',
      email: 'contact@digitalpro.com',
      company: 'Digital Solutions Pro SARL',
      country: 'Maroc',
      partnerCode: 'DW-PARTNER-GHI789',
      activationDate: '2024-01-05',
      totalSales: 15,
      totalCommission: 360.00,
      status: 'active'
    }
  ];

  const recentPayments = [
    { id: '1', user: 'Jean Dupont', amount: 29.99, plan: 'Premium', date: '2024-01-15', status: 'completed' },
    { id: '2', user: 'Marie Martin', amount: 19.99, plan: 'Standard', date: '2024-01-14', status: 'completed' },
    { id: '3', user: 'Pierre Durand', amount: 9.99, plan: 'Basic', date: '2024-01-13', status: 'pending' },
  ];

  const toggleMenu = (menuId: string) => {
    setExpandedMenus(prev => ({
      ...prev,
      [menuId]: !prev[menuId]
    }));
  };

  const handleApprovePartner = (partnerId: string) => {
    console.log('Approuver partenaire:', partnerId);
    alert('Partenaire approuvé ! Une notification a été envoyée par email.');
  };

  const handleRejectPartner = (partnerId: string) => {
    console.log('Rejeter partenaire:', partnerId);
    alert('Partenaire rejeté. Une notification a été envoyée par email.');
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('Code copié dans le presse-papiers !');
  };

  // Fonctions pour les services admin
  const handleCreateAdminNumber = async (countryCode: string, type: 'mobile' | 'landline' | 'premium') => {
    try {
      const country = countries.find(c => c.code === countryCode);
      const newNumber = {
        id: 'admin_' + Date.now(),
        number: generatePhoneNumber(countryCode),
        country: country?.name || 'Unknown',
        countryCode,
        type,
        status: 'active',
        createdAt: new Date().toISOString(),
        expiresAt: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(), // 1 an
        isPersonal: true
      };

      setAdminNumbers(prev => [...prev, newNumber]);
      setShowCreateNumber(false);
      alert('Numéro virtuel admin créé avec succès !');
    } catch (error) {
      alert('Erreur lors de la création du numéro');
    }
  };

  const handleCreateAdminWiFi = async (virtualNumberId: string, location?: { country: string; city: string; venue?: string }) => {
    try {
      const newWiFi = {
        id: 'wifi_admin_' + Date.now(),
        code: generateAdminWiFiCode(),
        virtualNumberId,
        ssid: generateSSID(),
        password: generateSecurePassword(),
        status: 'active',
        createdAt: new Date().toISOString(),
        expiresAt: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(), // 1 an
        usageCount: 0,
        maxUsage: 100,
        isPersonal: true,
        location
      };

      setAdminWifiCodes(prev => [...prev, newWiFi]);
      setShowCreateWiFi(false);
      alert('Code WiFi admin créé avec succès !');
    } catch (error) {
      alert('Erreur lors de la création du code WiFi');
    }
  };

  const handleDeleteNumber = (numberId: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer ce numéro ?')) {
      setAdminNumbers(prev => prev.filter(n => n.id !== numberId));
      setAdminWifiCodes(prev => prev.filter(w => w.virtualNumberId !== numberId));
      alert('Numéro supprimé avec succès !');
    }
  };

  const handleDeleteWiFi = (wifiId: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer ce code WiFi ?')) {
      setAdminWifiCodes(prev => prev.filter(w => w.id !== wifiId));
      alert('Code WiFi supprimé avec succès !');
    }
  };

  const handleEditNumber = (number: any) => {
    setShowEditNumber(number);
  };

  const handleEditWiFi = (wifi: any) => {
    setShowEditWiFi(wifi);
  };

  const handleSendSMS = (numberId: string, number: string) => {
    setShowSMSModal({ numberId, number });
  };

  const handleMakeCall = (numberId: string, number: string) => {
    setShowCallModal({ numberId, number });
  };

  // Fonctions utilitaires
  const generatePhoneNumber = (countryCode: string): string => {
    const formats: Record<string, () => string> = {
      'CA': () => `+1 514 ${Math.floor(Math.random() * 900 + 100)} ${Math.floor(Math.random() * 9000 + 1000)}`,
      'US': () => `+1 ${Math.floor(Math.random() * 900 + 100)} ${Math.floor(Math.random() * 900 + 100)} ${Math.floor(Math.random() * 9000 + 1000)}`,
      'FR': () => `+33 ${Math.floor(Math.random() * 9 + 1)} ${Math.floor(Math.random() * 90 + 10)} ${Math.floor(Math.random() * 90 + 10)} ${Math.floor(Math.random() * 90 + 10)} ${Math.floor(Math.random() * 90 + 10)}`,
      'GB': () => `+44 ${Math.floor(Math.random() * 9 + 1)}${Math.floor(Math.random() * 900 + 100)} ${Math.floor(Math.random() * 900000 + 100000)}`,
      'DE': () => `+49 ${Math.floor(Math.random() * 9 + 1)}${Math.floor(Math.random() * 90 + 10)} ${Math.floor(Math.random() * 90000000 + 10000000)}`
    };

    const generator = formats[countryCode];
    return generator ? generator() : `+${Math.floor(Math.random() * 999 + 1)} ${Math.floor(Math.random() * 900000000 + 100000000)}`;
  };

  const generateAdminWiFiCode = (): string => {
    const timestamp = Date.now().toString(36).toUpperCase();
    const random = Math.random().toString(36).substr(2, 6).toUpperCase();
    return `DANWIFI-ADMIN-${timestamp}-${random}`;
  };

  const generateSSID = (): string => {
    const timestamp = Date.now().toString(36).substr(-4).toUpperCase();
    return `DanWiFi_Admin_${timestamp}`;
  };

  const generateSecurePassword = (): string => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
    let password = '';
    for (let i = 0; i < 16; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return password;
  };

  const menuItems = [
    {
      id: 'overview',
      label: 'Vue d\'ensemble',
      icon: BarChart3,
      tab: 'overview'
    },
    {
      id: 'users',
      label: 'Gestion Utilisateurs',
      icon: Users,
      tab: 'users',
      submenu: [
        { id: 'all-users', label: 'Tous les utilisateurs', tab: 'users' },
        { id: 'active-users', label: 'Utilisateurs actifs', tab: 'users' },
        { id: 'inactive-users', label: 'Utilisateurs inactifs', tab: 'users' }
      ]
    },
    {
      id: 'partners',
      label: 'Gestion Partenaires',
      icon: UserCheck,
      tab: 'partners',
      submenu: [
        { id: 'pending-partners', label: 'Demandes en attente', tab: 'partners' },
        { id: 'approved-partners', label: 'Partenaires approuvés', tab: 'partners' },
        { id: 'rejected-partners', label: 'Demandes rejetées', tab: 'partners' }
      ]
    },
    {
      id: 'payments',
      label: 'Paiements',
      icon: CreditCard,
      tab: 'payments',
      submenu: [
        { id: 'all-payments', label: 'Tous les paiements', tab: 'payments' },
        { id: 'pending-payments', label: 'Paiements en attente', tab: 'payments' },
        { id: 'failed-payments', label: 'Paiements échoués', tab: 'payments' }
      ]
    },
    {
      id: 'services',
      label: 'Services',
      icon: Phone,
      tab: 'services',
      submenu: [
        { id: 'virtual-numbers', label: 'Numéros virtuels', tab: 'services' },
        { id: 'wifi-codes', label: 'Codes WiFi', tab: 'services' },
        { id: 'service-stats', label: 'Statistiques', tab: 'services' }
      ]
    },
    {
      id: 'settings',
      label: 'Paramètres',
      icon: Settings,
      tab: 'settings',
      submenu: [
        { id: 'general-settings', label: 'Paramètres généraux', tab: 'settings' },
        { id: 'pricing-settings', label: 'Configuration tarifs', tab: 'settings' },
        { id: 'system-settings', label: 'Paramètres système', tab: 'settings' }
      ]
    }
  ];

  const renderSidebar = () => (
    <div className={`fixed inset-y-0 left-0 z-50 w-64 bg-gray-900 transform transition-transform duration-300 ease-in-out ${
      sidebarOpen ? 'translate-x-0' : '-translate-x-full'
    } lg:translate-x-0 lg:static lg:inset-0`}>
      <div className="flex items-center justify-between h-16 px-6 bg-gray-800">
        <div className="flex items-center space-x-2">
          <Shield className="h-8 w-8 text-red-500" />
          <span className="text-xl font-bold text-white">Admin DanWiFi</span>
        </div>
        <button
          onClick={() => setSidebarOpen(false)}
          className="lg:hidden text-gray-400 hover:text-white"
        >
          <X size={20} />
        </button>
      </div>

      <nav className="mt-8 px-4">
        <div className="space-y-2">
          {menuItems.map((item) => (
            <div key={item.id}>
              <button
                onClick={() => {
                  if (item.submenu) {
                    toggleMenu(item.id);
                  } else {
                    setActiveTab(item.tab as any);
                    setSidebarOpen(false);
                  }
                }}
                className={`w-full flex items-center justify-between px-4 py-3 text-left rounded-lg transition-colors duration-200 ${
                  activeTab === item.tab
                    ? 'bg-red-600 text-white'
                    : 'text-gray-300 hover:bg-gray-800 hover:text-white'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <item.icon size={20} />
                  <span className="font-medium">{item.label}</span>
                </div>
                {item.submenu && (
                  <div className="ml-2">
                    {expandedMenus[item.id] ? (
                      <ChevronDown size={16} />
                    ) : (
                      <ChevronRight size={16} />
                    )}
                  </div>
                )}
              </button>

              {item.submenu && expandedMenus[item.id] && (
                <div className="ml-6 mt-2 space-y-1">
                  {item.submenu.map((subItem) => (
                    <button
                      key={subItem.id}
                      onClick={() => {
                        setActiveTab(subItem.tab as any);
                        setSidebarOpen(false);
                      }}
                      className="w-full text-left px-4 py-2 text-sm text-gray-400 hover:text-white hover:bg-gray-800 rounded-lg transition-colors duration-200"
                    >
                      {subItem.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="mt-8 pt-8 border-t border-gray-700">
          <div className="px-4 py-3">
            <div className="text-sm text-gray-400">Connecté en tant que</div>
            <div className="text-white font-medium">{user?.name}</div>
            <div className="text-xs text-gray-500">{user?.email}</div>
          </div>
          <button
            onClick={() => {
              logout();
              window.location.hash = '';
            }}
            className="w-full mt-2 px-4 py-2 text-left text-red-400 hover:text-red-300 hover:bg-gray-800 rounded-lg transition-colors duration-200"
          >
            Se déconnecter
          </button>
        </div>
      </nav>
    </div>
  );

  const renderOverview = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Vue d'ensemble</h2>
        <div className="text-sm text-gray-500">
          Dernière mise à jour : {new Date().toLocaleString('fr-FR')}
        </div>
      </div>

      {/* Statistiques principales */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Utilisateurs Total</p>
              <p className="text-3xl font-bold text-gray-900">{stats.totalUsers.toLocaleString()}</p>
            </div>
            <div className="bg-blue-100 p-3 rounded-lg">
              <Users className="h-8 w-8 text-blue-600" />
            </div>
          </div>
          <div className="mt-4 flex items-center">
            <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-sm text-green-600">+12% ce mois</span>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Abonnements Actifs</p>
              <p className="text-3xl font-bold text-gray-900">{stats.activeSubscriptions.toLocaleString()}</p>
            </div>
            <div className="bg-green-100 p-3 rounded-lg">
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </div>
          <div className="mt-4 flex items-center">
            <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-sm text-green-600">+8% ce mois</span>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Revenus Total</p>
              <p className="text-3xl font-bold text-gray-900">${stats.totalRevenue.toLocaleString()}</p>
            </div>
            <div className="bg-green-100 p-3 rounded-lg">
              <DollarSign className="h-8 w-8 text-green-600" />
            </div>
          </div>
          <div className="mt-4 flex items-center">
            <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-sm text-green-600">+15% ce mois</span>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Partenaires en Attente</p>
              <p className="text-3xl font-bold text-gray-900">{stats.pendingPartners}</p>
            </div>
            <div className="bg-yellow-100 p-3 rounded-lg">
              <AlertCircle className="h-8 w-8 text-yellow-600" />
            </div>
          </div>
          <div className="mt-4">
            <button
              onClick={() => setActiveTab('partners')}
              className="text-sm text-red-600 hover:text-red-700 font-medium"
            >
              Voir les demandes →
            </button>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Numéros Virtuels</p>
              <p className="text-3xl font-bold text-gray-900">{stats.virtualNumbers.toLocaleString()}</p>
            </div>
            <div className="bg-purple-100 p-3 rounded-lg">
              <Phone className="h-8 w-8 text-purple-600" />
            </div>
          </div>
          <div className="mt-4 flex items-center">
            <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-sm text-green-600">+25% ce mois</span>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Codes WiFi</p>
              <p className="text-3xl font-bold text-gray-900">{stats.wifiCodes.toLocaleString()}</p>
            </div>
            <div className="bg-indigo-100 p-3 rounded-lg">
              <Wifi className="h-8 w-8 text-indigo-600" />
            </div>
          </div>
          <div className="mt-4 flex items-center">
            <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-sm text-green-600">+18% ce mois</span>
          </div>
        </div>
      </div>

      {/* Activité récente */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Nouveaux Utilisateurs</h3>
          <div className="space-y-4">
            {recentUsers.map((user) => (
              <div key={user.id} className="flex items-center justify-between">
                <div>
                  <div className="font-medium text-gray-900">{user.name}</div>
                  <div className="text-sm text-gray-500">{user.email}</div>
                </div>
                <div className="text-right">
                  <div className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${
                    user.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                  }`}>
                    {user.status}
                  </div>
                  <div className="text-xs text-gray-500 mt-1">{user.subscription}</div>
                </div>
              </div>
            ))}
          </div>
          <button
            onClick={() => setActiveTab('users')}
            className="w-full mt-4 text-center text-red-600 hover:text-red-700 font-medium text-sm"
          >
            Voir tous les utilisateurs →
          </button>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Paiements Récents</h3>
          <div className="space-y-4">
            {recentPayments.map((payment) => (
              <div key={payment.id} className="flex items-center justify-between">
                <div>
                  <div className="font-medium text-gray-900">{payment.user}</div>
                  <div className="text-sm text-gray-500">{payment.plan}</div>
                </div>
                <div className="text-right">
                  <div className="font-medium text-gray-900">${payment.amount}</div>
                  <div className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${
                    payment.status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                  }`}>
                    {payment.status}
                  </div>
                </div>
              </div>
            ))}
          </div>
          <button
            onClick={() => setActiveTab('payments')}
            className="w-full mt-4 text-center text-red-600 hover:text-red-700 font-medium text-sm"
          >
            Voir tous les paiements →
          </button>
        </div>
      </div>
    </div>
  );

  const renderUsers = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Gestion des Utilisateurs</h2>
        <button className="bg-red-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-red-700 transition-colors duration-200">
          Exporter les données
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-900">Liste des Utilisateurs</h3>
            <div className="flex space-x-2">
              <select className="px-3 py-2 border border-gray-300 rounded-lg text-sm">
                <option>Tous les statuts</option>
                <option>Actifs</option>
                <option>Inactifs</option>
              </select>
              <input
                type="text"
                placeholder="Rechercher..."
                className="px-3 py-2 border border-gray-300 rounded-lg text-sm"
              />
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Utilisateur</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Abonnement</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date d'inscription</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {recentUsers.map((user) => (
                <tr key={user.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{user.name}</div>
                      <div className="text-sm text-gray-500">{user.email}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${
                      user.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                    }`}>
                      {user.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {user.subscription}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(user.joinDate).toLocaleDateString('fr-FR')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex space-x-2">
                      <button 
                        onClick={() => alert(`Voir détails de ${user.name}`)}
                        className="text-blue-600 hover:text-blue-900"
                      >
                        <Eye size={16} />
                      </button>
                      <button 
                        onClick={() => alert(`Éditer ${user.name}`)}
                        className="text-green-600 hover:text-green-900"
                      >
                        <Edit size={16} />
                      </button>
                      <button 
                        onClick={() => {
                          if (confirm(`Supprimer ${user.name} ?`)) {
                            alert(`${user.name} supprimé`);
                          }
                        }}
                        className="text-red-600 hover:text-red-900"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderPartners = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Gestion des Partenaires</h2>
        <div className="flex space-x-2">
          <span className="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm font-medium">
            {pendingPartners.length} en attente
          </span>
          <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
            {approvedPartners.length} approuvés
          </span>
        </div>
      </div>

      {/* Demandes en attente */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center space-x-2">
            <AlertCircle className="h-5 w-5 text-yellow-500" />
            <span>Demandes de Partenariat en Attente</span>
          </h3>
        </div>

        <div className="divide-y divide-gray-200">
          {pendingPartners.map((partner) => (
            <div key={partner.id} className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-3">
                    <Crown className="h-6 w-6 text-yellow-500" />
                    <h4 className="text-xl font-semibold text-gray-900">{partner.name}</h4>
                    <span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-medium">
                      En attente
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2 text-sm">
                        <Mail className="h-4 w-4 text-gray-400" />
                        <span className="text-gray-600">Email:</span>
                        <span className="font-medium">{partner.email}</span>
                      </div>
                      <div className="flex items-center space-x-2 text-sm">
                        <Phone className="h-4 w-4 text-gray-400" />
                        <span className="text-gray-600">Téléphone:</span>
                        <span className="font-medium">{partner.phone}</span>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2 text-sm">
                        <Building className="h-4 w-4 text-gray-400" />
                        <span className="text-gray-600">Entreprise:</span>
                        <span className="font-medium">{partner.company}</span>
                      </div>
                      <div className="flex items-center space-x-2 text-sm">
                        <Globe className="h-4 w-4 text-gray-400" />
                        <span className="text-gray-600">Pays:</span>
                        <span className="font-medium">{partner.country}</span>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2 text-sm">
                        <Calendar className="h-4 w-4 text-gray-400" />
                        <span className="text-gray-600">Demande:</span>
                        <span className="font-medium">{new Date(partner.requestDate).toLocaleDateString('fr-FR')}</span>
                      </div>
                      <div className="flex items-center space-x-2 text-sm">
                        <DollarSign className="h-4 w-4 text-gray-400" />
                        <span className="text-gray-600">Cotisation:</span>
                        <span className="font-medium">${partner.annualFee}</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-50 rounded-lg p-3 mb-4">
                    <div className="flex items-center space-x-2 mb-2">
                      <span className="text-sm font-medium text-gray-700">Code Partenaire:</span>
                      <code className="bg-white px-2 py-1 rounded text-sm font-mono text-blue-600">
                        {partner.partnerCode}
                      </code>
                      <button
                        onClick={() => copyToClipboard(partner.partnerCode)}
                        className="text-gray-400 hover:text-gray-600"
                      >
                        <Copy size={14} />
                      </button>
                    </div>
                    <div className="text-sm text-gray-600">
                      <strong>Adresse:</strong> {partner.address}
                    </div>
                    <div className="text-sm text-gray-600">
                      <strong>Type d'activité:</strong> {partner.businessType}
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex space-x-3">
                <button
                  onClick={() => handleApprovePartner(partner.id)}
                  className="bg-green-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-green-700 transition-colors duration-200 flex items-center space-x-2"
                >
                  <CheckCircle size={16} />
                  <span>Approuver</span>
                </button>
                <button
                  onClick={() => handleRejectPartner(partner.id)}
                  className="bg-red-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-red-700 transition-colors duration-200 flex items-center space-x-2"
                >
                  <XCircle size={16} />
                  <span>Rejeter</span>
                </button>
                <button 
                  onClick={() => alert(`Voir détails de ${partner.name}`)}
                  className="bg-gray-100 text-gray-700 px-6 py-2 rounded-lg font-medium hover:bg-gray-200 transition-colors duration-200 flex items-center space-x-2"
                >
                  <Eye size={16} />
                  <span>Voir Détails</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Partenaires approuvés */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center space-x-2">
            <CheckCircle className="h-5 w-5 text-green-500" />
            <span>Partenaires Approuvés</span>
          </h3>
        </div>

        <div className="divide-y divide-gray-200">
          {approvedPartners.map((partner) => (
            <div key={partner.id} className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <Crown className="h-5 w-5 text-green-500" />
                    <h4 className="text-lg font-semibold text-gray-900">{partner.name}</h4>
                    <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">
                      Actif
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm text-gray-600">
                    <div>
                      <span className="font-medium">Email:</span> {partner.email}
                    </div>
                    <div>
                      <span className="font-medium">Pays:</span> {partner.country}
                    </div>
                    <div>
                      <span className="font-medium">Ventes:</span> {partner.totalSales}
                    </div>
                    <div>
                      <span className="font-medium">Commission:</span> ${partner.totalCommission}
                    </div>
                  </div>
                  
                  <div className="mt-2 text-sm text-gray-500">
                    Code: <code className="bg-gray-100 px-1 rounded text-xs">{partner.partnerCode}</code> • 
                    Activé le {new Date(partner.activationDate).toLocaleDateString('fr-FR')}
                  </div>
                </div>
                
                <div className="flex space-x-2">
                  <button 
                    onClick={() => alert(`Voir détails de ${partner.name}`)}
                    className="text-blue-600 hover:text-blue-900"
                  >
                    <Eye size={16} />
                  </button>
                  <button 
                    onClick={() => alert(`Éditer ${partner.name}`)}
                    className="text-green-600 hover:text-green-900"
                  >
                    <Edit size={16} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderPayments = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Gestion des Paiements</h2>
        <div className="flex space-x-2">
          <button className="bg-green-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-green-700 transition-colors duration-200">
            Exporter
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Historique des Paiements</h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Utilisateur</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Montant</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Plan</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {recentPayments.map((payment) => (
                <tr key={payment.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {payment.user}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    ${payment.amount}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {payment.plan}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(payment.date).toLocaleDateString('fr-FR')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${
                      payment.status === 'completed' ? 'bg-green-100 text-green-800' : 
                      payment.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {payment.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex space-x-2">
                      <button 
                        onClick={() => alert(`Voir détails du paiement ${payment.id}`)}
                        className="text-blue-600 hover:text-blue-900"
                      >
                        <Eye size={16} />
                      </button>
                      {payment.status === 'completed' && (
                        <button 
                          onClick={() => {
                            if (confirm('Confirmer le remboursement ?')) {
                              alert('Remboursement traité');
                            }
                          }}
                          className="text-red-600 hover:text-red-900"
                        >
                          Rembourser
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderServices = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Services Admin - Usage Personnel</h2>
        <div className="text-sm text-gray-500">
          Vos numéros et codes WiFi personnels
        </div>
      </div>

      {/* Actions rapides */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="bg-blue-100 p-3 rounded-xl">
              <Phone className="h-8 w-8 text-blue-600" />
            </div>
            <div>
              <h3 className="text-xl font-semibold text-gray-900">Créer Numéro Admin</h3>
              <p className="text-gray-600">Numéro virtuel pour usage personnel</p>
            </div>
          </div>
          <button
            onClick={() => setShowCreateNumber(true)}
            className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors duration-200 flex items-center justify-center space-x-2"
          >
            <Plus size={20} />
            <span>Créer Numéro Admin</span>
          </button>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="bg-green-100 p-3 rounded-xl">
              <Wifi className="h-8 w-8 text-green-600" />
            </div>
            <div>
              <h3 className="text-xl font-semibold text-gray-900">Créer Code WiFi Admin</h3>
              <p className="text-gray-600">Code WiFi sécurisé personnel</p>
            </div>
          </div>
          <button
            onClick={() => setShowCreateWiFi(true)}
            disabled={adminNumbers.length === 0}
            className="w-full bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200 flex items-center justify-center space-x-2"
          >
            <Plus size={20} />
            <span>Créer Code WiFi Admin</span>
          </button>
        </div>
      </div>

      {/* Numéros virtuels admin */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-900">Mes Numéros Virtuels</h3>
            <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
              {adminNumbers.length} numéros
            </span>
          </div>
        </div>

        <div className="divide-y divide-gray-200">
          {adminNumbers.map((number) => (
            <div key={number.id} className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <Phone className="h-5 w-5 text-blue-600" />
                    <span className="text-xl font-semibold text-gray-900">{number.number}</span>
                    <button
                      onClick={() => copyToClipboard(number.number)}
                      className="text-gray-400 hover:text-gray-600"
                    >
                      <Copy size={16} />
                    </button>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      number.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                    }`}>
                      {number.status}
                    </span>
                  </div>
                  <div className="text-sm text-gray-600">
                    {number.country} • {number.type} • Expire le {new Date(number.expiresAt).toLocaleDateString('fr-FR')}
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => handleSendSMS(number.id, number.number)}
                    className="bg-blue-50 text-blue-600 p-2 rounded-lg hover:bg-blue-100 transition-colors duration-200"
                    title="Envoyer SMS"
                  >
                    <MessageSquare size={16} />
                  </button>
                  <button
                    onClick={() => handleMakeCall(number.id, number.number)}
                    className="bg-green-50 text-green-600 p-2 rounded-lg hover:bg-green-100 transition-colors duration-200"
                    title="Passer un appel"
                  >
                    <PhoneCall size={16} />
                  </button>
                  <button
                    onClick={() => alert(`Voir détails du numéro ${number.number}`)}
                    className="text-blue-600 hover:text-blue-900"
                    title="Voir détails"
                  >
                    <Eye size={16} />
                  </button>
                  <button
                    onClick={() => handleEditNumber(number)}
                    className="text-green-600 hover:text-green-900"
                    title="Éditer"
                  >
                    <Edit size={16} />
                  </button>
                  <button
                    onClick={() => handleDeleteNumber(number.id)}
                    className="text-red-600 hover:text-red-900"
                    title="Supprimer"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            </div>
          ))}
          
          {adminNumbers.length === 0 && (
            <div className="p-8 text-center text-gray-500">
              <Phone size={48} className="mx-auto mb-4 text-gray-300" />
              <p>Aucun numéro virtuel admin créé</p>
              <button
                onClick={() => setShowCreateNumber(true)}
                className="mt-4 text-blue-600 hover:text-blue-700 font-medium"
              >
                Créer votre premier numéro →
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Codes WiFi admin */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-900">Mes Codes WiFi</h3>
            <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
              {adminWifiCodes.length} codes
            </span>
          </div>
        </div>

        <div className="divide-y divide-gray-200">
          {adminWifiCodes.map((wifi) => (
            <div key={wifi.id} className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <Wifi className="h-5 w-5 text-green-600" />
                    <span className="text-lg font-semibold text-gray-900">{wifi.code}</span>
                    <button
                      onClick={() => copyToClipboard(wifi.code)}
                      className="text-gray-400 hover:text-gray-600"
                    >
                      <Copy size={16} />
                    </button>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      wifi.status === 'active' ? 'bg-green-100 text-green-800' : 
                      wifi.status === 'expired' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {wifi.status}
                    </span>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600">
                    <div>
                      <strong>SSID:</strong> {wifi.ssid}
                    </div>
                    <div className="flex items-center space-x-2">
                      <strong>Mot de passe:</strong>
                      <code className="bg-gray-100 px-2 py-1 rounded text-xs">{wifi.password}</code>
                      <button
                        onClick={() => copyToClipboard(wifi.password)}
                        className="text-gray-400 hover:text-gray-600"
                      >
                        <Copy size={12} />
                      </button>
                    </div>
                    <div>
                      <strong>Utilisation:</strong> {wifi.usageCount}/{wifi.maxUsage}
                    </div>
                  </div>
                  {wifi.location && (
                    <div className="mt-2 text-sm text-gray-500 flex items-center space-x-2">
                      <MapPin size={14} />
                      <span>{wifi.location.venue || wifi.location.city}, {wifi.location.country}</span>
                    </div>
                  )}
                </div>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => alert(`Voir détails du code ${wifi.code}`)}
                    className="text-blue-600 hover:text-blue-900"
                    title="Voir détails"
                  >
                    <Eye size={16} />
                  </button>
                  <button
                    onClick={() => handleEditWiFi(wifi)}
                    className="text-green-600 hover:text-green-900"
                    title="Éditer"
                  >
                    <Edit size={16} />
                  </button>
                  <button
                    onClick={() => handleDeleteWiFi(wifi.id)}
                    className="text-red-600 hover:text-red-900"
                    title="Supprimer"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-3">
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-gray-600">Utilisation:</span>
                  <span className="font-medium">{wifi.usageCount}/{wifi.maxUsage} connexions</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-green-600 h-2 rounded-full" 
                    style={{ width: `${(wifi.usageCount / wifi.maxUsage) * 100}%` }}
                  ></div>
                </div>
              </div>
            </div>
          ))}
          
          {adminWifiCodes.length === 0 && (
            <div className="p-8 text-center text-gray-500">
              <Wifi size={48} className="mx-auto mb-4 text-gray-300" />
              <p>Aucun code WiFi admin créé</p>
              {adminNumbers.length > 0 ? (
                <button
                  onClick={() => setShowCreateWiFi(true)}
                  className="mt-4 text-green-600 hover:text-green-700 font-medium"
                >
                  Créer votre premier code WiFi →
                </button>
              ) : (
                <p className="mt-4 text-gray-400">Créez d'abord un numéro virtuel</p>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Statistiques globales */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3 mb-4">
            <Phone className="h-8 w-8 text-blue-600" />
            <h3 className="text-lg font-semibold text-gray-900">Numéros Virtuels Globaux</h3>
          </div>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Total créés:</span>
              <span className="font-medium">{stats.virtualNumbers.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Actifs:</span>
              <span className="font-medium text-green-600">{(stats.virtualNumbers * 0.85).toFixed(0)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Inactifs:</span>
              <span className="font-medium text-gray-500">{(stats.virtualNumbers * 0.15).toFixed(0)}</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3 mb-4">
            <Wifi className="h-8 w-8 text-purple-600" />
            <h3 className="text-lg font-semibold text-gray-900">Codes WiFi Globaux</h3>
          </div>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Total générés:</span>
              <span className="font-medium">{stats.wifiCodes.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Actifs:</span>
              <span className="font-medium text-green-600">{(stats.wifiCodes * 0.70).toFixed(0)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Expirés:</span>
              <span className="font-medium text-gray-500">{(stats.wifiCodes * 0.30).toFixed(0)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderSettings = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Paramètres Système</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Configuration Générale</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Nom de l'application</label>
              <input
                type="text"
                value="DanWiFi"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">URL de l'API</label>
              <input
                type="url"
                value="https://api.danwifi.com"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email de support</label>
              <input
                type="email"
                value="support@danwifi.com"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Configuration des Partenaires</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Cotisation annuelle ($)</label>
              <input
                type="number"
                value="1500"
                step="1"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Commission partenaire (%)</label>
              <input
                type="number"
                value="8"
                step="0.1"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Délai de validation (jours)</label>
              <input
                type="number"
                value="5"
                step="1"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Actions Système</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button 
            onClick={() => alert('Configuration sauvegardée')}
            className="bg-blue-600 text-white px-4 py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors duration-200"
          >
            Sauvegarder la Configuration
          </button>
          <button 
            onClick={() => alert('Services redémarrés')}
            className="bg-yellow-600 text-white px-4 py-3 rounded-lg font-medium hover:bg-yellow-700 transition-colors duration-200"
          >
            Redémarrer les Services
          </button>
          <button 
            onClick={() => alert('Logs exportés')}
            className="bg-green-600 text-white px-4 py-3 rounded-lg font-medium hover:bg-green-700 transition-colors duration-200"
          >
            Exporter les Logs
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      {renderSidebar()}

      {/* Overlay pour mobile */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main Content */}
      <div className="flex-1 lg:ml-0">
        {/* Header */}
        <div className="bg-white shadow-sm border-b border-gray-200">
          <div className="px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => setSidebarOpen(true)}
                  className="lg:hidden text-gray-500 hover:text-gray-700"
                >
                  <Menu size={24} />
                </button>
                <h1 className="text-2xl font-bold text-gray-900">Administration DanWiFi</h1>
              </div>
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => window.location.hash = ''}
                  className="text-red-600 hover:text-red-700 font-medium"
                >
                  ← Retour au site
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="px-4 sm:px-6 lg:px-8 py-8">
          {activeTab === 'overview' && renderOverview()}
          {activeTab === 'users' && renderUsers()}
          {activeTab === 'partners' && renderPartners()}
          {activeTab === 'payments' && renderPayments()}
          {activeTab === 'services' && renderServices()}
          {activeTab === 'settings' && renderSettings()}
        </div>
      </div>

      {/* Modals */}
      {showCreateNumber && (
        <CreateNumberModal
          onClose={() => setShowCreateNumber(false)}
          onSubmit={handleCreateAdminNumber}
        />
      )}

      {showCreateWiFi && (
        <CreateWiFiModal
          onClose={() => setShowCreateWiFi(false)}
          onSubmit={handleCreateAdminWiFi}
          virtualNumbers={adminNumbers}
        />
      )}

      {showSMSModal && (
        <SMSModal
          numberId={showSMSModal.numberId}
          number={showSMSModal.number}
          onClose={() => setShowSMSModal(null)}
        />
      )}

      {showCallModal && (
        <CallModal
          numberId={showCallModal.numberId}
          number={showCallModal.number}
          onClose={() => setShowCallModal(null)}
        />
      )}
    </div>
  );
};

// Composants modaux
const CreateNumberModal: React.FC<{
  onClose: () => void;
  onSubmit: (countryCode: string, type: 'mobile' | 'landline' | 'premium') => void;
}> = ({ onClose, onSubmit }) => {
  const [selectedCountry, setSelectedCountry] = useState('');
  const [numberType, setNumberType] = useState<'mobile' | 'landline' | 'premium'>('premium');
  const [searchTerm, setSearchTerm] = useState('');

  const popularCountries = getPopularCountries();
  const filteredCountries = countries.filter(country =>
    country.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    country.code.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedCountry) {
      onSubmit(selectedCountry, numberType);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h3 className="text-xl font-semibold text-gray-900">Créer Numéro Admin</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X size={20} />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Rechercher un pays
            </label>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Tapez le nom d'un pays..."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Sélectionner un pays
            </label>
            <div className="max-h-48 overflow-y-auto border border-gray-300 rounded-lg">
              {(searchTerm ? filteredCountries : popularCountries).map((country) => (
                <button
                  key={country.code}
                  type="button"
                  onClick={() => setSelectedCountry(country.code)}
                  className={`w-full text-left px-3 py-2 hover:bg-gray-50 flex items-center space-x-3 ${
                    selectedCountry === country.code ? 'bg-red-50 text-red-600' : ''
                  }`}
                >
                  <span className="text-lg">{country.flag}</span>
                  <span className="flex-1">{country.name}</span>
                  <span className="text-xs text-gray-500">{country.code}</span>
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Type de numéro
            </label>
            <div className="space-y-2">
              {[
                { value: 'mobile', label: 'Mobile', description: 'Numéro de téléphone mobile' },
                { value: 'landline', label: 'Fixe', description: 'Numéro de téléphone fixe' },
                { value: 'premium', label: 'Premium', description: 'Numéro premium avec fonctionnalités avancées' }
              ].map((type) => (
                <label key={type.value} className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
                  <input
                    type="radio"
                    name="numberType"
                    value={type.value}
                    checked={numberType === type.value}
                    onChange={(e) => setNumberType(e.target.value as any)}
                    className="text-red-600 focus:ring-red-500"
                  />
                  <div>
                    <div className="font-medium text-gray-900">{type.label}</div>
                    <div className="text-sm text-gray-600">{type.description}</div>
                  </div>
                </label>
              ))}
            </div>
          </div>

          <div className="flex space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors duration-200"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={!selectedCountry}
              className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200"
            >
              Créer le Numéro
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

const CreateWiFiModal: React.FC<{
  onClose: () => void;
  onSubmit: (virtualNumberId: string, location?: { country: string; city: string; venue?: string }) => void;
  virtualNumbers: any[];
}> = ({ onClose, onSubmit, virtualNumbers }) => {
  const [selectedNumberId, setSelectedNumberId] = useState('');
  const [location, setLocation] = useState({
    country: '',
    city: '',
    venue: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedNumberId) {
      const locationData = location.country && location.city ? {
        country: location.country,
        city: location.city,
        venue: location.venue || undefined
      } : undefined;
      
      onSubmit(selectedNumberId, locationData);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h3 className="text-xl font-semibold text-gray-900">Créer Code WiFi Admin</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X size={20} />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Numéro virtuel associé
            </label>
            <select
              value={selectedNumberId}
              onChange={(e) => setSelectedNumberId(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              required
            >
              <option value="">Sélectionner un numéro</option>
              {virtualNumbers.map((number) => (
                <option key={number.id} value={number.id}>
                  {number.number} ({number.country})
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-4">
            <h4 className="text-sm font-medium text-gray-700">Localisation (optionnel)</h4>
            
            <div>
              <label className="block text-xs text-gray-600 mb-1">Pays</label>
              <input
                type="text"
                value={location.country}
                onChange={(e) => setLocation(prev => ({ ...prev, country: e.target.value }))}
                placeholder="Canada"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-xs text-gray-600 mb-1">Ville</label>
              <input
                type="text"
                value={location.city}
                onChange={(e) => setLocation(prev => ({ ...prev, city: e.target.value }))}
                placeholder="Montréal"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-xs text-gray-600 mb-1">Lieu (optionnel)</label>
              <input
                type="text"
                value={location.venue}
                onChange={(e) => setLocation(prev => ({ ...prev, venue: e.target.value }))}
                placeholder="Bureau Principal DanWiFi"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              />
            </div>
          </div>

          <div className="flex space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors duration-200"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={!selectedNumberId}
              className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200"
            >
              Créer le Code WiFi
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

const SMSModal: React.FC<{
  numberId: string;
  number: string;
  onClose: () => void;
}> = ({ numberId, number, onClose }) => {
  const [to, setTo] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert(`SMS envoyé de ${number} vers ${to}: ${message}`);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h3 className="text-xl font-semibold text-gray-900">Envoyer SMS Admin</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X size={20} />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">De</label>
            <input
              type="text"
              value={number}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50"
              readOnly
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">À</label>
            <input
              type="tel"
              value={to}
              onChange={(e) => setTo(e.target.value)}
              placeholder="+1 514 123 4567"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Message</label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Votre message..."
              rows={4}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              required
            />
            <div className="text-xs text-gray-500 mt-1">{message.length}/160 caractères</div>
          </div>
          
          <div className="flex space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors duration-200"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200"
            >
              Envoyer SMS
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

const CallModal: React.FC<{
  numberId: string;
  number: string;
  onClose: () => void;
}> = ({ numberId, number, onClose }) => {
  const [to, setTo] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert(`Appel initié de ${number} vers ${to}`);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h3 className="text-xl font-semibold text-gray-900">Passer Appel Admin</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X size={20} />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">De</label>
            <input
              type="text"
              value={number}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50"
              readOnly
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Appeler</label>
            <input
              type="tel"
              value={to}
              onChange={(e) => setTo(e.target.value)}
              placeholder="+1 514 123 4567"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              required
            />
          </div>
          
          <div className="flex space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors duration-200"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
            >
              Appeler
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AdminDashboard;