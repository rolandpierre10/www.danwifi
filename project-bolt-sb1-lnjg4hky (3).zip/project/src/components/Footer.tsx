import React from 'react';
import { Wifi, Mail, Phone, MapPin, Facebook, Twitter, Linkedin, Instagram } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const Footer: React.FC = () => {
  const { t } = useLanguage();

  const handleLinkClick = (section: string) => {
    // Scroll to section or navigate
    const element = document.getElementById(section);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-6">
            <div className="flex items-center space-x-2">
              <div className="bg-red-600 p-2 rounded-lg">
                <Wifi className="h-6 w-6 text-white" />
              </div>
              <span className="text-2xl font-bold">{t('footer.company')}</span>
            </div>
            <p className="text-gray-400 leading-relaxed">
              Leader mondial des services de télécommunications virtuelles. 
              Numéros virtuels et WiFi sécurisé dans 200+ pays.
            </p>
            <div className="flex space-x-4">
              <a 
                href="https://facebook.com/danwifi" 
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-gray-800 p-2 rounded-lg hover:bg-red-600 transition-colors duration-200"
              >
                <Facebook size={20} />
              </a>
              <a 
                href="https://twitter.com/danwifi" 
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-gray-800 p-2 rounded-lg hover:bg-red-600 transition-colors duration-200"
              >
                <Twitter size={20} />
              </a>
              <a 
                href="https://linkedin.com/company/danwifi" 
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-gray-800 p-2 rounded-lg hover:bg-red-600 transition-colors duration-200"
              >
                <Linkedin size={20} />
              </a>
              <a 
                href="https://instagram.com/danwifi" 
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-gray-800 p-2 rounded-lg hover:bg-red-600 transition-colors duration-200"
              >
                <Instagram size={20} />
              </a>
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-xl font-semibold mb-6">Services</h3>
            <ul className="space-y-4">
              <li>
                <button 
                  onClick={() => handleLinkClick('services')}
                  className="text-gray-400 hover:text-white transition-colors duration-200"
                >
                  Numéros Virtuels
                </button>
              </li>
              <li>
                <button 
                  onClick={() => handleLinkClick('services')}
                  className="text-gray-400 hover:text-white transition-colors duration-200"
                >
                  SMS Illimités
                </button>
              </li>
              <li>
                <button 
                  onClick={() => handleLinkClick('services')}
                  className="text-gray-400 hover:text-white transition-colors duration-200"
                >
                  WiFi Sécurisé
                </button>
              </li>
              <li>
                <a 
                  href="/api-docs" 
                  className="text-gray-400 hover:text-white transition-colors duration-200"
                >
                  API Développeurs
                </a>
              </li>
              <li>
                <button 
                  onClick={() => handleLinkClick('pricing')}
                  className="text-gray-400 hover:text-white transition-colors duration-200"
                >
                  Solutions Entreprise
                </button>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="text-xl font-semibold mb-6">Support</h3>
            <ul className="space-y-4">
              <li>
                <a 
                  href="/help" 
                  className="text-gray-400 hover:text-white transition-colors duration-200"
                >
                  Centre d'Aide
                </a>
              </li>
              <li>
                <a 
                  href="/docs" 
                  className="text-gray-400 hover:text-white transition-colors duration-200"
                >
                  Documentation
                </a>
              </li>
              <li>
                <a 
                  href="/status" 
                  className="text-gray-400 hover:text-white transition-colors duration-200"
                >
                  État des Services
                </a>
              </li>
              <li>
                <a 
                  href="mailto:contact@danwifi.com" 
                  className="text-gray-400 hover:text-white transition-colors duration-200"
                >
                  Contactez-nous
                </a>
              </li>
              <li>
                <button 
                  onClick={() => handleLinkClick('partners')}
                  className="text-gray-400 hover:text-white transition-colors duration-200"
                >
                  Partenaires
                </button>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-xl font-semibold mb-6">Contact</h3>
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <Mail size={18} className="text-red-500" />
                <a 
                  href="mailto:contact@danwifi.com"
                  className="text-gray-400 hover:text-white transition-colors duration-200"
                >
                  contact@danwifi.com
                </a>
              </div>
              <div className="flex items-center space-x-3">
                <Phone size={18} className="text-red-500" />
                <a 
                  href="tel:+15146543767"
                  className="text-gray-400 hover:text-white transition-colors duration-200"
                >
                  (514) 654-3767
                </a>
              </div>
              <div className="flex items-start space-x-3">
                <MapPin size={18} className="text-red-500 mt-1" />
                <span className="text-gray-400">
                  12100 42e Ave<br />
                  Montréal, QC, Canada<br />
                  H1E 2X5
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-gray-400 text-sm">
              © 2024 DanWiFi. Tous droits réservés.
            </div>
            <div className="flex flex-wrap justify-center md:justify-end space-x-6 text-sm">
              <a 
                href="/legal/terms" 
                className="text-gray-400 hover:text-white transition-colors duration-200"
              >
                Conditions d'Utilisation
              </a>
              <a 
                href="/legal/privacy" 
                className="text-gray-400 hover:text-white transition-colors duration-200"
              >
                Politique de Confidentialité
              </a>
              <a 
                href="/legal/cookies" 
                className="text-gray-400 hover:text-white transition-colors duration-200"
              >
                Politique des Cookies
              </a>
              <a 
                href="/legal/mentions" 
                className="text-gray-400 hover:text-white transition-colors duration-200"
              >
                Mentions Légales
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;