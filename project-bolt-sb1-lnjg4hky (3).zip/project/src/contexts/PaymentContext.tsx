import React, { createContext, useContext, useState } from 'react';

interface PaymentResult {
  success: boolean;
  transactionId?: string;
  error?: string;
}

interface CardData {
  number: string;
  expiry: string;
  cvc: string;
  name: string;
  email: string;
  address?: string;
  city?: string;
  postalCode?: string;
  country?: string;
}

interface PayPalData {
  email: string;
  password: string;
}

type PaymentContextType = {
  isProcessing: boolean;
  processCardPayment: (cardData: CardData, amount: number, planId: string) => Promise<PaymentResult>;
  processPayPalPayment: (paypalData: PayPalData, amount: number, planId: string) => Promise<PaymentResult>;
  getPaymentHistory: (userId: string) => Promise<any[]>;
};

const PaymentContext = createContext<PaymentContextType | undefined>(undefined);

export const PaymentProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isProcessing, setIsProcessing] = useState(false);

  const processCardPayment = async (cardData: CardData, amount: number, planId: string): Promise<PaymentResult> => {
    setIsProcessing(true);
    try {
      // Validation des données de carte
      const cardNumber = cardData.number.replace(/\s/g, '');
      
      if (cardNumber.length < 13 || cardNumber.length > 19) {
        throw new Error('Numéro de carte invalide');
      }
      
      if (!cardData.expiry.match(/^\d{2}\/\d{2}$/)) {
        throw new Error('Date d\'expiration invalide (MM/AA)');
      }
      
      if (cardData.cvc.length < 3 || cardData.cvc.length > 4) {
        throw new Error('Code CVC invalide');
      }
      
      if (!cardData.name.trim()) {
        throw new Error('Nom du titulaire requis');
      }
      
      if (!cardData.email.includes('@')) {
        throw new Error('Email invalide');
      }

      // Vérification de la date d'expiration
      const [month, year] = cardData.expiry.split('/');
      const expiryDate = new Date(2000 + parseInt(year), parseInt(month) - 1);
      const now = new Date();
      
      if (expiryDate < now) {
        throw new Error('Carte expirée');
      }

      // Simulation d'un appel API réel vers votre backend de paiement
      const response = await fetch(`${import.meta.env.VITE_API_URL}/payments/process-card`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth-token')}`,
          'X-API-Version': '2024-01-01',
        },
        body: JSON.stringify({
          card: {
            number: cardNumber,
            exp_month: parseInt(month),
            exp_year: 2000 + parseInt(year),
            cvc: cardData.cvc,
            name: cardData.name
          },
          billing_details: {
            email: cardData.email,
            address: {
              line1: cardData.address,
              city: cardData.city,
              postal_code: cardData.postalCode,
              country: cardData.country || 'FR'
            }
          },
          amount: Math.round(amount * 100), // Convertir en centimes
          currency: 'usd',
          plan_id: planId,
          payment_method_types: ['card'],
          confirmation_method: 'automatic',
          confirm: true
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Erreur lors du traitement du paiement');
      }

      const result = await response.json();
      
      if (result.status === 'succeeded') {
        // Sauvegarder la transaction localement
        const transaction = {
          id: result.id,
          amount: amount,
          currency: 'USD',
          status: 'succeeded',
          payment_method: 'card',
          card_last4: cardNumber.slice(-4),
          card_brand: getCardBrand(cardNumber),
          created: new Date().toISOString(),
          plan_id: planId
        };
        
        const transactions = JSON.parse(localStorage.getItem('payment_history') || '[]');
        transactions.unshift(transaction);
        localStorage.setItem('payment_history', JSON.stringify(transactions.slice(0, 50)));
        
        return {
          success: true,
          transactionId: result.id
        };
      } else {
        throw new Error(result.error?.message || 'Paiement refusé');
      }
    } catch (error) {
      console.error('Erreur paiement carte:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Erreur de paiement'
      };
    } finally {
      setIsProcessing(false);
    }
  };

  const processPayPalPayment = async (paypalData: PayPalData, amount: number, planId: string): Promise<PaymentResult> => {
    setIsProcessing(true);
    try {
      // Validation des données PayPal
      if (!paypalData.email.includes('@')) {
        throw new Error('Email PayPal invalide');
      }
      
      if (paypalData.password.length < 6) {
        throw new Error('Mot de passe PayPal trop court');
      }

      // Simulation d'un appel API réel vers votre backend PayPal
      const response = await fetch(`${import.meta.env.VITE_API_URL}/payments/process-paypal`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth-token')}`,
        },
        body: JSON.stringify({
          paypal_email: paypalData.email,
          paypal_password: paypalData.password,
          amount: amount.toFixed(2),
          currency: 'USD',
          plan_id: planId,
          return_url: `${window.location.origin}/payment/success`,
          cancel_url: `${window.location.origin}/payment/cancel`
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Erreur lors du traitement du paiement PayPal');
      }

      const result = await response.json();
      
      if (result.status === 'COMPLETED') {
        // Sauvegarder la transaction localement
        const transaction = {
          id: result.id,
          amount: amount,
          currency: 'USD',
          status: 'completed',
          payment_method: 'paypal',
          paypal_email: paypalData.email,
          created: new Date().toISOString(),
          plan_id: planId
        };
        
        const transactions = JSON.parse(localStorage.getItem('payment_history') || '[]');
        transactions.unshift(transaction);
        localStorage.setItem('payment_history', JSON.stringify(transactions.slice(0, 50)));
        
        return {
          success: true,
          transactionId: result.id
        };
      } else {
        throw new Error(result.error?.message || 'Paiement PayPal refusé');
      }
    } catch (error) {
      console.error('Erreur paiement PayPal:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Erreur de paiement PayPal'
      };
    } finally {
      setIsProcessing(false);
    }
  };

  const getPaymentHistory = async (userId: string): Promise<any[]> => {
    try {
      // En production, récupérer depuis votre API
      const response = await fetch(`${import.meta.env.VITE_API_URL}/payments/history/${userId}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth-token')}`,
        },
      });

      if (response.ok) {
        return await response.json();
      } else {
        // Fallback vers le stockage local
        return JSON.parse(localStorage.getItem('payment_history') || '[]');
      }
    } catch (error) {
      console.error('Erreur récupération historique:', error);
      return JSON.parse(localStorage.getItem('payment_history') || '[]');
    }
  };

  const getCardBrand = (cardNumber: string): string => {
    const num = cardNumber.replace(/\s/g, '');
    if (num.startsWith('4')) return 'visa';
    if (num.startsWith('5') || num.startsWith('2')) return 'mastercard';
    if (num.startsWith('3')) return 'amex';
    if (num.startsWith('6')) return 'discover';
    return 'unknown';
  };

  return (
    <PaymentContext.Provider value={{
      isProcessing,
      processCardPayment,
      processPayPalPayment,
      getPaymentHistory,
    }}>
      {children}
    </PaymentContext.Provider>
  );
};

export const usePayment = () => {
  const context = useContext(PaymentContext);
  if (!context) {
    throw new Error('usePayment must be used within a PaymentProvider');
  }
  return context;
};