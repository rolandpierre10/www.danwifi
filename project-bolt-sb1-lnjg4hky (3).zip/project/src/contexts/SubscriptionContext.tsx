import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';
import { Subscription, VirtualNumber, WiFiCode, Plan, SMSMessage, CallRecord } from '../types/subscription';
import VirtualNumberService from '../services/VirtualNumberService';
import WiFiService from '../services/WiFiService';

type SubscriptionContextType = {
  subscription: Subscription | null;
  plans: Plan[];
  virtualNumbers: VirtualNumber[];
  wifiCodes: WiFiCode[];
  isLoading: boolean;
  createVirtualNumber: (countryCode: string, type: 'mobile' | 'landline' | 'premium') => Promise<VirtualNumber>;
  generateWiFiCode: (virtualNumberId: string, location?: { country: string; city: string; venue?: string }) => Promise<WiFiCode>;
  deleteVirtualNumber: (numberId: string) => Promise<void>;
  revokeWiFiCode: (codeId: string) => Promise<void>;
  subscribeToPlan: (planId: string) => Promise<void>;
  cancelSubscription: () => Promise<void>;
  renewSubscription: () => Promise<void>;
  sendSMS: (numberId: string, to: string, message: string) => Promise<boolean>;
  makeCall: (numberId: string, to: string) => Promise<boolean>;
  getSMSHistory: (numberId: string) => Promise<SMSMessage[]>;
  getCallHistory: (numberId: string) => Promise<CallRecord[]>;
  getWiFiAnalytics: (codeId: string) => Promise<any>;
  updateWiFiSettings: (codeId: string, settings: any) => Promise<boolean>;
};

const SubscriptionContext = createContext<SubscriptionContextType | undefined>(undefined);

// Plans de production avec tarifs réels
const productionPlans: Plan[] = [
  {
    id: 'monthly',
    name: 'Mensuel',
    duration: 1,
    price: 29.99,
    currency: 'USD',
    features: {
      virtualNumbers: 1,
      smsLimit: -1, // Unlimited
      voiceMinutes: -1, // Unlimited
      wifiCodes: 1,
      countries: ['*'], // All countries
      premiumNumbers: false,
      apiAccess: false,
      priority: 'standard'
    },
    popular: false
  },
  {
    id: 'quarterly',
    name: '3 Mois',
    duration: 3,
    price: 24.99,
    currency: 'USD',
    features: {
      virtualNumbers: 1,
      smsLimit: -1,
      voiceMinutes: -1,
      wifiCodes: 1,
      countries: ['*'],
      premiumNumbers: true,
      apiAccess: true,
      priority: 'high'
    },
    popular: true,
    savings: '17%'
  },
  {
    id: 'biannual',
    name: '6 Mois',
    duration: 6,
    price: 22.99,
    currency: 'USD',
    features: {
      virtualNumbers: 1,
      smsLimit: -1,
      voiceMinutes: -1,
      wifiCodes: 1,
      countries: ['*'],
      premiumNumbers: true,
      apiAccess: true,
      priority: 'premium'
    },
    popular: false,
    savings: '23%'
  },
  {
    id: 'annual',
    name: '12 Mois',
    duration: 12,
    price: 19.99,
    currency: 'USD',
    features: {
      virtualNumbers: 1,
      smsLimit: -1,
      voiceMinutes: -1,
      wifiCodes: 1,
      countries: ['*'],
      premiumNumbers: true,
      apiAccess: true,
      priority: 'premium'
    },
    popular: false,
    savings: '33%'
  }
];

export const SubscriptionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isAuthenticated } = useAuth();
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [virtualNumbers, setVirtualNumbers] = useState<VirtualNumber[]>([]);
  const [wifiCodes, setWiFiCodes] = useState<WiFiCode[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const virtualNumberService = VirtualNumberService.getInstance();
  const wifiService = WiFiService.getInstance();

  // Load subscription data when user is authenticated
  useEffect(() => {
    if (isAuthenticated && user) {
      loadSubscriptionData();
    } else {
      setSubscription(null);
      setVirtualNumbers([]);
      setWiFiCodes([]);
    }
  }, [isAuthenticated, user]);

  const loadSubscriptionData = async () => {
    setIsLoading(true);
    try {
      // Charger les données depuis le localStorage
      const savedSubscription = localStorage.getItem(`subscription_${user!.id}`);
      const savedNumbers = localStorage.getItem(`virtualNumbers_${user!.id}`);
      const savedCodes = localStorage.getItem(`wifiCodes_${user!.id}`);

      if (savedSubscription) {
        setSubscription(JSON.parse(savedSubscription));
      }
      if (savedNumbers) {
        setVirtualNumbers(JSON.parse(savedNumbers));
      }
      if (savedCodes) {
        setWiFiCodes(JSON.parse(savedCodes));
      }
    } catch (error) {
      console.error('Failed to load subscription data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const createVirtualNumber = async (countryCode: string, type: 'mobile' | 'landline' | 'premium'): Promise<VirtualNumber> => {
    setIsLoading(true);
    try {
      // Vérifier les limites
      if (virtualNumbers.length >= 1) {
        throw new Error('Vous avez déjà atteint la limite d\'un numéro virtuel par forfait');
      }

      // Créer le numéro virtuel réel via le service
      const newNumber = await virtualNumberService.createVirtualNumber({
        countryCode,
        type,
        userId: user!.id,
        features: {
          sms: true,
          voice: true,
          forwarding: type === 'premium'
        }
      });
      
      const updatedNumbers = [...virtualNumbers, newNumber];
      setVirtualNumbers(updatedNumbers);
      
      // Sauvegarder localement
      localStorage.setItem(`virtualNumbers_${user!.id}`, JSON.stringify(updatedNumbers));
      
      return newNumber;
    } finally {
      setIsLoading(false);
    }
  };

  const generateWiFiCode = async (virtualNumberId: string, location?: { country: string; city: string; venue?: string }): Promise<WiFiCode> => {
    setIsLoading(true);
    try {
      // Vérifier si ce numéro a déjà un code WiFi actif
      const existingCode = wifiCodes.find(wc => wc.virtualNumberId === virtualNumberId && wc.status === 'active');
      if (existingCode) {
        throw new Error('Ce numéro virtuel a déjà un code WiFi actif');
      }

      // Générer le code WiFi réel via le service
      const newCode = await wifiService.generateWiFiCode({
        virtualNumberId,
        location,
        security: 'WPA3',
        encryption: 'AES-256',
        maxConnections: 50,
        duration: 30
      });
      
      const updatedCodes = [...wifiCodes, newCode];
      setWiFiCodes(updatedCodes);
      
      // Sauvegarder localement
      localStorage.setItem(`wifiCodes_${user!.id}`, JSON.stringify(updatedCodes));
      
      return newCode;
    } finally {
      setIsLoading(false);
    }
  };

  const deleteVirtualNumber = async (numberId: string): Promise<void> => {
    setIsLoading(true);
    try {
      // Supprimer via le service
      await virtualNumberService.deleteNumber(numberId);
      
      const updatedNumbers = virtualNumbers.filter(vn => vn.id !== numberId);
      const updatedCodes = wifiCodes.filter(wc => wc.virtualNumberId !== numberId);
      
      setVirtualNumbers(updatedNumbers);
      setWiFiCodes(updatedCodes);
      
      // Sauvegarder localement
      localStorage.setItem(`virtualNumbers_${user!.id}`, JSON.stringify(updatedNumbers));
      localStorage.setItem(`wifiCodes_${user!.id}`, JSON.stringify(updatedCodes));
    } finally {
      setIsLoading(false);
    }
  };

  const revokeWiFiCode = async (codeId: string): Promise<void> => {
    setIsLoading(true);
    try {
      // Révoquer via le service
      await wifiService.revokeWiFiCode(codeId);
      
      const updatedCodes = wifiCodes.map(wc => 
        wc.id === codeId ? { ...wc, status: 'revoked' as const } : wc
      );
      
      setWiFiCodes(updatedCodes);
      localStorage.setItem(`wifiCodes_${user!.id}`, JSON.stringify(updatedCodes));
    } finally {
      setIsLoading(false);
    }
  };

  const subscribeToPlan = async (planId: string): Promise<void> => {
    setIsLoading(true);
    try {
      const plan = productionPlans.find(p => p.id === planId);
      if (!plan) throw new Error('Plan not found');

      const newSubscription: Subscription = {
        id: 'sub_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9),
        userId: user!.id,
        planId,
        status: 'active',
        startDate: new Date().toISOString(),
        endDate: new Date(Date.now() + plan.duration * 30 * 24 * 60 * 60 * 1000).toISOString(),
        autoRenew: true,
        virtualNumbers: [],
        wifiCodes: [],
        usage: {
          smsCount: 0,
          voiceMinutes: 0,
          wifiConnections: 0
        },
        limits: {
          maxNumbers: plan.features.virtualNumbers,
          maxSms: plan.features.smsLimit,
          maxVoiceMinutes: plan.features.voiceMinutes,
          maxWifiCodes: plan.features.wifiCodes
        }
      };

      setSubscription(newSubscription);
      localStorage.setItem(`subscription_${user!.id}`, JSON.stringify(newSubscription));
    } finally {
      setIsLoading(false);
    }
  };

  const cancelSubscription = async (): Promise<void> => {
    setIsLoading(true);
    try {
      if (subscription) {
        const updatedSubscription = { ...subscription, status: 'cancelled' as const, autoRenew: false };
        setSubscription(updatedSubscription);
        localStorage.setItem(`subscription_${user!.id}`, JSON.stringify(updatedSubscription));
      }
    } finally {
      setIsLoading(false);
    }
  };

  const renewSubscription = async (): Promise<void> => {
    setIsLoading(true);
    try {
      if (subscription) {
        const plan = productionPlans.find(p => p.id === subscription.planId);
        if (plan) {
          const newEndDate = new Date(Date.now() + plan.duration * 30 * 24 * 60 * 60 * 1000).toISOString();
          const updatedSubscription = { 
            ...subscription, 
            status: 'active' as const, 
            autoRenew: true,
            endDate: newEndDate
          };
          setSubscription(updatedSubscription);
          localStorage.setItem(`subscription_${user!.id}`, JSON.stringify(updatedSubscription));
        }
      }
    } finally {
      setIsLoading(false);
    }
  };

  const sendSMS = async (numberId: string, to: string, message: string): Promise<boolean> => {
    const virtualNumber = virtualNumbers.find(vn => vn.id === numberId);
    if (!virtualNumber) return false;

    const result = await virtualNumberService.sendSMS(numberId, {
      from: virtualNumber.number,
      to,
      message
    });

    return result.success;
  };

  const makeCall = async (numberId: string, to: string): Promise<boolean> => {
    const virtualNumber = virtualNumbers.find(vn => vn.id === numberId);
    if (!virtualNumber) return false;

    const result = await virtualNumberService.makeCall(numberId, {
      from: virtualNumber.number,
      to
    });

    return result.success;
  };

  const getSMSHistory = async (numberId: string): Promise<SMSMessage[]> => {
    return await virtualNumberService.getSMSHistory(numberId);
  };

  const getCallHistory = async (numberId: string): Promise<CallRecord[]> => {
    return await virtualNumberService.getCallHistory(numberId);
  };

  const getWiFiAnalytics = async (codeId: string): Promise<any> => {
    return await wifiService.getWiFiAnalytics(codeId);
  };

  const updateWiFiSettings = async (codeId: string, settings: any): Promise<boolean> => {
    return await wifiService.updateWiFiSettings(codeId, settings);
  };

  return (
    <SubscriptionContext.Provider value={{
      subscription,
      plans: productionPlans,
      virtualNumbers,
      wifiCodes,
      isLoading,
      createVirtualNumber,
      generateWiFiCode,
      deleteVirtualNumber,
      revokeWiFiCode,
      subscribeToPlan,
      cancelSubscription,
      renewSubscription,
      sendSMS,
      makeCall,
      getSMSHistory,
      getCallHistory,
      getWiFiAnalytics,
      updateWiFiSettings
    }}>
      {children}
    </SubscriptionContext.Provider>
  );
};

export const useSubscription = () => {
  const context = useContext(SubscriptionContext);
  if (!context) {
    throw new Error('useSubscription must be used within a SubscriptionProvider');
  }
  return context;
};