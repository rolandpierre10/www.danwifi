import React, { createContext, useContext, useState, useEffect } from 'react';

type User = {
  id: string;
  email: string;
  name: string;
  role: 'user' | 'admin' | 'partner';
  isApproved?: boolean;
  phone?: string;
  company?: string;
  country?: string;
  createdAt: string;
};

type AuthContextType = {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  signup: (email: string, password: string, name: string, role?: 'user' | 'partner') => Promise<void>;
  isAuthenticated: boolean;
  isAdmin: boolean;
  updateUser: (userData: Partial<User>) => void;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);

  // Load user from localStorage on mount
  useEffect(() => {
    const savedUser = localStorage.getItem('danwifi-user');
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser));
      } catch (error) {
        localStorage.removeItem('danwifi-user');
      }
    }
  }, []);

  // Save user to localStorage whenever user changes
  useEffect(() => {
    if (user) {
      localStorage.setItem('danwifi-user', JSON.stringify(user));
    } else {
      localStorage.removeItem('danwifi-user');
    }
  }, [user]);

  const login = async (email: string, password: string) => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Check for admin credentials
    if (email === 'admin@danwifi.com' && password === 'admin123') {
      const adminUser: User = {
        id: 'admin_001',
        email: 'admin@danwifi.com',
        name: 'Administrateur DanWiFi',
        role: 'admin',
        isApproved: true,
        createdAt: new Date().toISOString(),
      };
      setUser(adminUser);
      return;
    }
    
    // Mock user data based on email
    const mockUser: User = {
      id: Date.now().toString(),
      email,
      name: email.split('@')[0].replace(/[._]/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
      role: email.includes('admin') ? 'admin' : 'user',
      isApproved: true,
      createdAt: new Date().toISOString(),
    };
    
    setUser(mockUser);
  };

  const logout = () => {
    setUser(null);
  };

  const signup = async (email: string, password: string, name: string, role: 'user' | 'partner' = 'user') => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const mockUser: User = {
      id: Date.now().toString(),
      email,
      name,
      role,
      isApproved: role === 'partner' ? false : true, // Partners need approval
      createdAt: new Date().toISOString(),
    };
    
    setUser(mockUser);
  };

  const updateUser = (userData: Partial<User>) => {
    if (user) {
      setUser({ ...user, ...userData });
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      login,
      logout,
      signup,
      isAuthenticated: !!user,
      isAdmin: user?.role === 'admin',
      updateUser,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};