import React, { useState } from 'react';
import { LanguageProvider } from './contexts/LanguageContext';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { SubscriptionProvider } from './contexts/SubscriptionContext';
import { PaymentProvider } from './contexts/PaymentContext';
import Header from './components/Header';
import Hero from './components/Hero';
import Services from './components/Services';
import Pricing from './components/Pricing';
import Footer from './components/Footer';
import AdminDashboard from './components/AdminDashboard';
import SubscriptionDashboard from './components/SubscriptionDashboard';
import LegalPages from './pages/LegalPages';
import PWAInstallPrompt from './components/PWAInstallPrompt';
import OfflineIndicator from './components/OfflineIndicator';

const AppContent: React.FC = () => {
  const { isAuthenticated, isAdmin } = useAuth();
  const [showAdmin, setShowAdmin] = useState(false);
  const [showDashboard, setShowDashboard] = useState(false);
  const [legalPage, setLegalPage] = useState<'terms' | 'privacy' | 'cookies' | 'mentions' | null>(null);

  // Handle admin view
  React.useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash;
      
      // Reset states
      setShowAdmin(false);
      setShowDashboard(false);
      setLegalPage(null);
      
      // Check for legal pages
      if (hash === '#legal/terms') {
        setLegalPage('terms');
      } else if (hash === '#legal/privacy') {
        setLegalPage('privacy');
      } else if (hash === '#legal/cookies') {
        setLegalPage('cookies');
      } else if (hash === '#legal/mentions') {
        setLegalPage('mentions');
      } else if (hash === '#admin' && isAdmin) {
        setShowAdmin(true);
      } else if (hash === '#dashboard' && isAuthenticated) {
        setShowDashboard(true);
      }
    };

    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, [isAdmin, isAuthenticated]);

  // Handle legal page navigation
  React.useEffect(() => {
    const handleLegalNavigation = (event: Event) => {
      const target = event.target as HTMLAnchorElement;
      if (target.href) {
        const url = new URL(target.href);
        const pathname = url.pathname;
        
        if (pathname.startsWith('/legal/')) {
          event.preventDefault();
          const legalType = pathname.split('/')[2] as 'terms' | 'privacy' | 'cookies' | 'mentions';
          window.location.hash = `#legal/${legalType}`;
        }
      }
    };

    document.addEventListener('click', handleLegalNavigation);
    return () => document.removeEventListener('click', handleLegalNavigation);
  }, []);

  if (legalPage) {
    return (
      <LegalPages 
        type={legalPage} 
        onBack={() => {
          setLegalPage(null);
          window.location.hash = '';
        }} 
      />
    );
  }

  if (showAdmin && isAdmin) {
    return <AdminDashboard />;
  }

  if (showDashboard && isAuthenticated) {
    return <SubscriptionDashboard />;
  }

  return (
    <div className="min-h-screen bg-white">
      <OfflineIndicator />
      <Header />
      <main>
        <Hero />
        <Services />
        <Pricing />
      </main>
      <Footer />
      <PWAInstallPrompt />
    </div>
  );
};

function App() {
  return (
    <AuthProvider>
      <LanguageProvider>
        <PaymentProvider>
          <SubscriptionProvider>
            <AppContent />
          </SubscriptionProvider>
        </PaymentProvider>
      </LanguageProvider>
    </AuthProvider>
  );
}

export default App;