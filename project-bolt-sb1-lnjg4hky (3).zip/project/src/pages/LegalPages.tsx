import React from 'react';
import { ArrowLeft, Shield, Eye, Cookie, FileText, Mail, Phone, MapPin } from 'lucide-react';

interface LegalPageProps {
  type: 'terms' | 'privacy' | 'cookies' | 'mentions';
  onBack: () => void;
}

const LegalPages: React.FC<LegalPageProps> = ({ type, onBack }) => {
  const renderTermsOfService = () => (
    <div className="space-y-8">
      <div className="text-center">
        <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
          <FileText className="h-8 w-8 text-red-600" />
        </div>
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Conditions d'Utilisation</h1>
        <p className="text-gray-600">Dernière mise à jour : 15 janvier 2024</p>
      </div>

      <div className="prose max-w-none">
        <h2>1. Acceptation des Conditions</h2>
        <p>
          En utilisant les services DanWiFi, vous acceptez d'être lié par ces conditions d'utilisation. 
          Si vous n'acceptez pas ces conditions, veuillez ne pas utiliser nos services.
        </p>

        <h2>2. Description des Services</h2>
        <p>
          DanWiFi fournit des services de numéros de téléphone virtuels et de codes WiFi sécurisés dans plus de 200 pays. 
          Nos services incluent :
        </p>
        <ul>
          <li>Attribution d'un numéro de téléphone virtuel par forfait</li>
          <li>SMS et appels illimités</li>
          <li>Génération d'un code WiFi unique lié au numéro virtuel</li>
          <li>Support technique 24/7</li>
        </ul>

        <h2>3. Inscription et Compte</h2>
        <p>
          Pour utiliser nos services, vous devez créer un compte en fournissant des informations exactes et complètes. 
          Vous êtes responsable de maintenir la confidentialité de vos identifiants de connexion.
        </p>

        <h2>4. Utilisation Acceptable</h2>
        <p>Vous vous engagez à ne pas utiliser nos services pour :</p>
        <ul>
          <li>Des activités illégales ou frauduleuses</li>
          <li>Envoyer du spam ou des communications non sollicitées</li>
          <li>Violer les droits de propriété intellectuelle</li>
          <li>Compromettre la sécurité de nos systèmes</li>
        </ul>

        <h2>5. Tarification et Paiement</h2>
        <p>
          Les tarifs sont affichés en USD et incluent la TVA applicable. 
          Les paiements sont traités de manière sécurisée via Stripe et PayPal. 
          Les abonnements sont renouvelés automatiquement sauf annulation.
        </p>

        <h2>6. Politique d'Annulation et de Remboursement</h2>
        <p>
          Vous pouvez annuler votre abonnement à tout moment. 
          Nous offrons une garantie de remboursement de 30 jours pour tous les nouveaux abonnements.
        </p>

        <h2>7. Limitation de Responsabilité</h2>
        <p>
          DanWiFi ne sera pas responsable des dommages indirects, accessoires ou consécutifs 
          résultant de l'utilisation de nos services.
        </p>

        <h2>8. Modifications des Conditions</h2>
        <p>
          Nous nous réservons le droit de modifier ces conditions à tout moment. 
          Les modifications seront notifiées par email et prendront effet 30 jours après notification.
        </p>

        <h2>9. Contact</h2>
        <p>
          Pour toute question concernant ces conditions, contactez-nous à :
          <br />
          Email : contact@danwifi.com
          <br />
          Téléphone : (514) 654-3767
          <br />
          Adresse : 12100 42e Ave, Montréal, QC, Canada H1E 2X5
        </p>
      </div>
    </div>
  );

  const renderPrivacyPolicy = () => (
    <div className="space-y-8">
      <div className="text-center">
        <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
          <Eye className="h-8 w-8 text-blue-600" />
        </div>
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Politique de Confidentialité</h1>
        <p className="text-gray-600">Dernière mise à jour : 15 janvier 2024</p>
      </div>

      <div className="prose max-w-none">
        <h2>1. Collecte des Informations</h2>
        <p>Nous collectons les informations suivantes :</p>
        <ul>
          <li><strong>Informations personnelles :</strong> nom, email, téléphone, adresse</li>
          <li><strong>Informations de paiement :</strong> traitées de manière sécurisée par nos partenaires</li>
          <li><strong>Données d'utilisation :</strong> logs de connexion, utilisation des services</li>
          <li><strong>Informations techniques :</strong> adresse IP, type de navigateur, système d'exploitation</li>
        </ul>

        <h2>2. Utilisation des Informations</h2>
        <p>Nous utilisons vos informations pour :</p>
        <ul>
          <li>Fournir et maintenir nos services</li>
          <li>Traiter les paiements et gérer les abonnements</li>
          <li>Communiquer avec vous concernant votre compte</li>
          <li>Améliorer nos services et développer de nouvelles fonctionnalités</li>
          <li>Assurer la sécurité et prévenir la fraude</li>
        </ul>

        <h2>3. Partage des Informations</h2>
        <p>
          Nous ne vendons jamais vos informations personnelles. 
          Nous pouvons partager vos informations uniquement dans les cas suivants :
        </p>
        <ul>
          <li>Avec votre consentement explicite</li>
          <li>Avec nos prestataires de services (Stripe, PayPal) pour le traitement des paiements</li>
          <li>Pour se conformer aux obligations légales</li>
          <li>Pour protéger nos droits et notre sécurité</li>
        </ul>

        <h2>4. Sécurité des Données</h2>
        <p>
          Nous mettons en place des mesures de sécurité techniques et organisationnelles appropriées :
        </p>
        <ul>
          <li>Chiffrement SSL/TLS pour toutes les communications</li>
          <li>Stockage sécurisé des données avec chiffrement</li>
          <li>Accès limité aux données personnelles</li>
          <li>Surveillance continue de la sécurité</li>
        </ul>

        <h2>5. Vos Droits</h2>
        <p>Conformément au RGPD, vous avez le droit de :</p>
        <ul>
          <li>Accéder à vos données personnelles</li>
          <li>Rectifier des informations inexactes</li>
          <li>Supprimer vos données (droit à l'oubli)</li>
          <li>Limiter le traitement de vos données</li>
          <li>Portabilité de vos données</li>
          <li>Vous opposer au traitement</li>
        </ul>

        <h2>6. Conservation des Données</h2>
        <p>
          Nous conservons vos données personnelles aussi longtemps que nécessaire pour fournir nos services 
          et respecter nos obligations légales. Les données de facturation sont conservées 10 ans conformément à la loi.
        </p>

        <h2>7. Transferts Internationaux</h2>
        <p>
          Vos données peuvent être transférées et traitées dans des pays autres que votre pays de résidence. 
          Nous nous assurons que ces transferts respectent les réglementations applicables.
        </p>

        <h2>8. Contact</h2>
        <p>
          Pour exercer vos droits ou pour toute question concernant cette politique :
          <br />
          Email : privacy@danwifi.com
          <br />
          Téléphone : (514) 654-3767
          <br />
          Adresse : 12100 42e Ave, Montréal, QC, Canada H1E 2X5
        </p>
      </div>
    </div>
  );

  const renderCookiePolicy = () => (
    <div className="space-y-8">
      <div className="text-center">
        <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
          <Cookie className="h-8 w-8 text-green-600" />
        </div>
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Politique des Cookies</h1>
        <p className="text-gray-600">Dernière mise à jour : 15 janvier 2024</p>
      </div>

      <div className="prose max-w-none">
        <h2>1. Qu'est-ce qu'un Cookie ?</h2>
        <p>
          Un cookie est un petit fichier texte stocké sur votre appareil lorsque vous visitez notre site web. 
          Les cookies nous aident à améliorer votre expérience utilisateur et à analyser l'utilisation de notre site.
        </p>

        <h2>2. Types de Cookies Utilisés</h2>
        
        <h3>Cookies Essentiels</h3>
        <p>Ces cookies sont nécessaires au fonctionnement du site :</p>
        <ul>
          <li><strong>Session :</strong> maintient votre connexion</li>
          <li><strong>Sécurité :</strong> protège contre les attaques CSRF</li>
          <li><strong>Préférences :</strong> sauvegarde vos paramètres de langue</li>
        </ul>

        <h3>Cookies Analytiques</h3>
        <p>Ces cookies nous aident à comprendre comment vous utilisez notre site :</p>
        <ul>
          <li><strong>Google Analytics :</strong> analyse du trafic et du comportement</li>
          <li><strong>Hotjar :</strong> cartes de chaleur et enregistrements de session</li>
        </ul>

        <h3>Cookies Marketing</h3>
        <p>Ces cookies sont utilisés pour la publicité personnalisée :</p>
        <ul>
          <li><strong>Facebook Pixel :</strong> suivi des conversions</li>
          <li><strong>Google Ads :</strong> remarketing et optimisation</li>
        </ul>

        <h2>3. Gestion des Cookies</h2>
        <p>Vous pouvez contrôler les cookies de plusieurs façons :</p>
        <ul>
          <li><strong>Paramètres du navigateur :</strong> bloquer ou supprimer les cookies</li>
          <li><strong>Outils de désinscription :</strong> liens fournis par les services tiers</li>
          <li><strong>Préférences du site :</strong> panneau de gestion des cookies</li>
        </ul>

        <h2>4. Cookies Tiers</h2>
        <p>Nous utilisons des services tiers qui peuvent placer leurs propres cookies :</p>
        <ul>
          <li><strong>Stripe :</strong> traitement des paiements sécurisés</li>
          <li><strong>PayPal :</strong> alternative de paiement</li>
          <li><strong>Cloudflare :</strong> sécurité et performance</li>
        </ul>

        <h2>5. Durée de Conservation</h2>
        <p>Les cookies ont différentes durées de vie :</p>
        <ul>
          <li><strong>Session :</strong> supprimés à la fermeture du navigateur</li>
          <li><strong>Persistants :</strong> conservés selon la durée définie (max 2 ans)</li>
        </ul>

        <h2>6. Modifications</h2>
        <p>
          Cette politique peut être mise à jour pour refléter les changements dans notre utilisation des cookies. 
          Nous vous notifierons de tout changement significatif.
        </p>

        <h2>7. Contact</h2>
        <p>
          Pour toute question concernant notre utilisation des cookies :
          <br />
          Email : cookies@danwifi.com
          <br />
          Téléphone : (514) 654-3767
        </p>
      </div>
    </div>
  );

  const renderLegalNotices = () => (
    <div className="space-y-8">
      <div className="text-center">
        <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
          <Shield className="h-8 w-8 text-purple-600" />
        </div>
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Mentions Légales</h1>
        <p className="text-gray-600">Informations légales et réglementaires</p>
      </div>

      <div className="prose max-w-none">
        <h2>1. Informations sur l'Éditeur</h2>
        <div className="bg-gray-50 p-6 rounded-lg">
          <p><strong>Raison sociale :</strong> DanWiFi Inc.</p>
          <p><strong>Forme juridique :</strong> Société par actions</p>
          <p><strong>Siège social :</strong> 12100 42e Ave, Montréal, QC, Canada H1E 2X5</p>
          <p><strong>Numéro d'entreprise :</strong> 123456789 RC0001</p>
          <p><strong>TVA :</strong> CA123456789RT0001</p>
          <p><strong>Téléphone :</strong> (514) 654-3767</p>
          <p><strong>Email :</strong> contact@danwifi.com</p>
        </div>

        <h2>2. Directeur de Publication</h2>
        <p>
          <strong>Nom :</strong> Daniel Martineau
          <br />
          <strong>Qualité :</strong> Président-Directeur Général
          <br />
          <strong>Email :</strong> direction@danwifi.com
        </p>

        <h2>3. Hébergement</h2>
        <div className="bg-gray-50 p-6 rounded-lg">
          <p><strong>Hébergeur :</strong> Amazon Web Services (AWS)</p>
          <p><strong>Adresse :</strong> 410 Terry Avenue North, Seattle, WA 98109, États-Unis</p>
          <p><strong>Téléphone :</strong> +1 206-266-1000</p>
          <p><strong>Site web :</strong> aws.amazon.com</p>
        </div>

        <h2>4. Propriété Intellectuelle</h2>
        <p>
          Le site web DanWiFi et tous ses éléments (textes, images, logos, design, code source) 
          sont protégés par le droit d'auteur et appartiennent à DanWiFi Inc. ou à ses partenaires.
        </p>
        <p>
          Toute reproduction, représentation, modification, publication, adaptation de tout ou partie 
          des éléments du site est interdite sans autorisation écrite préalable.
        </p>

        <h2>5. Responsabilité</h2>
        <p>
          DanWiFi s'efforce de fournir des informations exactes et à jour sur son site web. 
          Cependant, nous ne pouvons garantir l'exactitude, la complétude ou l'actualité des informations.
        </p>
        <p>
          L'utilisation des informations et services proposés sur le site se fait sous la responsabilité 
          exclusive de l'utilisateur.
        </p>

        <h2>6. Données Personnelles</h2>
        <p>
          Conformément à la Loi sur la protection des renseignements personnels et les documents électroniques (LPRPDE) 
          et au Règlement général sur la protection des données (RGPD), vous disposez de droits concernant vos données personnelles.
        </p>
        <p>
          Pour plus d'informations, consultez notre 
          <a href="/legal/privacy" className="text-red-600 hover:underline"> Politique de Confidentialité</a>.
        </p>

        <h2>7. Cookies</h2>
        <p>
          Ce site utilise des cookies pour améliorer l'expérience utilisateur et analyser le trafic. 
          Pour plus d'informations, consultez notre 
          <a href="/legal/cookies" className="text-red-600 hover:underline"> Politique des Cookies</a>.
        </p>

        <h2>8. Droit Applicable et Juridiction</h2>
        <p>
          Le présent site web et les conditions d'utilisation sont régis par le droit canadien. 
          Tout litige sera soumis à la compétence exclusive des tribunaux de Montréal, Québec, Canada.
        </p>

        <h2>9. Médiation</h2>
        <p>
          En cas de litige, une solution amiable sera recherchée avant toute action judiciaire. 
          Vous pouvez contacter notre service client à l'adresse : mediation@danwifi.com
        </p>

        <h2>10. Contact</h2>
        <div className="bg-red-50 p-6 rounded-lg">
          <div className="flex items-center space-x-3 mb-3">
            <Mail size={20} className="text-red-600" />
            <span><strong>Email :</strong> legal@danwifi.com</span>
          </div>
          <div className="flex items-center space-x-3 mb-3">
            <Phone size={20} className="text-red-600" />
            <span><strong>Téléphone :</strong> (514) 654-3767</span>
          </div>
          <div className="flex items-start space-x-3">
            <MapPin size={20} className="text-red-600 mt-1" />
            <span>
              <strong>Adresse :</strong><br />
              12100 42e Ave<br />
              Montréal, QC, Canada<br />
              H1E 2X5
            </span>
          </div>
        </div>
      </div>
    </div>
  );

  const getContent = () => {
    switch (type) {
      case 'terms':
        return renderTermsOfService();
      case 'privacy':
        return renderPrivacyPolicy();
      case 'cookies':
        return renderCookiePolicy();
      case 'mentions':
        return renderLegalNotices();
      default:
        return renderTermsOfService();
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-red-600 hover:text-red-700 mb-8 transition-colors duration-200"
        >
          <ArrowLeft size={20} />
          <span>Retour à l'accueil</span>
        </button>

        <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
          {getContent()}
        </div>
      </div>
    </div>
  );
};

export default LegalPages;