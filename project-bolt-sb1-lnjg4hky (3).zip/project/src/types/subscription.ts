export interface VirtualNumber {
  id: string;
  number: string;
  country: string;
  countryCode: string;
  type: 'mobile' | 'landline' | 'premium';
  status: 'active' | 'inactive' | 'suspended';
  createdAt: string;
  expiresAt: string;
  features: {
    sms: boolean;
    voice: boolean;
    forwarding: boolean;
  };
  provider?: string;
  apiData?: {
    providerId: string;
    capabilities: string[];
    monthlyFee: number;
  };
}

export interface WiFiCode {
  id: string;
  code: string;
  virtualNumberId: string;
  ssid: string;
  password: string;
  status: 'active' | 'expired' | 'revoked';
  createdAt: string;
  expiresAt: string;
  usageCount: number;
  maxUsage: number;
  location?: {
    country: string;
    city: string;
    venue?: string;
  };
  security?: {
    type: 'WPA2' | 'WPA3';
    encryption: 'AES-128' | 'AES-256';
    provider: string;
  };
  analytics?: {
    totalConnections: number;
    uniqueDevices: number;
    dataUsage: number;
    peakUsage: string;
  };
}

export interface Subscription {
  id: string;
  userId: string;
  planId: string;
  status: 'active' | 'cancelled' | 'expired' | 'pending';
  startDate: string;
  endDate: string;
  autoRenew: boolean;
  virtualNumbers: VirtualNumber[];
  wifiCodes: WiFiCode[];
  usage: {
    smsCount: number;
    voiceMinutes: number;
    wifiConnections: number;
  };
  limits: {
    maxNumbers: number;
    maxSms: number;
    maxVoiceMinutes: number;
    maxWifiCodes: number;
  };
}

export interface Plan {
  id: string;
  name: string;
  duration: number; // in months
  price: number;
  currency: string;
  features: {
    virtualNumbers: number;
    smsLimit: number;
    voiceMinutes: number;
    wifiCodes: number;
    countries: string[];
    premiumNumbers: boolean;
    apiAccess: boolean;
    priority: 'standard' | 'high' | 'premium';
  };
  popular: boolean;
  savings?: string;
}

export interface SMSMessage {
  id: string;
  from: string;
  to: string;
  message: string;
  status: 'sent' | 'delivered' | 'failed' | 'pending';
  timestamp: string;
  cost: number;
  direction: 'inbound' | 'outbound';
}

export interface CallRecord {
  id: string;
  from: string;
  to: string;
  status: 'initiated' | 'ringing' | 'answered' | 'completed' | 'failed' | 'busy' | 'no-answer';
  timestamp: string;
  duration: number; // in seconds
  cost: number;
  direction: 'inbound' | 'outbound';
  recording?: string; // URL to recording if available
}

export interface WiFiConnection {
  deviceId: string;
  deviceName: string;
  deviceType: 'smartphone' | 'laptop' | 'tablet' | 'other';
  ipAddress: string;
  macAddress: string;
  connectedAt: string;
  disconnectedAt?: string;
  dataUsage: number; // in MB
  signalStrength: number; // in dBm
  sessionDuration: number; // in minutes
}

export interface UsageAnalytics {
  period: 'daily' | 'weekly' | 'monthly';
  sms: {
    sent: number;
    received: number;
    cost: number;
  };
  calls: {
    outbound: number;
    inbound: number;
    totalMinutes: number;
    cost: number;
  };
  wifi: {
    totalConnections: number;
    uniqueDevices: number;
    dataTransferred: number; // in MB
    averageSessionDuration: number; // in minutes
  };
  costs: {
    total: number;
    sms: number;
    calls: number;
    wifi: number;
    subscription: number;
  };
}