export interface PaymentMethod {
  id: string;
  type: 'stripe' | 'paypal';
  name: string;
  description: string;
  icon: string;
}

export interface PaymentIntent {
  id: string;
  amount: number;
  currency: string;
  status: 'pending' | 'processing' | 'succeeded' | 'failed' | 'canceled';
  paymentMethod: PaymentMethod;
  metadata: {
    planId: string;
    userId: string;
    planName: string;
    duration: number;
  };
}

export interface PaymentResult {
  success: boolean;
  paymentIntentId?: string;
  error?: string;
  redirectUrl?: string;
}

export interface StripePaymentData {
  token: string;
  amount: number;
  currency: string;
  description: string;
  metadata: Record<string, string>;
}

export interface PayPalPaymentData {
  orderId: string;
  payerId: string;
  amount: number;
  currency: string;
  description: string;
}