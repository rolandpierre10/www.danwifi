# 🌐 Guide Configuration DNS Netlify pour DanWiFi

## 🎯 **PROBLÈME : Pas d'option DNS sur Netlify ?**

Si vous ne voyez pas l'option DNS dans Netlify, c'est normal ! Voici les **2 solutions** possibles :

---

## 🚀 **SOLUTION 1 : Utiliser les DNS de votre Registrar (Recommandé)**

### Étape 1 : Déployer sur Netlify
1. **Connectez votre repo GitHub** à Netlify
2. **Configurez le build :**
   - Build command : `npm run build`
   - Publish directory : `dist`
3. **Déployez** votre site

### Étape 2 : Récupérer l'URL Netlify
Après déploiement, vous obtiendrez une URL comme :
```
https://amazing-site-123456.netlify.app
```

### Étape 3 : Configurer chez votre Registrar
**Allez chez votre registrar de domaine** (GoDaddy, Namecheap, OVH, etc.) et ajoutez :

#### Enregistrements DNS à ajouter :
```dns
Type    Nom                 Valeur
CNAME   www                 amazing-site-123456.netlify.app
CNAME   danwifi.com         amazing-site-123456.netlify.app
```

**OU si CNAME root n'est pas supporté :**
```dns
Type    Nom                 Valeur
A       @                   75.2.60.5
A       @                   99.83.190.102
A       @                   198.61.251.14
A       @                   198.61.251.15
CNAME   www                 amazing-site-123456.netlify.app
```

### Étape 4 : Configurer le domaine dans Netlify
1. **Site settings** → **Domain management**
2. **Add custom domain** → `danwifi.com`
3. **Verify DNS configuration**
4. **Force HTTPS** (automatique)

---

## 🔧 **SOLUTION 2 : Transférer les DNS vers Netlify**

### Étape 1 : Activer Netlify DNS
1. **Site settings** → **Domain management**
2. **Add custom domain** → `danwifi.com`
3. **Set up Netlify DNS** → Cliquez sur "Set up"

### Étape 2 : Récupérer les Name Servers Netlify
Netlify vous donnera des name servers comme :
```
dns1.p01.nsone.net
dns2.p01.nsone.net
dns3.p01.nsone.net
dns4.p01.nsone.net
```

### Étape 3 : Changer les Name Servers
**Chez votre registrar :**
1. **Allez dans** la gestion DNS
2. **Changez les name servers** vers ceux de Netlify
3. **Sauvegardez** (propagation 24-48h)

### Étape 4 : Configurer les enregistrements
**Dans Netlify DNS :**
```dns
Type    Nom                 Valeur
A       danwifi.com         75.2.60.5
AAAA    danwifi.com         2600:1f18:3e5b:e201::
CNAME   www                 danwifi.com
CNAME   api                 your-backend-service.com
CNAME   cdn                 your-cdn-service.com
```

---

## 📧 **CONFIGURATION EMAIL (Optionnel)**

### Pour les emails @danwifi.com
```dns
Type    Nom                 Valeur                      Priorité
MX      danwifi.com         mail.danwifi.com           10
MX      danwifi.com         mail2.danwifi.com          20
TXT     danwifi.com         "v=spf1 include:_spf.google.com ~all"
CNAME   mail                your-email-provider.com
```

---

## 🛡️ **CONFIGURATION SÉCURITÉ**

### Headers de Sécurité (netlify.toml)
Votre fichier `netlify.toml` est déjà configuré avec :
```toml
[[headers]]
  for = "/*"
  [headers.values]
    X-Frame-Options = "DENY"
    X-XSS-Protection = "1; mode=block"
    X-Content-Type-Options = "nosniff"
    Referrer-Policy = "strict-origin-when-cross-origin"
    Permissions-Policy = "geolocation=(), microphone=(), camera=()"
```

### SSL/TLS
- ✅ **HTTPS automatique** avec Let's Encrypt
- ✅ **Redirection HTTP → HTTPS** automatique
- ✅ **HSTS** configuré

---

## 🔍 **VÉRIFICATION DE LA CONFIGURATION**

### Outils de Test
1. **DNS Checker :** https://dnschecker.org/
2. **SSL Test :** https://www.ssllabs.com/ssltest/
3. **Security Headers :** https://securityheaders.com/

### Commandes de Vérification
```bash
# Vérifier les DNS
nslookup danwifi.com
dig danwifi.com

# Vérifier HTTPS
curl -I https://danwifi.com

# Test de connectivité
ping danwifi.com
```

---

## ⚡ **OPTIMISATIONS PERFORMANCE**

### Variables d'Environnement Netlify
**Dans Site settings → Environment variables :**
```env
VITE_APP_URL=https://danwifi.com
VITE_API_URL=https://api.danwifi.com
VITE_ENVIRONMENT=production
NODE_ENV=production
```

### Build Optimizations
**Dans netlify.toml :**
```toml
[build]
  publish = "dist"
  command = "npm run build"

[build.environment]
  NODE_VERSION = "18"
  NPM_FLAGS = "--production=false"
```

---

## 🚨 **DÉPANNAGE COURANT**

### "Domain already taken"
- Le domaine est déjà utilisé sur un autre site Netlify
- **Solution :** Supprimez-le de l'autre site d'abord

### "DNS not configured"
- Les DNS ne pointent pas vers Netlify
- **Solution :** Vérifiez les enregistrements chez votre registrar

### "SSL Certificate pending"
- Le certificat SSL est en cours de génération
- **Solution :** Attendez 10-15 minutes

### "Site not found"
- La propagation DNS n'est pas terminée
- **Solution :** Attendez 24-48h ou utilisez un VPN

---

## 📋 **CHECKLIST FINALE**

### Avant de Commencer ✅
- [ ] **Repo GitHub** connecté à Netlify
- [ ] **Build réussi** sur Netlify
- [ ] **Site accessible** via l'URL Netlify
- [ ] **Accès au registrar** de domaine

### Configuration DNS ✅
- [ ] **Enregistrements DNS** ajoutés
- [ ] **Domaine personnalisé** ajouté dans Netlify
- [ ] **HTTPS** activé et fonctionnel
- [ ] **Redirections** www → non-www configurées

### Tests Finaux ✅
- [ ] **https://danwifi.com** accessible
- [ ] **https://www.danwifi.com** redirige vers danwifi.com
- [ ] **Certificat SSL** valide
- [ ] **Headers de sécurité** présents
- [ ] **PWA** installable

---

## 🎯 **ÉTAPES RECOMMANDÉES POUR VOUS**

### 1. Déploiement Immédiat
```bash
# Connectez votre repo à Netlify
# Build command: npm run build
# Publish directory: dist
```

### 2. Configuration DNS Simple
**Chez votre registrar, ajoutez :**
```dns
CNAME   www                 votre-site.netlify.app
CNAME   danwifi.com         votre-site.netlify.app
```

### 3. Domaine Personnalisé
**Dans Netlify :**
- Site settings → Domain management
- Add custom domain → `danwifi.com`

### 4. Variables d'Environnement
**Ajoutez vos clés Twilio/Meraki dans Netlify**

---

## 📞 **SUPPORT**

### Si vous avez des problèmes :
- **Netlify Support :** https://docs.netlify.com/
- **DNS Help :** https://docs.netlify.com/domains-https/
- **DanWiFi Support :** support@danwifi.com

### Informations à fournir :
- Nom de votre registrar de domaine
- URL de votre site Netlify
- Messages d'erreur exacts
- Captures d'écran de la configuration

---

🎉 **Votre site DanWiFi sera bientôt accessible sur https://danwifi.com !**